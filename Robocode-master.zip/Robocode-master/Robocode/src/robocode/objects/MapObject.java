package robocode.objects;

import robocode.util.BoundingRectangle;

import java.awt.*;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

public class MapObject {
    public Line2D.Double top = new Line2D.Double();
    public Line2D.Double bottom = new Line2D.Double();
    public Line2D.Double right = new Line2D.Double();
    public Line2D.Double left = new Line2D.Double();
    public Point2D llc = new Point2D.Double();
    public Point2D ulc = new Point2D.Double();
    public Point2D urc = new Point2D.Double();
    public Point2D lrc = new Point2D.Double();
    private int x;
    private int y;
    private int width;
    private int height;
    private Shape shape;
    private BoundingRectangle boundingBox;

    public MapObject(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

        shape = new BoundingRectangle(x, y, width, height);
        boundingBox = new BoundingRectangle();
        boundingBox.setRect(x - 5, y - 5, width + 10, height + 10);

        llc = new Point2D.Double(this.getBoundingBox().getMinX(), this.getBoundingBox().getMinY());
        ulc = new Point2D.Double(this.getBoundingBox().getMinX(), this.getBoundingBox().getMaxY());
        urc = new Point2D.Double(this.getBoundingBox().getMaxX(), this.getBoundingBox().getMaxY());
        lrc = new Point2D.Double(this.getBoundingBox().getMaxX(), this.getBoundingBox().getMinY());

        top = new Line2D.Double(ulc, urc);
        bottom = new Line2D.Double(llc, lrc);
        left = new Line2D.Double(llc, ulc);
        right = new Line2D.Double(lrc, urc);
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return this.width;
    }

    public void setWidth(int w) {
        this.width = w;
    }

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int h) {
        this.height = h;
    }

    public synchronized BoundingRectangle getBoundingBox() {
        return boundingBox;
    }

    public Shape getShape() {
        return shape;
    }
}
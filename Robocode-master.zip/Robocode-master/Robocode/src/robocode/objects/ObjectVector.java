package robocode.objects;

import java.util.Vector;

public class ObjectVector implements Cloneable {

	private Vector vector = null;

	/*
	 * For creating a new vector of objects
	 */
	public ObjectVector() {
		vector = new Vector();
	}

	/*
	 * For loading a vector of objects
	 */
	private ObjectVector(Vector v) {
		vector = v;
	}

	public synchronized Object clone() {
		return new ObjectVector((Vector) vector.clone());
	}

//	public void add(ObjectVector spec)
//	{
//		vector.add(spec);
//	}

	public ObjectVector add(MapObject mapObj) {
		if (mapObj != null) {
			this.vector.add(mapObj);
		}
		return this;
	}

	public int size() {
		return vector.size();
	}

	public MapObject elementAt(int i) {
		return (MapObject) vector.elementAt(i);
	}

	public void sort() {
		java.util.Collections.sort(vector);
	}

	public void clear() {
		vector.clear();
	}

	public void remove(int i) {
		vector.remove(i);
	}
}


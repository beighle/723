/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode;

/**
 * A HitWallEvent is sent to {@link Robot#onHitWall} when you collide a wall.
 * You can use the information contained in this event to determine what to do.
 */
public class HitWallEvent extends Event {
    private double bearing = 0.0;
    private boolean hitWall;

    /**
     * Called by the game to create the HitWallEvent.
     */
    public HitWallEvent() {
        bearing = 0.0;
        hitWall = false;
    }

    public HitWallEvent(double bearing) {
        this.bearing = bearing;
    }

    /**
     * Returns the angle to the wall you hit, relative to your robot's heading.  -180 <= getBearing() < 180
     *
     * @return the angle to the wall you hit, in degrees
     */
    public double getBearing() {
        return bearing * 180.0 / Math.PI;
    }

    /**
     * Returns the angle to the wall you hit in radians, relative to your robot's heading.  -PI <= getBearing() < PI
     *
     * @return the angle to the wall you hit, in radians
     */
    public double getBearingRadians() {
        return bearing;
    }

    public void setBearingRadians(double bearing) {
        this.bearing = bearing;
    }

    public boolean getHitWall() {
        return hitWall;
    }

    public void setHitWall(boolean hitWall) {
        this.hitWall = hitWall;
    }
}

package robocode;

import javafx.util.Pair;

import java.util.ArrayList;
import java.util.Arrays;

class RoundRobinScheduler {


    public ArrayList<Battle> battleSet = new ArrayList<>();
    private ArrayList<String> robots = new ArrayList<>();
    private int battlesPerRobot;
    private int numberOfRobots;

    public RoundRobinScheduler(String[] robotNames, int battlesPerRobot) {
        loadNames(robotNames);
        this.battlesPerRobot = battlesPerRobot;
    }

    public RoundRobinScheduler(int numberOfRobots, int battlesPerRobot) {
        loadNames(new String[]{"development.grap.Alpha", "development.grap.Bravo", "development.grap.Charlie", "development.grap.Delta", "development.grap.Echo", "development.grap.Foxtrot", "development.grap.Golf", "development.grap.Hotel", "development.grap.India", "development.grap.Juliett", "development.grap.Kilo", "development.grap.Lima", "development.grap.Mike", "development.grap.November", "development.grap.Oscar", "development.grap.Papa", "development.grap.Quebec", "development.grap.Romeo", "development.grap.Sierra", "development.grap.Tango"});
        this.numberOfRobots = numberOfRobots;
        this.battlesPerRobot = battlesPerRobot;
    }

    public void loadNames(String[] robotNames) {
        robots.clear();
        this.numberOfRobots = robotNames.length;
        robots.addAll(Arrays.asList(robotNames).subList(0, numberOfRobots));
    }

    public ArrayList<Pair<String, String>> scheduleMatches() throws RuntimeException {

        while (!allComplete()) {
            for (String robot : robots) {
                if (complete(robot)) {
                    continue;
                }
                boolean matchMade = false;
                String potentialOpponent = getNext(robot);
                for (int i = 0; i < robots.size(); i++) {
                    Battle potentialBattle = new Battle(robot, potentialOpponent);
                    if (validOption(potentialBattle)) {
                        battleSet.add(potentialBattle);
                        //System.out.println("Added " + potentialBattle);
                        matchMade = true;
                        break;
                    }
                    potentialOpponent = getNext(potentialOpponent);
                }
                if (!matchMade) {
                    throw new RuntimeException("Cannot make valid match with " +
                            robot +
                            " and any other robot. Please try again.");
                }
            }
        }
        return battleSetAsMap();
    }

    private ArrayList<Pair<String, String>> battleSetAsMap() {
        ArrayList<Pair<String, String>> pairingMap = new ArrayList<>();
        for (Battle battle : battleSet) {
            pairingMap.add(new Pair<>(battle.robot1, battle.robot2));
        }
        return pairingMap;
    }

//    private void test() {
//        battleSet.add(new Battle(robots.get(0), robots.get(1)));
//        battleSet.add(new Battle(robots.get(1), robots.get(2)));
//        Battle testBattle = new Battle(robots.get(2), robots.get(1));
//        battleSet.add(testBattle);
//
//        for (Battle battle : battleSet) {
//            System.out.println(battle + " equals " + testBattle + " --> " + battle.equals(testBattle));
//        }
//
//        Battle b1 = new Battle(robots.get(1), robots.get(0));
//        Battle b2 = new Battle(robots.get(0), robots.get(1));
//        Battle b3 = new Battle(robots.get(1), robots.get(2));
//
//        System.out.println("BattleSet contains " + b1 + " --> " + battleSet.contains(b1));
//        System.out.println("BattleSet contains " + b2 + " --> " + battleSet.contains(b2));
//
//        System.out.println(battleSet);
//
//    }

    private String getNext(String current) {
        int index = robots.indexOf(current) + 1;
        if (index > robots.size() - 1) {
            index = 0;
        }
        return robots.get(index);

    }

    private int numberOfBattles(String robot) {
        return (int) battleSet.stream().filter(battle -> battle.contains(robot)).count();
    }

    private boolean allComplete() {
        boolean allComplete = true;
        for (String robot : robots) {
            if (!complete(robot)) {
                allComplete = false;
            }
        }
        return allComplete;
    }

    private boolean complete(String robot) {
        if (numberOfBattles(robot) < battlesPerRobot) {
            return false;
        }
        if (numberOfBattles(robot) > battlesPerRobot) {
            throw new IllegalStateException("Exceeded allowed number of battles for robot " + robot + ".");
        }
        return true;
    }

    private boolean validOption(Battle b) {
        return !battleSet.contains(b) &&
                numberOfBattles(b.robot1) < battlesPerRobot &&
                numberOfBattles(b.robot2) < battlesPerRobot &&
                !b.robot1.equals(b.robot2);
    }

    private static class Battle {
        String robot1;
        String robot2;

        Battle(String r1, String r2) {
            robot1 = r1;
            robot2 = r2;
        }

        boolean contains(String r) {
            return r.equals(robot1) || r.equals(robot2);
        }

        boolean contains(String r1, String r2) {
            return contains(r1) && contains(r2);
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof Battle)) {
                return false;
            }
            return this.contains(((Battle) o).robot1, ((Battle) o).robot2);
        }

        @Override
        public String toString() {
            return robot1 + " vs. " + robot2;
        }
    }
}

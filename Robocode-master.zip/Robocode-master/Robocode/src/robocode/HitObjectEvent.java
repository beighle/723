package robocode;

import java.io.Serializable;

/**
 * A ObjectWallEvent is sent to {@link Robot#onHitObject} when you collide with an object.
 * You can use the information contained in this event to determine what to do.
 */
public class HitObjectEvent extends Event implements Serializable {
    private double bearing = 0.0;
    private boolean hitObject;

    /**
     * Called by the game to create a new HitObjectEvent.
     */
    public HitObjectEvent() {
        bearing = 0.0;
        hitObject = false;
    }

    public HitObjectEvent(double bearing) {
        this.bearing = bearing;

    }

    /**
     * Returns the angle to the object you hit, relative to your robot's heading.  -180 <= getBearing() < 180
     *
     * @return the angle to the object you hit, in degrees
     */
    public double getBearing() {
        return bearing * 180.0 / Math.PI;
    }

    /**
     * Returns the angle to the object you hit in radians, relative to your robot's heading.  -PI <= getBearing() < PI
     *
     * @return the angle to the object you hit, in radians
     */
    public double getBearingRadians() {
        return bearing;
    }

    public void setBearingRadians(double bearing) {
        this.bearing = bearing;
    }

    public boolean getHitObject() {
        return hitObject;
    }

    public void setHitObject(boolean hitObject) {
        this.hitObject = hitObject;
    }
}
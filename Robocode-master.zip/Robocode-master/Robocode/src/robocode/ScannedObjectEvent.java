package robocode;

import java.io.Serializable;

/**
 * A ScannedObjectEvent is sent to {@link Robot#onScannedObject} when you scan an object.
 * You can use the information contained in this event to determine what to do.
 */
public class ScannedObjectEvent extends Event implements Serializable {
    private double bearing;
    private double distance;
    private boolean active;

    public ScannedObjectEvent() {
        this(0, 0, false);
    }

    /**
     * Called by the game to create a new ScannedRobotEvent.
     */
    public ScannedObjectEvent(double bearing, double distance, boolean active) {
        super();
        this.bearing = bearing;
        this.distance = distance;
        this.active = active;
    }

    /**
     * Returns the angle to the robot, relative to your robot's heading, in degrees.  -180 < getRobotBearing() <= 180
     *
     * @return the angle to the robot
     */
    public double getBearing() {
        return bearing * 180.0 / Math.PI;
    }

    /**
     * Returns the angle to the robot, relative to your robot's heading, in degrees.  -180 < getRobotBearing() <= 180
     *
     * @return the angle to the robot
     */
    public void setBearing(double bearing) {
        this.bearing = bearing * Math.PI / 180.0;
    }

    /**
     * Returns the angle to the robot, relative to your robot's heading, in radians.  -PI < getRobotBearingRadians() <= PI
     *
     * @return the angle to the robot
     */
    public double getBearingRadians() {
        return bearing;
    }

    /**
     * Returns the angle to the robot, relative to your robot's heading, in degrees.  -180 < getRobotBearing() <= 180
     *
     * @return the angle to the robot
     */
    public void setBearingRadians(double bearing) {
        this.bearing = bearing;
    }


    /**
     * Returns the distance to the robot you scanned (your center to his center).
     *
     * @return the distance to the robot you scanned.
     */
    public double getDistance() {
        return distance;
    }

    /**
     * Returns the angle to the robot, relative to your robot's heading, in degrees.  -180 < getRobotBearing() <= 180
     *
     * @return the angle to the robot
     */
    public void setDistance(double distance) {
        this.distance = distance;
    }

    /**
     * Returns whether an object has been detected recently.
     *
     * @return true if an object detected.
     */
    public boolean getActive() {
        return active;
    }

    /**
     * Returns the angle to the robot, relative to your robot's heading, in degrees.  -180 < getRobotBearing() <= 180
     *
     * @return the angle to the robot
     */
    public void setActive(boolean active) {
        this.active = active;
    }
///**
// * Returns the energy of the object
// * @return the energy of the object
// */
//public double getEnergy() {
//	return energy;
//}

}

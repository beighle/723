package robocode;

import javafx.util.Pair;

import java.util.ArrayList;

public class BenchmarkArgumentCreator extends MultiBattleArgumentCreator {
    @Override
    public ArrayList<String[]> getArguments(String[] args) {

        int numProcessors = Runtime.getRuntime().availableProcessors();
        int battlesPerProcessor = 1;
        boolean display = true;
        String osprey = "development.Osprey";
        String victor = "development.grap.Victor";

        for (int i = 0; i < args.length; i++) {
            if (args[i].equalsIgnoreCase("-benchmark")) {
                battlesPerProcessor = Integer.parseInt(args[i + 1]) / numProcessors;
            } else if (args[i].equalsIgnoreCase("-nodisplay")) {
                display = false;
            }
        }

        ArrayList<Pair<String, String>> pairings = new ArrayList<>();

        for (int i = 0; i < numProcessors; i++) {
            pairings.add(new Pair<>(victor, osprey));
        }


        ArrayList<String> battlePaths = generateBattleFiles(pairings, battlesPerProcessor);
        ArrayList<String> resultPaths = generateResultPaths(pairings); // returns paths for result files

        ArrayList<String[]> benchmarkArgs = new ArrayList<>();

        for (int i = 0; i < battlePaths.size(); i++) {
            benchmarkArgs.add(generateArgs(battlePaths.get(i), resultPaths.get(i), display));
        }
        return benchmarkArgs;
    }
}

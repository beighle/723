package robocode;

import javafx.util.Pair;

import java.util.ArrayList;

public class RoundRobinArgumentCreator extends MultiBattleArgumentCreator {

    @Override
    public ArrayList<String[]> getArguments(String[] args) {
        int numberOfBots = populationSize;
        int battlesPerBot = numberOfBots - 1;
        boolean display = true;

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-roundRobin")) {
                battlesPerBot = Integer.parseInt(args[i + 1]);
            } else if (args[i].equals("-nodisplay")) {
                display = false;
            }
        }

        if (args.length <= 1) {
            args = new String[]{"-battle", "battles/populationMelee.battle", "-results", "results/battleResults.txt"};
        }

        RoundRobinScheduler rss;
        rss = new RoundRobinScheduler(getRobotNames(), battlesPerBot);
        ArrayList<Pair<String, String>> pairings = rss.scheduleMatches(); // get robot opponent pairs
        ArrayList<String> battlePaths = generateBattleFiles(pairings, 1); // returns paths to battle files
        ArrayList<String> resultPaths = generateResultPaths(pairings); // returns paths for result files

        ArrayList<String[]> roundRobinArgs = new ArrayList<>();

        for (int i = 0; i < battlePaths.size(); i++) {
            roundRobinArgs.add(generateArgs(battlePaths.get(i), resultPaths.get(i), display));
        }
        return roundRobinArgs;

    }
}

package robocode;

import javafx.util.Pair;

import java.util.ArrayList;

public class TaOArgumentCreator extends MultiBattleArgumentCreator {

    @Override
    public ArrayList<String[]> getArguments(String[] args) {

        int battlesPerBot = 1;
        boolean display = true;
        String osprey = "development.Osprey";

        for (int i = 0; i < args.length; i++) {
            if (args[i].equalsIgnoreCase("-trainAgainstOsprey")) {
                battlesPerBot = Integer.parseInt(args[i + 1]);
            } else if (args[i].equalsIgnoreCase("-nodisplay")) {
                display = false;
            }
        }

        if (args.length <= 1) {
            args = new String[]{"-battle", "battles/populationMelee.battle", "-results", "results/battleResults.txt"};
        }

        ArrayList<Pair<String, String>> pairings = new ArrayList<>();

        for (int i = 0; i < populationSize; i++) {
            pairings.add(new Pair<>(getRobotNames()[i], osprey));
        }

        ArrayList<String> battlePaths = generateBattleFiles(pairings, battlesPerBot);
        ArrayList<String> resultPaths = generateResultPaths(pairings); // returns paths for result files

        ArrayList<String[]> taoArgs = new ArrayList<>();

        for (int i = 0; i < battlePaths.size(); i++) {
            taoArgs.add(generateArgs(battlePaths.get(i), resultPaths.get(i), display));
        }
        return taoArgs;
    }
}

/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode.editor;

import robocode.util.Utils;

import javax.swing.*;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;

/**
 * Insert the type's description here.
 * Creation date: (4/9/2001 5:15:56 PM)
 *
 * @author: Mathew A. Nelson
 */
public class EditWindow extends JInternalFrame implements CaretListener {

    public RobocodeEditorKit editorKit = null;
    public String fileName = null;
    public String robotName = null;
    public boolean modified = false;
    public JFrame frame = null;
    public File directory = null;
    private RobocodeEditor editor = null;
    private JEditorPane editorPane = null;
    private JPanel editWindowContentPane = null;
    private boolean mapFile = false;
    private JScrollPane scrollPane = null;


    /**
     * EditWindow constructor,
     */
    public EditWindow(RobocodeEditor editor, File directory) {
        super();
        initialize();
        this.editor = editor;
        this.directory = directory;
        //System.out.println(mapFile);
    }

    /**
     * Return the editorPane property value.
     *
     * @return javax.swing.JEditorPane
     */
    public JEditorPane getEditorPane() {
        if (editorPane == null) {
            try {
                editorPane = new JEditorPane();
                editorPane.setName("editorPane");
                editorPane.setFont(new java.awt.Font("monospaced", 0, 12));
                //editorPane.setBounds(0, 0, 6, 22);
                editorPane.setContentType("text/java");
                editorKit = new RobocodeEditorKit();
                editorPane.setEditorKitForContentType("text/java", editorKit);
                editorPane.setContentType("text/java");
                editorKit.setEditWindow(this);
                editorPane.addCaretListener(this);
                ((JavaDocument) editorPane.getDocument()).setEditWindow(this);
            } catch (Throwable e) {
                log(e);
            }
        }
        return editorPane;
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/18/2001 4:05:06 PM)
     *
     * @return java.lang.String
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/18/2001 4:05:06 PM)
     *
     * @param newFileName java.lang.String
     */
    public void setFileName(String newFileName) {
        fileName = newFileName;
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/18/2001 4:55:48 PM)
     *
     * @return java.lang.String
     */
    public String getRobotName() {
        return robotName;
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/18/2001 4:55:48 PM)
     *
     * @param newRobotName java.lang.String
     */
    public void setRobotName(String newRobotName) {
        robotName = newRobotName;
    }

    /**
     * Initialize the class.
     */
    private void initialize() {
        try {
            this.addInternalFrameListener(new InternalFrameAdapter() {
                public void internalFrameClosing(InternalFrameEvent e) {
                    if (!modified) {
                        editor.setLineStatus(-1);
                        dispose();
                    } else if (fileSave(true)) {
                        editor.setLineStatus(-1);
                        dispose();
                    }
                    return;
                }

                public void internalFrameDeactivated(InternalFrameEvent e) {
                    editor.setLineStatus(-1);
                }

                public void internalFrameIconified(InternalFrameEvent e) {
                    editor.setLineStatus(-1);
                }
            });
            setName("EditWindow");
            setResizable(true);
            setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            setIconifiable(true);
            setClosable(true);
            setMaximum(false);
            setFrameIcon(new ImageIcon(getClass().getResource("/resources/icons/icon.jpg")));
            setSize(553, 441);
            setMaximizable(true);
            setTitle("Edit Window");
            setContentPane(getEditWindowContentPane());
        } catch (Throwable e) {
            log(e);
        }
    }

    public boolean isMapFile() {
        return this.mapFile;
    }

    public void setMapFile(boolean mapFile) {
        this.mapFile = mapFile;
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/18/2001 4:56:22 PM)
     *
     * @param modified boolean
     */
    public void setModified(boolean modified) {

        if (this.modified == false && modified == true) {
            this.modified = true;
            if (fileName != null) {
                setTitle("Editing - " + fileName + " *");
            } else if (robotName != null) {
                setTitle("Editing - " + robotName + " *");
            } else {
                setTitle("Editing - *");
            }
        } else if (modified == false) {
            this.modified = false;
            if (fileName != null) {
                setTitle("Editing - " + fileName);
            } else if (robotName != null) {
                setTitle("Editing - " + robotName);
            } else {
                setTitle("Editing");
            }
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/10/2001 1:03:12 PM)
     *
     * @param e javax.swing.event.CaretEvent
     */
    public void caretUpdate(CaretEvent e) {
        int lineend = getEditorPane().getDocument().getDefaultRootElement().getElementIndex(e.getDot());
        editor.setLineStatus(lineend);
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/23/2001 12:06:39 PM)
     */
    public void compile() {
        if (!fileSave(true, true)) {
            error("You must save before compiling.");
            return;
        }

        RobocodeCompiler compiler = editor.getCompiler();
        if (compiler != null) {
            compiler.compile(fileName);
        } else {
            JOptionPane.showMessageDialog(editor, "No compiler installed.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
     * Insert the method's description here.
     * Creation date: (4/18/2001 4:27:07 PM)
     *
     * @param msg java.lang.String
     */
    public void error(String msg) {
        Object[] options = {"OK"};
        JOptionPane.showOptionDialog(this, msg, "Error", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, options, options[0]);

    }

    /**
     * Insert the method's description here.
     * Creation date: (4/19/2001 3:55:52 PM)
     *
     * @param editWindow robocode.editor.EditWindow
     * @return boolean - whether cancelled
     */
    public boolean fileSave(boolean confirm) {
        return fileSave(confirm, false);
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/19/2001 3:55:52 PM)
     *
     * @param editWindow robocode.editor.EditWindow
     * @return boolean - whether cancelled
     */
    public boolean fileSave(boolean confirm, boolean mustSave) {
        if (confirm) {
            if (!modified) {
                return true;
            }
            String s = fileName;
            if (s == null) {
                s = robotName;
            }
            if (s == null) {
                s = "This file";
            }
            int
                    ok =
                    JOptionPane.showConfirmDialog(this, s +
                            " has been modified.  Do you wish to save it?", "Modified file", JOptionPane.YES_NO_CANCEL_OPTION);
            if (ok == JOptionPane.NO_OPTION) {
                return !mustSave;
            }
            if (ok == JOptionPane.CANCEL_OPTION) {
                return false;
            }

        }
        String fileName = getFileName();
        if (fileName == null) {
            return fileSaveAs();
        }


        String reasonableFilename = getReasonableFilename();
        if (reasonableFilename != null) {
            try {
                String a = new File(reasonableFilename).getCanonicalPath();
                String b = new File(fileName).getCanonicalPath();
                if (!a.equals(b)) {
                    int
                            ok =
                            JOptionPane.showConfirmDialog(this, fileName +
                                    " should be saved in: \n" +
                                    reasonableFilename +
                                    "\n  Would you like to save it there instead?", "Name has changed", JOptionPane.YES_NO_CANCEL_OPTION);
                    if (ok == JOptionPane.CANCEL_OPTION) {
                        return false;
                    }
                    if (ok == JOptionPane.YES_OPTION) {
                        if (editor.getManager() != null) {
                            editor.getManager().getRobotRepositoryManager().clearRobotList();
                        }
                        return fileSaveAs();
                    }
                }
            } catch (Exception e) {
                log("Unable to check reasonable filename: " + e);
            }
        }
        File f = new File(fileName);
        try {
            FileWriter writer = new FileWriter(f);
            getEditorPane().write(writer);
            setModified(false);
            writer.close();
        } catch (IOException e) {
            error("Cannot write file: " + e);
            return false;
        }
        return true;
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/19/2001 3:55:52 PM)
     *
     * @param editWindow robocode.editor.EditWindow
     * @return boolean
     */
    public boolean fileSaveAs() {
        String fileName; // = editWindow.getFileName();
        String javaFileName = null;
        String saveDir = null;
        String packageTree = null;

        fileName = directory.getPath() + File.separatorChar;
        System.out.println(fileName);
        saveDir = fileName;

        try {
            String text = getEditorPane().getText();
            int pIndex = text.indexOf("package ");
            if (pIndex >= 0) {
                int pEIndex = text.indexOf(";", pIndex);
                if (pEIndex > 0) {
                    packageTree = text.substring(pIndex + 8, pEIndex) + File.separatorChar;
                    packageTree = packageTree.replace('.', File.separatorChar);

                    fileName += packageTree;
                    saveDir = fileName;
                }
            }

            pIndex = text.indexOf("public class ");
            if (pIndex >= 0) {
                int pEIndex = text.indexOf(" ", pIndex + 13);
                if (pEIndex > 0) {
                    int pEIndex2 = text.indexOf("\n", pIndex + 13);
                    if (pEIndex2 > 0 && pEIndex2 < pEIndex) {
                        pEIndex = pEIndex2;
                    }
                    javaFileName = text.substring(pIndex + 13, pEIndex).trim() + ".java";
                    fileName += javaFileName;
                } else {
                    pEIndex = text.indexOf("\n", pIndex + 13);
                    if (pEIndex > 0) {
                        javaFileName = text.substring(pIndex + 13, pEIndex).trim() + ".java";
                        fileName += javaFileName;
                    }
                }
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            error("Could not parse package and class names.");
        }

//	}

        File f = new File(saveDir);
        if (!f.exists()) {
            int
                    ok =
                    JOptionPane.showConfirmDialog(this, "Your robot should be saved in the directory: " +
                            saveDir +
                            "\nThis directory does not exist, would you like to create it?", "Create Directory", JOptionPane.YES_NO_CANCEL_OPTION);
            if (ok == JOptionPane.YES_OPTION) {
                f.mkdirs();
                f = new File(saveDir);
            }
            if (ok == JOptionPane.CANCEL_OPTION) {
                return false;
            }
        }

        JFileChooser chooser;
        chooser = new JFileChooser(f); //.getAbsoluteFile().toString());
        chooser.setCurrentDirectory(f);
//		log("opening at: " + f.getAbsoluteFile().toString());
        javax.swing.filechooser.FileFilter filter;
        System.out.println(isMapFile());
        if (!isMapFile()) {
            filter = new javax.swing.filechooser.FileFilter() {
                public boolean accept(File pathname) {
                    if (pathname.isDirectory()) {
                        return true;
                    }
                    String fn = pathname.getName();
                    int idx = fn.lastIndexOf('.');
                    String extension = "";
                    if (idx >= 0) {
                        extension = fn.substring(idx);
                    }
                    return extension.equalsIgnoreCase(".java");
                }

                public String getDescription() {
                    return "Robots";
                }
            };
        } else {
            filter = new javax.swing.filechooser.FileFilter() {
                public boolean accept(File pathname) {
                    if (pathname.isDirectory()) {
                        return true;
                    }
                    String fn = pathname.getName();
                    int idx = fn.lastIndexOf('.');
                    String extension = "";
                    if (idx >= 0) {
                        extension = fn.substring(idx);
                    }
                    return extension.equalsIgnoreCase(".maps");
                }

                public String getDescription() {
                    return "Maps";
                }
            };
        }

        chooser.setFileFilter(filter);

        boolean done = false;
        while (!done) {
            done = true;
            if (javaFileName != null) {
                chooser.setSelectedFile(new File(f, javaFileName));
            }
            int rv = chooser.showSaveDialog(this);
            String robotFileName = null;
            if (rv == JFileChooser.APPROVE_OPTION) {
                robotFileName = chooser.getSelectedFile().getPath();
                if (isMapFile()) {
                    int idx = robotFileName.lastIndexOf('.');
                    String extension = "";
                    if (idx > 0) {
                        extension = robotFileName.substring(idx);
                    }
                    if (!(extension.equalsIgnoreCase(".maps"))) {
                        robotFileName += ".maps";
                    }
                }
                File outFile = new File(robotFileName);
                if (outFile.exists()) {
                    int
                            ok =
                            JOptionPane.showConfirmDialog(this, robotFileName +
                                    " already exists.  Are you sure you want to replace it?", "Warning", JOptionPane.YES_NO_CANCEL_OPTION);
                    if (ok == JOptionPane.NO_OPTION) {
                        done = false;
                        continue;
                    }
                    if (ok == JOptionPane.CANCEL_OPTION) {
                        return false;
                    }
                }
                setFileName(robotFileName);
                fileSave(false);
            } else {
                return false;
            }
        }

        return true;
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/18/2001 4:34:48 PM)
     *
     * @return robocode.editor.RobocodeEditorKit
     */
    public RobocodeEditorKit getEditorKit() {
        return editorKit;
    }

    /**
     * Return the editWindowContentPane
     *
     * @return javax.swing.JPanel
     */
    private JPanel getEditWindowContentPane() {
        if (editWindowContentPane == null) {
            try {
                editWindowContentPane = new JPanel();
                editWindowContentPane.setName("editWindow");
                editWindowContentPane.setLayout(new java.awt.BorderLayout());
                editWindowContentPane.setDoubleBuffered(true);
                editWindowContentPane.add(getScrollPane(), "Center");
            } catch (Throwable e) {
                log(e);
            }
        }
        return editWindowContentPane;
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/23/2001 2:39:53 PM)
     *
     * @return javax.swing.JFrame
     */
    public JFrame getFrame() {
        return frame;
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/23/2001 2:39:53 PM)
     *
     * @param newFrame javax.swing.JFrame
     */
    public void setFrame(JFrame newFrame) {
        frame = newFrame;
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/10/2001 12:10:07 PM)
     *
     * @return java.lang.String
     */
    public String getPackage() {
        String text = getEditorPane().getText();
        int pIndex = text.indexOf("package ");
        if (pIndex >= 0) {
            int pEIndex = text.indexOf(";", pIndex);
            if (pEIndex > 0) {
                return text.substring(pIndex + 8, pEIndex);
            } else {
                return "";
            }
        } else {
            return "";
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (11/1/2001 5:42:28 PM)
     *
     * @return java.lang.String
     */
    public String getReasonableFilename() {

        String fileName = directory.getPath() + File.separatorChar;
        String saveDir = fileName;
        String javaFileName = null;
        String packageTree = null;

        try {
            String text = getEditorPane().getText();
            StringTokenizer tokenizer = new StringTokenizer(text, " \t\r\n;");
            String token = null;
            boolean inComment = false;
            while (tokenizer.hasMoreTokens()) {
                token = tokenizer.nextToken();
                if (!inComment && (token.equals("/*") || token.equals("/**"))) {
                    inComment = true;
                }
                if (inComment && (token.equals("*/") || token.equals("**/"))) {
                    inComment = false;
                }
                if (inComment) {
                    continue;
                }

                if (packageTree == null && token.equals("package")) {
                    packageTree = tokenizer.nextToken();
                    if (packageTree == null || packageTree.equals("")) {
                        return null;
                    }
                    packageTree = packageTree.replace('.', File.separatorChar);
                    packageTree += File.separator;
                    fileName += packageTree;
                    saveDir = fileName;
                }
                if (javaFileName == null && token.equals("class")) {
                    javaFileName = tokenizer.nextToken() + ".java";
                    fileName += javaFileName;
                    return fileName;
                }
            }

        } catch (Exception e) {
            return null;
        }

        return null;
        // fileName;
    }

    /**
     * Return the scrollPane
     *
     * @return javax.swing.JScrollPane
     */
    private JScrollPane getScrollPane() {
        if (scrollPane == null) {
            try {
                scrollPane = new JScrollPane();
                scrollPane.setName("scrollPane");
                scrollPane.setViewportView(getEditorPane());
            } catch (Throwable e) {
                log(e);
            }
        }
        return scrollPane;
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/22/2001 1:41:21 PM)
     *
     * @param e java.lang.Exception
     */
    public void log(String s) {
        Utils.log(s);
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/22/2001 1:41:21 PM)
     *
     * @param e java.lang.Exception
     */
    public void log(Throwable e) {
        Utils.log(e);
    }

    /**
     * Insert the method's description here.
     * Creation date: (4/20/2001 1:29:33 PM)
     */
    public void scrollToTop() {
        getEditorPane().scrollRectToVisible(new Rectangle(0, 0, 10, 10));

    }

    /**
     * Insert the method's description here.
     * Creation date: (4/18/2001 4:27:07 PM)
     *
     * @param msg java.lang.String
     */
    public void success(String msg) {
        Object[] options = {"OK"};
        JOptionPane.showOptionDialog(this, msg, "Success", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

    }
}
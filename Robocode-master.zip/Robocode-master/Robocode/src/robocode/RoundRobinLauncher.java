package robocode;

import java.io.File;
import java.util.ArrayList;
import java.util.Objects;

public class RoundRobinLauncher {

    public static void main(String[] args) {
        RoundRobinArgumentCreator mgr = new RoundRobinArgumentCreator();
        ArrayList<String[]> roundRobinArgs = mgr.getArguments(args);

        File resultsDir = new File("results\\roundRobin");
        for (File file : Objects.requireNonNull(resultsDir.listFiles())) {
            file.delete();
        }

        for (String[] rrArgs : roundRobinArgs) {
            Robocode.main(rrArgs);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

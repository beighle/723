/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode;


import robocode.manager.RobocodeManager;
import robocode.security.RobocodeSecurityManager;
import robocode.security.RobocodeSecurityPolicy;
import robocode.security.SecureInputStream;
import robocode.security.SecurePrintStream;
import robocode.util.Constants;
import robocode.util.Utils;

import javax.swing.*;
import java.io.File;
import java.security.Policy;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Robocode - A programming game involving battling AI tanks.<BR/>
 * Copyright 2001 Mathew Nelson
 *
 * @author Mathew A. Nelson
 * @see <a target="_top" href="http://robocode.sourceforge.net">robocode.sourceforge.net</a>
 */
public class Robocode {
    private RobocodeManager manager = null;

    private Robocode() {
    }

    /**
     * Use the command-line to start Robocode.
     * The command is:  java -jar robocode.jar
     *
     * @param args an array of command-line arguments
     */
    public static void main(String[] args) {
        Robocode robocode;

        if (args.length > 0) {
            if (args[0].equalsIgnoreCase("-roundRobin")) {
                RoundRobinArgumentCreator rrArgCreator = new RoundRobinArgumentCreator();
                ArrayList<String[]> rrArgs = rrArgCreator.getArguments(args);

                // clear out previous round's results
                File resultsDir = new File("results\\multiBattle");
                for (File file : Objects.requireNonNull(resultsDir.listFiles())) {
                    file.delete();
                }

                // progress bar
                System.out.print("                 |");
                for (int i = 0; i < Integer.parseInt(args[1]) * 10; i++) System.out.print(" ");
                System.out.println("|");
                System.out.print("Running battles: |");

                startMultiBattles(rrArgs);

            } else if (args[0].equalsIgnoreCase("-trainAgainstOsprey")) {

                MultiBattleArgumentCreator taoArgCreator = new TaOArgumentCreator();
                ArrayList<String[]> taoArgs = taoArgCreator.getArguments(args);

                // clear out previous round's results
                File resultsDir = new File("results\\multiBattle");
                for (File file : Objects.requireNonNull(resultsDir.listFiles())) {
                    file.delete();
                }

                // progress bar
                System.out.print("                 |");
                for (int i = 0; i < Integer.parseInt(args[1]) * 20; i++) System.out.print(" ");
                System.out.println("|");
                System.out.print("Running battles: |");

                startMultiBattles(taoArgs);

            } else if (args[0].equalsIgnoreCase("-benchmark")) {

                MultiBattleArgumentCreator benArgCreator = new BenchmarkArgumentCreator();
                ArrayList<String[]> benArgs = benArgCreator.getArguments(args);

                // clear out previous round's results
                File resultsDir = new File("results\\multiBattle");
                for (File file : Objects.requireNonNull(resultsDir.listFiles())) {
                    file.delete();
                }

                // progress bar
                System.out.print("                           |");
                for (int i = 0; i < Integer.parseInt(args[1]); i++) System.out.print(" ");
                System.out.println("|");
                System.out.print("Running benchmark battles: |");

                startMultiBattles(benArgs);

            } else {
                robocode = new Robocode();
                robocode.initialize(args);
            }
        } else if (args.length == 0) {
            robocode = new Robocode();
            robocode.initialize(args);
        }

        if (args.length == 0 ||
                (!args[0].equalsIgnoreCase("-roundRobin") && !args[0].equalsIgnoreCase("-trainAgainstOsprey"))) {

        } else {


        }
        //StatisticsSaver.updateGeneration(60, roundsPerBot);
        //System.exit(0);
    }

    private static void startMultiBattles(ArrayList<String[]> multiBattleArgs) {


        // spin up the battles
        for (String[] rrArgs : multiBattleArgs) {
            new Robocode().initialize(rrArgs);
            try {
                Thread.sleep(20);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.print("|");

    }

    synchronized boolean initialize(String[] args) {
        //System.out.println(getClass().getProtectionDomain().getCodeSource().getLocation());
        try {
            manager = new RobocodeManager(false, null);

            // Set native look and feel
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

            if (System.getProperty("WORKINGDIRECTORY") != null) {
                Constants.setWorkingDirectory(new File(System.getProperty("WORKINGDIRECTORY")));
            }
            if (System.getProperty("SINGLEBUFFER", "false").equals("true")) {
                RepaintManager.currentManager(manager.getWindowManager().getRobocodeFrame())
                        .setDoubleBufferingEnabled(false);
            }

            Thread.currentThread().setName("Application Thread");

            // This allows us, in Java 1.4, to use a custom 'classpath' policy.
            RobocodeSecurityPolicy securityPolicy = new RobocodeSecurityPolicy(Policy.getPolicy());
		/*
		DISABLE THE SECURITY POLICY THAT CAUSES THE UBF TO FAIL
		 */
//		Policy.setPolicy(securityPolicy);

            // For John Burkey at Apple
            boolean securityOn = false;
            if (System.getProperty("NOSECURITY", "false").equals("true")) {
                Utils.messageWarning("Robocode is running without a security manager.\n" +
                        "Robots have full access to your system.\n" +
                        "You should only run robots which you trust!");
                securityOn = false;
            }
            if (securityOn) {
                System.setSecurityManager(new RobocodeSecurityManager(Thread.currentThread(), manager.getThreadManager(), true));

                RobocodeFileOutputStream.setThreadManager(manager.getThreadManager());

                ThreadGroup tg = Thread.currentThread().getThreadGroup();
                while (tg != null) {
                    ((RobocodeSecurityManager) System.getSecurityManager()).addSafeThreadGroup(tg);
                    tg = tg.getParent();
                }
            }

            SecurePrintStream sysout = new SecurePrintStream(System.out, true, "System.out");
            SecurePrintStream syserr = new SecurePrintStream(System.err, true, "System.err");
            SecureInputStream sysin = new SecureInputStream(System.in, "System.in");

            System.setOut(sysout);
            if (System.getProperty("debug", "false").equals("true")) {
            } else {
                System.setErr(syserr);
            }
            System.setIn(sysin);

            boolean noDisplay = false;
            boolean minimize = false;
            String battleFilename = null;
            String resultsFilename = null;
            int fps = 10000;
            for (int i = 0; i < args.length; i++) {
                if (args[i].equals("-cwd") && (i < args.length + 1)) {
                    Constants.setWorkingDirectory(new File(args[i + 1]));
                    i++;
                } else if (args[i].equals("-battle") && (i < args.length + 1)) {
                    battleFilename = args[i + 1];
                    i++;
                } else if (args[i].equals("-results") && (i < args.length + 1)) {
                    resultsFilename = args[i + 1];
                    i++;
                } else if (args[i].equals("-fps") && (i < args.length + 1)) {
                    fps = Integer.parseInt(args[i + 1]);
                    i++;
                } else if (args[i].equals("-minimize")) {
                    minimize = true;
                } else if (args[i].equals("-nodisplay")) {
                    noDisplay = true;
                    //manager.getWindowManager().getRobocodeFrame().setVisible(false);
                } else if (args[i].equals("-?") || args[i].equals("-help")) {
                    printUsage();
                    System.exit(0);
                } else {
                    System.out.println("Not understood: " + args[i]);
                    printUsage();
                    System.exit(8);
                }
            }
            File robots = new File(Constants.cwd(), "Robocode/robots");
            if (!robots.exists() || !robots.isDirectory()) {
                System.err.println(new File(Constants.cwd(), "").getAbsolutePath() +
                        " is not a valid directory to start Robocode in. \n You must have a Robots folder in your working directory.");
                System.exit(8);
            }

            if (battleFilename != null) {
                if (resultsFilename != null) {
                    manager.getBattleManager().setResultsFile(resultsFilename);
                }
                manager.getBattleManager().setBattleFilename(battleFilename);
                manager.getBattleManager().loadBattleProperties();
                manager.getBattleManager().startNewBattle(manager.getBattleManager().getBattleProperties(), true);
                // I don't think this works... doesn't matter.
                // New functionality as of 0.98.3 is, when minimized, fps is max
                manager.getBattleManager().getBattle().setOptimalFPS(fps);
            }
            if (noDisplay) {
                return true;
            }

            if (!minimize && battleFilename == null) {
                manager.getWindowManager().showSplashScreen();
            }
            manager.getWindowManager().showRobocodeFrame();
            if (false)        // if (!minimize)
            {
                manager.getVersionManager().checkUpdateCheck();
            }
            if (minimize) {
                manager.getWindowManager().getRobocodeFrame().setState(JFrame.ICONIFIED);
            }

            if (!manager.getProperties().getLastRunVersion().equals(manager.getVersionManager().getVersion())) {
                manager.getProperties().setLastRunVersion(manager.getVersionManager().getVersion());
                manager.saveProperties();
                manager.runIntroBattle();
            }

            return true;
        } catch (Throwable e) {
            log(e);
            return false;
        }

    }

    private void log(Throwable e) {
        Utils.log(e);
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/23/2001 4:50:58 PM)
     */
    private void printUsage() {
        System.out.println("Usage: robocode [-cwd directory] [-battle filename [-results filename] [-fps fps] [-minimize]]");
    }

}
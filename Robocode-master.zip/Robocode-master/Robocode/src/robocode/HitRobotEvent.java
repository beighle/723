/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode;

import java.io.Serializable;

/**
 * A HitRobotEvent is sent to {@link Robot#onHitRobot} when you collide with another robot
 * You can use the information contained in this event to determine what to do.
 */
public class HitRobotEvent extends Event implements Serializable {
    private String robotName;
    private double bearing;
    private double energy;
    private boolean atFault = false;
    private boolean active = false;

    /**
     * Called by the game to create a new HitRobotEvent.
     */
    public HitRobotEvent(String name, double bearing, double energy, boolean atFault) {
        this.robotName = name;
        this.bearing = bearing;
        this.energy = energy;
        this.atFault = atFault;
        active = true;
    }

    public HitRobotEvent() {
        active = false;
    }

    public void setHitRobotEvent(String name, double bearing, double energy, boolean atFault) {
        this.robotName = name;
        this.bearing = bearing;
        this.energy = energy;
        this.atFault = atFault;
        active = true;
    }

    public void clearHitRobotEvent() {
        active = false;
    }

    public boolean activeHitRobotEvent() {
        return active;
    }

    /**
     * Returns the angle to the robot you hit, relative to your robot's heading.  -180 <= getBearing() < 180
     *
     * @return the angle to the robot you hit, in degrees
     */
    public double getBearing() {
        return bearing * 180.0 / Math.PI;
    }

    /**
     * Returns the angle to the robot you hit in radians, relative to your robot's heading.  -PI <= getBearing() < PI
     *
     * @return the angle to the robot you hit, in radians
     */
    public double getBearingRadians() {
        return bearing;
    }

    /**
     * Returns the energy of the robot you hit
     *
     * @return the energy of the robot you hit
     */
    public double getEnergy() {
        return energy;
    }

    /**
     * Returns the name of the robot you hit
     *
     * @return the name of the robot you hit
     */
    public String getName() {
        return robotName;
    }

    /**
     * If you were moving toward the robot you hit, isMyFault() will return true.
     * If isMyFault() is true, then your robot's movement (including turning)
     * will have stopped and been marked complete.
     * Note:  If two robots are moving toward each other and collide,
     * they will each receive two HitRobotEvents.  The first will be the one with isMyFault() == true.
     *
     * @return whether or not you were moving toward the other robot.
     */
    public boolean isMyFault() {
        return atFault;
    }
}

/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *     Brian Woolley - implemented a motor control variation of the Robot
 *     					for use by AFIT/ENG - CSCE623 and CSCE723
 *******************************************************************************/
package robocode;

import robocode.exception.RobotException;
import robocode.peer.RobotPeer;

import java.awt.*;
import java.util.Vector;

/**
 * The basic robot class that you will extend to create your own
 * robots.
 *
 * <P>Please note the following standards will be used:
 * <BR> heading - absolute angle in degrees with 0 facing up the screen, positive clockwise.  0 <= heading < 360.
 * <BR> bearing - relative angle to some object from your robot's heading, positive clockwise.  -180 < bearing <= 180
 * <BR> All coordinates are expressed as (x,y).
 * <BR> All coordinates are positive.
 * <BR> The origin (0,0) is at the bottom left of the screen.
 * <BR> Positive x is right.
 * <BR> Positive y is up.
 */
public abstract class Robot implements Runnable {
    /**
     * The output stream your robot should use to print.  You can view it by clicking the buttons on the right side of the battle.
     *
     * <P>Example
     * public void onHitRobot(HitRobotEvent e) {
     * out.println("I hit a robot!  My energy: " + getEnergy() + " his energy: " + e.getEnergy());
     * }
     * <p>
     * System.out will also print to this.
     */
    public java.io.PrintStream out = null;
    RobotPeer peer;

    /**
     * This method is called by the game.  RobotPeer is the object that deals with
     * game mechanics and rules, and makes sure your robot abides by them.
     * Do not call this method... your robot will simply stop interacting with the game.
     */
    public final void setPeer(RobotPeer peer) {
        this.peer = peer;
    }

    /*
     * Robot Info API
     */

    /**
     * Insert the method's description here.
     * Creation date: (8/27/2001 1:36:54 PM)
     *
     * @param s java.lang.String
     */
    protected void uninitializedException(String s) {
        throw new RobotException("You cannot call the " +
                s +
                "() method before your run() method is called, or you are using a Robot object that the game doesn't know about.");
    }

    /**
     * Returns the height of the robot
     *
     * @return the height of the robot
     */
    public double getHeight() {
        if (peer != null) {
            peer.getCall();
            return peer.getHeight();
        } else {
            uninitializedException("getHeight");
            return 0; // never called
        }
    }

    /**
     * Returns the width of the robot
     *
     * @return the width of the robot
     */
    public double getWidth() {
        if (peer != null) {
            peer.getCall();
            return peer.getWidth();
        } else {
            uninitializedException("getWidth");
            return 0; // never called
        }
    }

    /**
     * Returns the robot's name
     *
     * @return the robot's name
     */
    public String getName() {
        if (peer != null) {
            peer.getCall();
            return peer.getName();
        } else {
            uninitializedException("getName");
            return null; // never called
        }
    }

    /**
     * Get height of the current battlefield.
     *
     * @return The height of the battlefield.
     */
    public double getBattleFieldHeight() {
        if (peer != null) {
            peer.getCall();
            return peer.getBattleFieldHeight();
        } else {
            uninitializedException("getBattleFieldHeight");
            return 0; // never called
        }
    }

    /**
     * Get width of the current battlefield.
     *
     * @return The width of the battlefield.
     */
    public double getBattleFieldWidth() {
        if (peer != null) {
            peer.getCall();
            return peer.getBattleFieldWidth();
        } else {
            uninitializedException("getBattleFieldWidth");
            return 0; // never called
        }
    }

    /**
     * Returns the X position of the robot.  (0,0) is at the bottom left of the battlefield, and increases going right.
     *
     * @return the X position of the robot
     */
    public double getX() {
        if (peer != null) {
            peer.getCall();
            return peer.getX();
        } else {
            uninitializedException("getX");
            return 0; // never called
        }
    }

    /**
     * Returns the Y position of the robot.  (0,0) is at the bottom left of the battlefield, and increases going up.
     *
     * @return the Y position of the robot
     */
    public double getY() {
        if (peer != null) {
            peer.getCall();
            return peer.getY();
        } else {
            uninitializedException("getY");
            return 0; // never called
        }
    }

    /**
     * Returns the direction the robot is facing, in degrees. 0 is to the right, 90 is up.
     *
     * @return the direction the robot is facing, in degrees.
     */
    public double getHeading() {
        if (peer != null) {
            peer.getCall();
            return Math.toDegrees(peer.getHeading());
        } else {
            uninitializedException("getHeading");
            return 0; // never called
        }
    }

    /**
     * Gets current velocity of the robot, in distance/tick
     * <BR> Positive values indicate forward motion
     * <BR> Negative values indicate backward motion
     * <BR> A zero value indicates that the robot is stopped
     */
    public double getVelocity() {
        if (peer != null) {
            peer.getCall();
            return peer.getVelocity();
        } else {
            uninitializedException("getVelocity");
            return 0; // never called
        }
    }

    public abstract void setVelocity(double newVelocity);

    /**
     * Gets current turning rate of the robot, in degrees/tick.
     * <BR> Positive values indicate clockwise motion
     * <BR> Negative values indicate counter-clockwise motion
     * <BR> A zero value indicates that the robot is not rotating
     *
     * @return rotational speed of the robot, in degrees/tick
     */
    public double getTurnRate() {
        if (peer != null) {
            peer.getCall();
            return Math.toDegrees(peer.getTurnRate());
        } else {
            uninitializedException("getTurnRate");
            return 0; // never called
        }
    }

    public abstract void setTurnRate(double newTurnRate);

    /**
     * Returns gun heading in degrees [0..360]. 0 points to the right, and 90 to the top.
     *
     * @return gun heading
     */
    public double getGunHeading() {
        if (peer != null) {
            peer.getCall();
            return Math.toDegrees(peer.getGunHeading());
        } else {
            uninitializedException("getGunHeading");
            return 0; // never called
        }
    }

    /**
     * Gets the current rotational speed of the gun, in degrees/tick
     * <BR> Positive values indicate clockwise motion
     * <BR> Negative values indicate counter-clockwise motion
     * <BR> A zero value indicates that the radar is not rotating
     *
     * @return rotational speed of the gun, in degrees
     */
    public double getGunRotation() {
        if (peer != null) {
            peer.getCall();
            return Math.toDegrees(peer.getGunTurnRate());
        } else {
            uninitializedException("getGunRotation");
            return 0; // never called
        }

    }

    public abstract void setGunRotation(double newTurnRate);

    /**
     * Returns the current heat of the gun.  You cannot fire unless this is 0.
     * (Calls to fire will succeed, but will not actually fire unless getGunHeat() == 0
     *
     * @return the current gun heat
     */
    public double getGunHeat() {
        if (peer != null) {
            peer.getCall();
            return peer.getGunHeat();
        } else {
            uninitializedException("getGunHeat");
            return 0; // never called
        }
    }

    /**
     * Returns the rate at which the gun will cool down.
     *
     * @return the gun cooling rate
     * @see #getGunHeat
     */
    public double getGunCoolingRate() {
        if (peer != null) {
            peer.getCall();
            return peer.getBattle().getGunCoolingRate();
        } else {
            uninitializedException("getGunCoolingRate");
            return 0; // never called
        }
    }

    /* *****************
     * Robot Action API
     * *****************/

    /**
     * Returns radar heading in degrees [0..360].   0 points to the right and 90 to the top of the screen
     *
     * @return radar heading
     */
    public double getRadarHeading() {
        if (peer != null) {
            peer.getCall();
            return Math.toDegrees(peer.getRadarHeading());
        } else {
            uninitializedException("getRadarHeading");
            return 0; // never called
        }
    }

    /**
     * Gets the current rotational speed of the radar, in degrees/tick
     * <BR> Positive values indicate clockwise motion
     * <BR> Negative values indicate counter-clockwise motion
     * <BR> A zero value indicates that the radar is not rotating
     *
     * @return rotational speed of the radar, in degrees
     */
    public double getRadarRotation() {
        if (peer != null) {
            peer.getCall();
            return Math.toDegrees(peer.getRadarTurnRate());
        } else {
            uninitializedException("getRadarRotation");
            return 0; // never called
        }
    }

    public abstract void setRadarRotation(double newTurnRate);

    /**
     * Returns the robot's current energy
     *
     * @return the robot's energy
     */
    public double getEnergy() {
        if (peer != null) {
            peer.getCall();
            return peer.getEnergy();
        } else {
            uninitializedException("getEnergy");
            return 0; // never called
        }
    }

    public boolean isDead() {
        if (peer != null) {
            peer.getCall();
            return peer.isDead();
        } else {
            uninitializedException("isDead");
            return false;
        }
    }

    /**
     * Do nothing this turn.
     * This call executes immediately.
     */
    public void doNothing() {
        if (peer != null) {
            peer.tick();
        } else {
            uninitializedException("doNothing");
        }
    }

    /**
     * Fires a bullet.  The valid range for power is .1 to 3.
     * The bullet will travel in the direction the gun is pointing.
     * The bullet will do (4 * power) damage if it hits another robot.
     * If power is greater than 1, it will do an additional 2 * (power - 1) damage.
     * You will get (3 * power) back if you hit the other robot.
     * <p>
     * An event will be generated when the bullet hits a robot, wall, or other bullet.
     *
     * @param power The energy given to the bullet, and subtracted from your energy.
     * @see Robot#fireBullet
     * @see Robot#onBulletHit
     * @see Robot#onBulletHitBullet
     * @see Robot#onBulletMissed
     */
    public abstract Bullet fire(double power);

    /**
     * Look for other robots.
     * This method is called automatically by the game,
     * as long as you are moving, turning, turning your gun, or turning your radar.
     * <p>
     * There are 2 reasons to call scan() manually:
     * 1 - You want to scan after you stop moving
     * 2 - You want to interrupt the onScannedRobot event, or onScannedObject event.
     * This is more likely.  If you are in onScannedRobot or onScannedObject, and
     * call scan(), and you still see a robot or object, then the system will
     * interrupt your onScannedRobot event, or onScannedObject event, immediately
     * and start it from the top.
     * This call executes immediately.
     * <p>
     * Scan will cause {@link #onScannedRobot} to be called if you see a robot.
     * Scan will cause {@link #onScannedObject} to be called if you see an object.
     *
     * @see #onScannedRobot
     * @see #onScannedObject
     * @see robocode.ScannedRobotEvent
     * @see robocode.ScannedObjectEvent
     */
    public abstract void scan();

    /**
     * The main method in every robot.  Override this to set up your robot's basic behavior.
     *
     * <P>Example
     * <PRE>
     * // A basic robot that moves around in a square
     * public void run() {
     * while (true) {
     * ahead(100);
     * turnRight(90);
     * }
     * </PRE>
     */
    public abstract void run();

    /**
     * Called by the system to 'clean up' after your robot.
     * You may not override this method.
     */
    public final void finalize() {
    }


    /*
     * Game Information
     */

    /**
     * Returns the number of rounds in the current battle
     *
     * @return the number of rounds in the current battle
     */
    public int getNumRounds() {
        if (peer != null) {
            peer.getCall();
            return peer.getNumRounds();
        } else {
            uninitializedException("getNumRounds");
            return 0; // never called
        }
    }

    /**
     * Returns how many opponents are left
     *
     * @return how many opponents are left
     */
    public int getOthers() {
        if (peer != null) {
            peer.getCall();
            return peer.getOthers();
        } else {
            uninitializedException("getOthers");
            return 0; // never called
        }
    }

    /**
     * Returns the number of the current round (0 to getNumRounds()-1) in the battle
     *
     * @return the number of the current round in the battle
     */
    public int getRoundNum() {
        if (peer != null) {
            peer.getCall();
            return peer.getRoundNum();
        } else {
            uninitializedException("getRoundNum");
            return 0; // never called
        }

    }

    /**
     * Returns the current game time
     * Note:  1 battle consists of multiple rounds
     * Time is reset to 0 at the beginning of every round.
     * getTime() is equivalent to the number of frames displayed this round.
     *
     * @return the current game time
     */
    public long getTime() {
        if (peer != null) {
            peer.getCall();
            return peer.getTime();
        } else {
            uninitializedException("getTime");
            return 0; // never called
        }
    }

    /*
     * Robot Event API
     */

    /**
     * Returns the robot's last scanned object
     *
     * @return the robot's last scanned object
     */
    public ScannedObjectEvent getScannedObjectEvent() {
        if (peer != null) {
            peer.getCall();
            return peer.getScannedObjectEvent();
        } else {
            uninitializedException("getScannedObjectEvent");
            return null; // never called
        }
    }

    public Vector<ScannedRobotEvent> getScannedRobotEvents() {
        if (peer != null) {
            peer.getCall();
            return peer.getScannedRobotEvents();
        } else {
            uninitializedException("getScannedObjectEvents");
            return null; // never called
        }
    }

    /**
     * Returns that the robot hit an object
     *
     * @return the robot hit an object
     */
    public HitObjectEvent getHitObjectEvent() {
        if (peer != null) {
            peer.getCall();
            return peer.getHitObjectEvent();
        } else {
            uninitializedException("getHitObjectEvent");
            return null; // never called
        }
    }

    /**
     * Returns that the robot was just hit by a bullet
     *
     * @return the HitByBulletEvent status
     */
    public HitByBulletEvent getHitByBulletEvent() {
        if (peer != null) {
            peer.getCall();
            return peer.getHitByBulletEvent();
        } else {
            uninitializedException("getHitByBulletEvent");
            return null; // never called
        }
    }

    /**
     * Returns that the robot's bullet hit a target.
     *
     * @return the BulletHitEvent status
     */
    public BulletHitEvent getBulletHitEvent() {
        if (peer != null) {
            peer.getCall();
            return peer.getBulletHitEvent();
        } else {
            uninitializedException("getBulletHitEvent");
            return null; // never called
        }
    }

    public boolean getBulletMissedEvent() {
        if (peer != null) {
            peer.getCall();
            return peer.getBulletMissed();
        }
        return false; // never called
    }

    public boolean getBulletHitBulletEvent() {
        if (peer != null) {
            peer.getCall();
            return peer.getBulletHitBullet();
        }
        return false; // never called
    }

    public HitRobotEvent getHitRobotEvent() {
        if (peer != null) {
            peer.getCall();
            return peer.getHitRobotEvent();
        }
        return null; // never called
    }

    public boolean getRobotDeathEvent() {
        if (peer != null) {
            peer.getCall();
            return peer.getRobotDeath();
        }
        return false;
    }

    public String getRobotDeathName() {
        if (peer != null) {
            peer.getCall();
            return peer.getDeadRobotName();
        }
        return null;
    }

    /**
     * This method will be called if you are taking an extremely long time between actions.
     * If you receive 30 of these, your robot will be removed from the round.
     * You will only receive this event after taking an action... so a robot in an infinite loop
     * will not receive any events, and will simply be stopped.
     * <p>
     * No correctly working, reasonable robot should ever receive this event.
     *
     * @param event The event set by the game
     * @see Event
     */
    public abstract void onSkippedTurn();

    /*
     * Robot Settings API
     */

    /**
     * Checks if the gun is set to adjust for the robot turning.
     *
     * @return if the gun is set to adjust for the robot turning.
     * @see #setAdjustGunForRobotTurn
     */
    public boolean isAdjustGunForRobotTurn() {
        if (peer != null) {
            peer.getCall();
            return peer.isAdjustGunForBodyTurn();
        } else {
            uninitializedException("isAdjustGunForRobotTurn");
            return false; // never called
        }
    }

    /**
     * Sets the gun to automatically turn the opposite way when the robot turns.
     * <p>
     * Ok, so this needs some explanation:
     * The gun is mounted on the robot.  So, normally, if the robot turns 90 degrees to the right,
     * then the gun will turn with it.
     *
     * <P>To compensate for this, you can call setAdjustGunForRobotTurn(true).  When this is set,
     * the gun will automatically turn in the opposite direction, so that it "stays still" when
     * the robot turns.
     *
     * <P>Example, assuming both the robot and gun start out facing up (0 degrees):
     * <PRE>
     * setAdjustGunForRobotTurn(false); // This is the default
     * turnRight(90);
     * // At this point, both the robot and gun are facing right (90 degrees);
     * turnLeft(90);
     * // Both are back to 0 degrees
     * <p>
     * -- or --
     * <p>
     * setAdjustGunForRobotTurn(true);
     * turnRight(90);
     * // At this point, the robot is facting right (90 degrees), but the gun is still facing up.
     * turnLeft(90);
     * // Both are back to 0 degrees.
     * </PRE>
     *
     * <P>Note:  The gun compensating this way does count as "turning the gun".  See {@link #setAdjustRadarForGunTurn} for details.
     *
     * @param adjustGunForRobotTurn
     * @see #setAdjustRadarForGunTurn
     */
    public void setAdjustGunForRobotTurn(boolean newAdjustGunForRobotTurn) {
        if (peer != null) {
            peer.setCall();
            peer.setAdjustGunForBodyTurn(newAdjustGunForRobotTurn);
        } else {
            uninitializedException("setAdjustGunForRobotTurn");
        }
    }

    /**
     * Checks if the radar is set to adjust for the gun turning.
     *
     * @return if the radar is set to adjust for the gun turning.
     * @see #setAdjustRadarForGunTurn
     */
    public boolean isAdjustRadarForGunTurn() {
        if (peer != null) {
            peer.getCall();
            return peer.isAdjustRadarForGunTurn();
        } else {
            uninitializedException("isAdjustRadarForGunTurn");
            return false; // never called
        }
    }

    /**
     * Sets the radar to automatically turn the opposite way when the gun turns.
     * <p>
     * Make sure you understand how {@link #setAdjustGunForRobotTurn} works before reading on...
     *
     * <P>Ok, so now you understand {@link #setAdjustGunForRobotTurn} right?
     *
     * <P>Just like the gun is mounted on the robot, the radar is mounted on the gun.
     * So, normally, if the gun turns 90 degrees to the right,
     * then the radar will turn with it.
     *
     * <P>To compensate for this (if you like), you can call setAdjustRadarForGunTurn(true).  When this is set,
     * the radar will automatically turn in the opposite direction, so that it "stays still" when
     * the gun turns (in relation to the body, as of 0.97).
     *
     * <P>Example, assuming both the radar and gun start out facing up (0 degrees):
     * <PRE>
     * setAdjustRadarForGunTurn(false); // This is the default
     * turnGunRight(90);
     * // At this point, both the radar and gun are facing right (90 degrees);
     * <p>
     * -- or --
     * <p>
     * setAdjustRadarForGunTurn(true);
     * turnGunRight(90);
     * // At this point, the gun is facing right (90 degrees), but the radar is still facing up.
     *
     * </PRE>
     * <P>Note: Calling setAdjustRadarForGunTurn will automatically call setAdjustRadarForRobotTurn
     * with the same value, unless you have already called it yourself.  This
     * behavior is primarily for backward compatibility with older Robocode robots.
     *
     * @param adjustGunForRobotTurn
     * @see #setAdjustRadarForRobotTurn
     * @see #setAdjustGunForRobotTurn
     */
    public void setAdjustRadarForGunTurn(boolean newAdjustRadarForGunTurn) {
        if (peer != null) {
            peer.setCall();
            peer.setAdjustRadarForGunTurn(newAdjustRadarForGunTurn);
        } else {
            uninitializedException("setAdjustRadarForGunTurn");
        }
    }

    /**
     * Checks if the radar is set to adjust for the robot turning.
     *
     * @return if the radar is set to adjust for the robot turning.
     * @see #setAdjustRadarForRobotTurn
     */
    public boolean isAdjustRadarForRobotTurn() {
        if (peer != null) {
            peer.getCall();
            return peer.isAdjustRadarForBodyTurn();
        } else {
            uninitializedException("isAdjustRadarForRobotTurn");
            return false; // never called
        }
    }

    /**
     * Sets the radar to automatically turn the opposite way when the robot turns.
     *
     * <P>The radar is mounted on the gun, which is mounted on the robot.
     * So, normally, if the robot turns 90 degrees to the right, the gun turns, as does the radar.0
     *
     * <P>To compensate for this (if you like), you can call setAdjustRadarForRobotTurn(true).  When this is set,
     * the radar will automatically turn in the opposite direction, so that it "stays still" when
     * the body turns.
     *
     * <P>Example, assuming the robot, gun, and radar all start out facing up (0 degrees):
     * <PRE>
     * setAdjustRadarForRobotTurn(false); // This is the default
     * turnRight(90);
     * // At this point, all three are facing right (90 degrees);
     * <p>
     * -- or --
     * <p>
     * setAdjustRadarForRobotTurn(true);
     * turnRight(90);
     * // At this point, the robot and gun are facing right (90 degrees), but the radar is still facing up.
     *
     * </PRE>
     *
     * @param adjustRadarForRobotTurn
     * @see #setAdjustGunForRobotTurn
     * @see #setAdjustRadarForGunTurn
     */
    public void setAdjustRadarForRobotTurn(boolean newAdjustRadarForRobotTurn) {
        if (peer != null) {
            peer.setCall();
            peer.setAdjustRadarForBodyTurn(newAdjustRadarForRobotTurn);
        } else {
            uninitializedException("setAdjustRadarForRobotTurn");
        }
    }

    /**
     * Call this method to set your robot's colors.
     * You may only call this method one time per battle.
     * A null indicates the default (blue-ish) color.
     *
     * <PRE>
     * Example:
     * // Don't forget to import java.awt.Color at the top...
     * import java.awt.Color;
     * <p>
     * public void run() {
     * setColors(Color.black,Color.red,new Color(150,0,150));
     * }
     * </PRE>
     *
     * @param robotColor Your robot's color
     * @param gunColor   Your robot's gun color
     * @param radarColor Your robot's radar color
     * @see Color
     */
    public void setColors(Color robotColor, Color gunColor, Color radarColor) {
        if (peer != null) {
            peer.setCall();
            peer.setColors(robotColor, gunColor, radarColor);
        } else {
            uninitializedException("setColors");
        }
    }
}
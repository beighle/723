/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode.util;

/**
 * Insert the type's description here.
 * Creation date: (12/29/2000 12:13:09 PM)
 *
 * @author Mathew A. Nelson
 */
public class RobocodeFileFilter implements java.io.FileFilter {
    String[] fileTypes = null;

    /**
     * RobocodeFilenameFilter constructor
     */
    public RobocodeFileFilter(String[] fileTypes) {
        super();
        this.fileTypes = fileTypes;
    }

    /**
     * Tests if a specified file should be included in a file list.
     *
     * @param file java.io.File the directory in which the file was found.
     * @return <code>true</code> if and only if the name should be
     * included in the file list; <code>false</code> otherwise.
     */
    public boolean accept(java.io.File file) {
        if (file.isDirectory()) {
            return true;
        }

        for (int i = 0; i < fileTypes.length; i++) {
            if (file.getName().length() > fileTypes[i].length()) {
                if (file.getName().substring(file.getName().length() - fileTypes[i].length()).equals(fileTypes[i])) {
                    return true;
                }
            }
        }
        return false;
    }
}

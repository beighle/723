/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *     Brian Woolley - implemented a motor control variation of the RobotPeer
 *     					for use by AFIT/ENG - CSCE623 and CSCE723
 *******************************************************************************/
package robocode.peer;

import robocode.Robot;
import robocode.*;
import robocode.battle.Battle;
import robocode.battlefield.BattleField;
import robocode.exception.DeathException;
import robocode.exception.DisabledException;
import robocode.exception.RobotException;
import robocode.exception.WinException;
import robocode.manager.ImageManager;
import robocode.manager.RobotRepositoryManager;
import robocode.objects.MapObject;
import robocode.peer.robot.*;
import robocode.util.BoundingRectangle;
import robocode.util.Utils;

import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Random;
import java.util.Vector;

/**
 * Insert the type's description here.
 * Creation date: (12/15/2000 12:04:09 PM)
 *
 * @author Mathew A. Nelson
 */
public class RobotPeer implements Runnable, ContestantPeer {
    // Environmental Limits on Velocity
    private static final double maxVelocity = 8;
    private static final double maxTurnRate = Math.toRadians(10);
    private static final double maxGunTurnRate = Math.toRadians(20);
    private static final double maxRadarTurnRate = Math.toRadians(20);
    // Environmental Limits on Acceleration
    private static final double acceleration = 1;
    private static final double turnAcceleration = Math.toRadians(1);
    private static final double gunTurnAcceleration = Math.toRadians(2);
    private static final double radarTurnAcceleration = Math.toRadians(2);
    private final long maxSetCallCount = 10000;
    private final long maxGetCallCount = 10000;
    public boolean printit = false;
    public int printcount = 0;
    public RobotOutputStream out = null;
    public java.awt.Rectangle dirtyRect;
    public java.awt.Rectangle arcRect;
    public boolean checkFileQuota = false;
    // Current Position Attributes (angles are in radians)
    private double x;
    private double y;
    private double heading;
    private double gunHeading;
    private double radarHeading;
    // Past Position Attributes
    private double lastX = 0;
    private double lastY = 0;
    private double lastHeading;
    private double lastGunHeading;
    private double lastRadarHeading;
    // Current Velocity Values
    private double velocity;
    private double turnRate;
    private double gunTurnRate;
    private double radarTurnRate;
    // Desired Velocity Values
    private double desiredVelocity = 0;
    private double desiredTurnRate = 0;
    private double desiredGunTurnRate = 0;
    private double desiredRadarTurnRate = 0;
    // Detection Events
    private ScannedObjectEvent scannedObjectEvent;
    private Vector<ScannedRobotEvent> scannedRobotEvents;
    private HitObjectEvent hitObjectEvent;
    private HitByBulletEvent hitByBulletEvent;
    private BulletHitEvent bulletHitEvent;
    private HitRobotEvent hitRobotEvent;
    private boolean bulletHitBullet;
    private boolean bulletMissed;
    private boolean hasRobotDied;
    private String deadRobotName;
    private boolean sleeping = false;
    private Robot robot;
    private int width;
    private int height;
    private BattleField battleField;
    private BoundingRectangle boundingBox;
    private Arc2D.Double scanArc;
    private double scanRadius = 1200;
    private boolean adjustGunForBodyTurn = false;
    private boolean adjustRadarForGunTurn = false;
    private volatile boolean dead = false;
    //private java.awt.geom.Line2D.Double scanLine;
    private volatile boolean running = false;
    private double maxScanRadius = 1000;
    private boolean scan = false;
    private boolean winner = false;
    private Battle battle;
    private Condition waitCondition = null;
    private boolean adjustRadarForBodyTurn = false;
    private boolean adjustRadarForBodyTurnSet = false;
    private double energy;
    private double gunHeat = 0;
    private boolean halt = false;
    private boolean inCollision = false;
    private String name = null;
    private String nonVersionedName = null;
    private int setCallCount = 0;
    private int getCallCount = 0;
    private RobotClassManager robotClassManager = null;
    private RobotFileSystemManager robotFileSystemManager = null;
    private RobotThreadManager robotThreadManager = null;
    private String shortName = null;
    private int skippedTurns = 0;
    private RobotStatistics statistics;
    //private Object monitor = new Object();
    private int colorIndex = -1;
    private int setColorRoundNum = -1;
    private RobotMessageManager messageManager = null;
    //private RobotRepositoryManager robotManager = null;
    private ImageManager imageManager = null;
    private TeamPeer teamPeer = null;
    private boolean droid = false;
    private TextPeer sayTextPeer = null;
    private boolean duplicate = false;
    private boolean testingCondition = false;
    private BulletPeer newBullet = null;
    private boolean ioRobot = false;

    /**
     * RobotPeer constructor
     */
    public RobotPeer(RobotClassManager robotClassManager, RobotRepositoryManager robotManager, long fileSystemQuota) {
        super();
        this.robotClassManager = robotClassManager;
        robotThreadManager = new RobotThreadManager(this);
        robotFileSystemManager = new RobotFileSystemManager(this, fileSystemQuota);
        boundingBox = new BoundingRectangle();
        scanArc = new Arc2D.Double();
        //scanLine = new java.awt.geom.Line2D.Double();
        imageManager = robotManager.getImageManager();
        this.teamPeer = robotClassManager.getTeamManager();
        // Create statistics after teamPeer set
        statistics = new RobotStatistics(this);
        scannedObjectEvent = new ScannedObjectEvent(0.0, 0.0, false);
        scannedRobotEvents = new Vector<ScannedRobotEvent>();
        hitObjectEvent = new HitObjectEvent();
        hitByBulletEvent = new HitByBulletEvent();
        bulletHitEvent = new BulletHitEvent();
        hitRobotEvent = new HitRobotEvent();
    }

    /*
     * method for determining if an arc intersects some point on a rectangle
     */
    public static boolean intersects(Arc2D arc, Rectangle2D rect) {
        // This part checks just the end of the arc


        if (rect.intersectsLine(arc.getEndPoint().getX(), arc.getEndPoint().getY(), arc.getStartPoint()
                .getX(), arc.getStartPoint().getY())) {
            return true;
        }

        // This checks from the center to the arc.
        return arc.intersects(rect);
    }

    public static double scanDiff(double currentRadarHeading, double lastRadarHeading) {
        // get the angle of the scan arc (-ve if moving clockwise, +ve if moving counter-clockwise)
        // since there is no way to know if the radar swung around the long or the short way, we will always
        // assume that it followed the shorter arc
        double scanDiff = currentRadarHeading - lastRadarHeading;
        if (scanDiff > Math.PI) {
            scanDiff -= Math.PI;
            scanDiff *= -1;
        } else if (scanDiff < -Math.PI) {
            scanDiff += Math.PI;
            scanDiff *= -1;
        }

        return scanDiff;
    }

    public static double scanStart(double currentRadarHeading, double lastRadarHeading) {
        // find the right-most angle so the arc can be build counter-clockwise
        if (scanDiff(currentRadarHeading, lastRadarHeading) <= 0) {
            return currentRadarHeading;
        } else {
            return lastRadarHeading;
        }
    }

    public static double scanExtent(double currentRadarHeading, double lastRadarHeading) {
        return Math.abs(scanDiff(currentRadarHeading, lastRadarHeading));
    }

    // takes angles where 0rads=East and converts them to frame where 0rads=North
    public static double shiftAngleFrameFromEastToNorth(double originalAngle) {
        double shiftedAngle;
        if (originalAngle >= Math.PI / 2) {
            shiftedAngle = originalAngle - Math.PI / 2;
        } else {
            shiftedAngle = originalAngle + Math.PI * 3 / 2;
        }
        return shiftedAngle;
    }

    // Math.atan2 returns negative values if point x,y is in either of the lower quadrants
    // we want positive values all the way around so this function returns the correct value
    // note value returned is in radians with frame 0rad=East and angles increase counterclockwise
    public static double atan2FixedFrame(double y, double x) {
        double atan2Angle = Math.atan2(y, x);
        if (atan2Angle >= 0) {
            return atan2Angle;
        } else {
            double complement = Math.PI + atan2Angle;
            return Math.PI + complement;
        }
    }

    public static double bearing(double angle, double heading) {
        double bearing = angle - heading;
        if (bearing < 0.0) {
            bearing = bearing + (2 * Math.PI);
        }
        return bearing;
    }

    // Accepts angles in radians
    // automatically corrects for vertically flipped bounding box on arc
    public static Arc2D makeArc(double robotX, double robotY, double maxScanRadius, double start, double extent, double battleFieldHeight) {
        /*
         * @link:https://docs.oracle.com/javase/7/docs/api/java/awt/geom/Arc2D.Double.html#Arc2D.Double(double,%20double,%20double,%20double,%20double,%20double,%20int)
         * public Arc2D.Double(double x, double y, double w, double h, double start, double extent, int type)
         * Constructs a new arc, initialized to the specified location, size, angular extents, and closure type.
         * Parameters:
         * x - The X coordinate of the upper-left corner of the arc's framing rectangle.
         * y - The Y coordinate of the upper-left corner of the arc's framing rectangle. [note upper-left corner is required while robocode coordinates are from lower-left corner]
         * w - The overall width of the full ellipse of which this arc is a partial section.
         * h - The overall height of the full ellipse of which this arc is a partial section.
         * start - The starting angle of the arc in degrees. [framed with 0 pointing north]
         * extent - The angular extent of the arc in degrees. [proceeds clockwise from start]
         * type - The closure type for the arc: Arc2D.OPEN, Arc2D.CHORD, or Arc2D.PIE.
         */
        return new Arc2D.Double(robotX - maxScanRadius, (battleFieldHeight - robotY) - maxScanRadius, 2 * maxScanRadius,
                2 *
                        maxScanRadius, Math.toDegrees(start), Math.toDegrees(extent), Arc2D.PIE);
    }

    public TextPeer getSayTextPeer() {
        return sayTextPeer;
    }

    public synchronized boolean isIORobot() {
        return ioRobot;
    }

    public synchronized void setIORobot(boolean ioRobot) {
        this.ioRobot = ioRobot;
    }

    public synchronized boolean getTestingCondition() {
        return testingCondition;
    }

    public synchronized void setTestingCondition(boolean testingCondition) {
        this.testingCondition = testingCondition;
    }

    public boolean isDroid() {
        return droid;
    }

    public void setDroid(boolean droid) {
        this.droid = droid;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 6:52:26 PM)
     */
    public void checkRobotCollision() {

        double ramDamage = .6;
        this.inCollision = false;
        for (int i = 0; i < battle.getRobots().size(); i++) {
            RobotPeer r = battle.getRobots().elementAt(i);
            if (r != null && r != this && !r.isDead()) {
                // If we hit
                if (getBoundingBox().intersects(r.getBoundingBox())) {
                    // Bounce back
                    double angle, dx, dy;
                    dx = r.getX() - x;
                    dy = r.getY() - y;
                    angle = Math.atan2(dx, dy);
                    double movedx, movedy;
                    movedx = velocity * Math.cos(heading);
                    movedy = velocity * Math.sin(heading);

                    boolean atFault = false;
                    double bearing = Utils.normalRelativeAngle(heading - angle);
                    if (velocity > 0 && bearing > -Math.PI / 2 && bearing < Math.PI / 2) {
                        // I'm moving forwards toward him!
                        velocity = 0;
                        atFault = true;
                        getRobotStatistics().scoreRammingDamage(i, ramDamage);
                        this.setEnergy(energy - ramDamage);
                        r.setEnergy(r.energy - ramDamage);
                        r.getRobotStatistics().damagedByRamming(ramDamage);
                        this.inCollision = true;
                        x -= movedx;
                        y -= movedy;

                        if (r.getEnergy() == 0) {
                            if (!r.isDead()) {
                                r.setDead(true);
                                getRobotStatistics().scoreKilledEnemyRamming(i);
                            }
                        }
                    } else if (velocity < 0 && (bearing < -Math.PI / 2 || bearing > Math.PI / 2)) {
                        // I'm moving backwards toward him!
                        velocity = 0;
                        atFault = true;
                        getRobotStatistics().scoreRammingDamage(i, ramDamage);
                        this.setEnergy(energy - ramDamage);
                        r.setEnergy(r.energy - ramDamage);
                        r.getRobotStatistics().damagedByRamming(ramDamage);
                        this.inCollision = true;
                        x -= movedx;
                        y -= movedy;

                        if (r.getEnergy() == 0) {
                            if (!r.isDead()) {
                                r.setDead(true);
                                getRobotStatistics().scoreKilledEnemyRamming(i);
                            }
                        }
                    } else {
                        // Do nothing, I'm just moving.
                    }

                    setHitRobotEvent(r.getName(), bearing, r.getEnergy(), atFault);
                    r.setHitRobotEvent(getName(), Utils.normalRelativeAngle(r.heading -
                            (Math.PI + angle)), getEnergy(), false);
                } // if hit
            } // if robot active & not me
        } // for robots
    }

    public void checkObjectCollision() {
        boolean hitObject = false;
        double fixx = 0.0, fixy = 0.0;
        double angle = 0.0;
//		hitObjectEvent.setHitObject(false);

        // First check for wall hits then check for map object hits.
        hitObject = checkWallCollision();
        if (hitObject) {
            hitObjectEvent.setHitObject(true);
        } else {
            // Map object hits
            for (int i = 0; i < battle.getObjects().size(); i++) {
                MapObject mo = battle.getObjects().elementAt(i);
                if (mo != null) {
                    if (getBoundingBox().intersects(mo.getBoundingBox())) {
                        Line2D[] lines = {mo.top, mo.left, mo.bottom, mo.right};
                        for (int k = 0; k < lines.length; k++) {
                            if (lines[k].intersects(boundingBox)) {
                                hitObject = true;
                                double dist = lines[k].ptLineDist(boundingBox.getCenterX(), boundingBox.getCenterY());
                                if (lines[k] == mo.top) {
                                    fixy = (boundingBox.height / 2) - dist;
                                    angle = Utils.normalRelativeAngle(heading - Math.PI);
                                    hitObjectEvent.setHitObject(true);
                                    hitObjectEvent.setBearingRadians(angle);
                                } else if (lines[k] == mo.bottom) {
                                    fixy = dist - (boundingBox.height / 2);
                                    angle = Utils.normalRelativeAngle(heading);
                                    hitObjectEvent.setHitObject(true);
                                    hitObjectEvent.setBearingRadians(angle);
                                } else if (lines[k] == mo.left) {
                                    fixx = dist - (boundingBox.width / 2);
                                    angle = Utils.normalRelativeAngle(heading - 3 * Math.PI / 2);
                                    hitObjectEvent.setHitObject(true);
                                    hitObjectEvent.setBearingRadians(angle);
                                } else if (lines[k] == mo.right) {
                                    fixx = (boundingBox.width / 2) - dist;
                                    angle = Utils.normalRelativeAngle(heading - Math.PI / 2);
                                    hitObjectEvent.setHitObject(true);
                                    hitObjectEvent.setBearingRadians(angle);
                                }
                            }
                        }
                        if (hitObject) {
                            double velocity1 = 0, velocity2 = 0;
                            if (Math.abs(Math.cos(heading)) > .00001 && fixx != 0) {
                                velocity1 = fixx / Math.cos(heading);
                            } else {
                                velocity1 = 0;
                            }

                            if (Math.abs(Math.sin(heading)) > .00001 && fixy != 0) {
                                velocity2 = fixy / Math.sin(heading);
                            } else {
                                velocity2 = 0;
                            }

                            double fixv = 0;
                            if (Math.max(Math.abs(velocity1), Math.abs(velocity2)) == Math.abs(velocity1)) {
                                fixv = velocity1;
                            } else {
                                fixv = velocity2;
                            }

                            double dx = fixv * Math.cos(heading);
                            double dy = fixv * Math.sin(heading);

                            // Sanity
                            if (Math.abs(dx) < Math.abs(fixx)) {
                                dx = fixx;
                            }
                            if (Math.abs(dy) < Math.abs(fixy)) {
                                dy = fixy;
                            }

                            // IF THIS IS NOT HERE
                            // STRANGE THINGS HAPPEN UNDER IBM JAVA 1.4
                            // ?????
                            if (Double.isNaN(velocity1)) {
                            }
                            if (Double.isNaN(velocity2)) {
                            }

                            x += dx;
                            y += dy;

                            // Update energy, but do not reset inactiveTurnCount
                            if (robot instanceof robocode.AdvancedRobot) {
                                this.setEnergy(energy - (Math.max(Math.abs(velocity) * .5 - 1, 0)), false);
                            }

                            updateBoundingBox();

                            velocity = 0.0;
                            desiredVelocity = 0.0;
                        }
                    }
                }
            }
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 6:52:26 PM)
     */
    private boolean checkWallCollision() {
        double fixx = 0.0, fixy = 0.0;
        double angle = 0.0;
        boolean hitWall = false;

        //if it gets to the right edge
        if (boundingBox.x + boundingBox.width > battleField.getBoundingBox().x + battleField.getBoundingBox().width) {
            fixx =
                    battleField.getBoundingBox().x + battleField.getBoundingBox().width -
                            boundingBox.width -
                            boundingBox.x -
                            .001;
            angle = Utils.normalRelativeAngle(heading - Math.PI / 2);
            hitWall = true;
            hitObjectEvent.setBearingRadians(angle);
        }

        //if it gets to the left edge
        if (boundingBox.x < battleField.getBoundingBox().x) {
            fixx = battleField.getBoundingBox().x - boundingBox.x + .001;
            angle = Utils.normalRelativeAngle(heading - 3 * Math.PI / 2);
            hitWall = true;
            hitObjectEvent.setBearingRadians(angle);
        }

        //if it gets to the top
        if (boundingBox.y + boundingBox.height > battleField.getBoundingBox().y + battleField.getBoundingBox().height) {
            fixy =
                    battleField.getBoundingBox().y + battleField.getBoundingBox().height -
                            getBoundingBox().height -
                            getBoundingBox().y -
                            .001;
            angle = Utils.normalRelativeAngle(heading);
            hitWall = true;
            hitObjectEvent.setBearingRadians(angle);
        }

        //if it gets to the bottom
        if (boundingBox.y < battleField.getBoundingBox().y) {
            fixy = battleField.getBoundingBox().y - boundingBox.y + .001;
            angle = Utils.normalRelativeAngle(heading - Math.PI);
            hitWall = true;
            hitObjectEvent.setBearingRadians(angle);
        }

        if (hitWall) {
            double velocity1 = 0, velocity2 = 0;
            if (Math.abs(Math.cos(heading)) > .00001 && fixx != 0) {
                velocity1 = fixx / Math.cos(heading);
            } else {
                velocity1 = 0;
            }

            if (Math.abs(Math.sin(heading)) > .00001 && fixy != 0) {
                velocity2 = fixy / Math.sin(heading);
            } else {
                velocity2 = 0;
            }

            double fixv = 0;
            if (Math.max(Math.abs(velocity1), Math.abs(velocity2)) == Math.abs(velocity1)) {
                fixv = velocity1;
            } else {
                fixv = velocity2;
            }

            double dx = fixv * Math.cos(heading);
            double dy = fixv * Math.sin(heading);

            // Sanity
            if (Math.abs(dx) < Math.abs(fixx)) {
                dx = fixx;
            }
            if (Math.abs(dy) < Math.abs(fixy)) {
                dy = fixy;
            }

            // IF THIS IS NOT HERE
            // STRANGE THINGS HAPPEN UNDER IBM JAVA 1.4
            // ?????
            if (Double.isNaN(velocity1)) {
            }
            if (Double.isNaN(velocity2)) {
            }

            x += dx;
            y += dy;

            // Update energy, but do not reset inactiveTurnCount
            if (robot instanceof robocode.AdvancedRobot) {
                this.setEnergy(energy - (Math.max(Math.abs(velocity) * .5 - 1, 0)), false);
            }

            updateBoundingBox();

            velocity = 0.0;
            desiredVelocity = 0.0;
        }
        return hitWall;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/14/2000 4:31:19 PM)
     */
    public final void death() {
        throw new DeathException();
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 3:33:11 PM)
     *
     * @return robocode.Battle
     */
    public Battle getBattle() {
        return battle;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 3:33:11 PM)
     *
     * @param newBattle robocode.Battle
     */
    public void setBattle(Battle newBattle) {
        battle = newBattle;

    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 7:00:24 PM)
     *
     * @return robocode.BattleField
     */
    public BattleField getBattleField() {
        return battleField;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 7:00:24 PM)
     *
     * @param newBattleField robocode.BattleField
     */
    public void setBattleField(BattleField newBattleField) {
        battleField = newBattleField;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 3:34:38 PM)
     *
     * @return double
     */
    public synchronized double getBattleFieldHeight() {
        return battle.getBattleField().getHeight();
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 3:34:38 PM)
     *
     * @return double
     */
    public synchronized double getBattleFieldWidth() {
        return battle.getBattleField().getWidth();
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/23/2000 4:14:33 PM)
     *
     * @return BoundingRectangle
     */
    public synchronized BoundingRectangle getBoundingBox() {
        return boundingBox;
    }

    /**
     * Returns the current X position of the robot
     *
     * @return double
     */
    public synchronized double getX() {
        return x;
    }

    /**
     * Directly sets the X Location. Not bounded by physics engine.
     *
     * @param newX double
     */
    public synchronized void setX(double newX) {
        x = newX;
    }

    /**
     * Returns the current Y position of the robot
     *
     * @return double
     */
    public synchronized double getY() {
        return y;
    }

    /**
     * Directly sets the Y Location. Not bounded by physics engine.
     *
     * @param newY double
     */
    public synchronized void setY(double newY) {
        y = newY;
    }

    /**
     * Returns the heading of the robot [0..2*PI]. 0 is to the right of the screen, 0.5*PI is to the top of the screen.
     *
     * @return double current robot heading, in radians
     */
    public synchronized double getHeading() {
        return heading;
    }

    /**
     * Directly sets the robot heading. Not bounded by physics engine.
     *
     * @param newHeading double the new heading for the robot
     */
    public synchronized void setHeading(double newHeading) {
        heading = newHeading;
    }

    /**
     * Returns the heading of the gun [0..2*PI]. 0 is the the right of the screen, 0.5*Pi is to the top.
     * I thought about doing this in terms of the robot frame (which is how the robot would work), but it
     * seemed kind of silly since all that would happen is the function would just be reversed.
     *
     * @return double current gun heading, in radians
     */
    public synchronized double getGunHeading() {
        return gunHeading;
    }

    /**
     * Directly sets the gun heading. Not bounded by physics engine.
     *
     * @param newGunHeading double the new heading for the gun
     */
    public synchronized void setGunHeading(double newGunHeading) {
        gunHeading = newGunHeading;
    }

    /**
     * Returns the heading of the radar [0..2*PI]. 0 is the the right of the screen, 0.5*Pi is to the top.
     *
     * @return double current radar heading, in radians
     */
    public synchronized double getRadarHeading() {
        return radarHeading;
    }

    /**
     * Directly sets the gun heading. Not bounded by physics engine.
     *
     * @param newRadarHeading double the new heading for the radar
     */
    public synchronized void setRadarHeading(double newRadarHeading) {
        radarHeading = newRadarHeading;
    }

    /**
     * Returns the height of the robot
     *
     * @return int height of robot, in pixels
     */
    public synchronized int getHeight() {
        return height;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 3:18:05 PM)
     *
     * @param newHeight int
     */
    public synchronized void setHeight(int newHeight) {
        height = newHeight;
    }

    /**
     * Returns the width of the robot
     *
     * @return int width of robot, in pixels
     */
    public synchronized int getWidth() {
        return width;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 3:17:56 PM)
     *
     * @param newWidth int
     */
    public synchronized void setWidth(int newWidth) {
        width = newWidth;
    }

    /**
     * Returns the name of the robot.
     *
     * @return java.lang.String robot's name
     */
    public synchronized String getName() {
        if (name == null) {
            return robotClassManager.getClassNameManager().getFullClassNameWithVersion();
        } else {
            return name;
        }
    }

    public synchronized String getNonVersionedName() {
        if (nonVersionedName == null) {
            return robotClassManager.getClassNameManager().getFullClassName();
        } else {
            return nonVersionedName;
        }
    }

    /**
     * Returns the number of active robots
     *
     * @return int which is the count of the other active robots
     */
    public synchronized int getOthers() {
        if (!isDead()) {
            return battle.getActiveRobots() - 1;
        } else {
            return battle.getActiveRobots();
        }
    }

    public synchronized boolean getBulletMissed() {
        return bulletMissed;
    }

    public synchronized void setBulletMissed(boolean value) {
        bulletMissed = value;
    }

    public synchronized boolean getBulletHitBullet() {
        return bulletHitBullet;
    }

    public synchronized void setBulletHitBullet(boolean value) {
        bulletHitBullet = value;
    }

    public synchronized void robotDeath(String name) {
        hasRobotDied = true;
        deadRobotName = name;
    }

    public synchronized void clearRobotDeath() {
        hasRobotDied = false;
    }

    public synchronized String getDeadRobotName() {
        return deadRobotName;
    }

    public synchronized boolean getRobotDeath() {
        return hasRobotDied;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/24/2000 12:34:06 PM)
     *
     * @return boolean
     */
    public synchronized boolean isAdjustGunForBodyTurn() {
        return adjustGunForBodyTurn;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/24/2000 12:34:06 PM)
     *
     * @param newAdjustGunForBodyTurn boolean
     */
    public synchronized void setAdjustGunForBodyTurn(boolean newAdjustGunForBodyTurn) {
        adjustGunForBodyTurn = newAdjustGunForBodyTurn;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/24/2000 12:34:24 PM)
     *
     * @return boolean
     */
    public synchronized boolean isAdjustRadarForGunTurn() {
        return adjustRadarForGunTurn;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/24/2000 12:34:24 PM)
     *
     * @param newAdjustRadarForGunTurn boolean
     */
    public synchronized void setAdjustRadarForGunTurn(boolean newAdjustRadarForGunTurn) {
        adjustRadarForGunTurn = newAdjustRadarForGunTurn;
        if (!adjustRadarForBodyTurnSet) {
            adjustRadarForBodyTurn = newAdjustRadarForGunTurn;
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/29/2000 9:47:51 AM)
     *
     * @return boolean
     */
    public synchronized boolean isDead() {
        return dead;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/29/2000 9:47:51 AM)
     *
     * @param dead boolean
     */
    public synchronized void setDead(boolean dead) {
        if (dead) {
            battle.resetInactiveTurnCount(10.0);
            if (!this.dead) {
                if (this.isTeamLeader()) {
                    for (int i = 0; i < teamPeer.size(); i++) {
                        RobotPeer teammate = teamPeer.elementAt(i);
                        if (!teammate.isDead() && teammate != this) {
                            teammate.setEnergy(teammate.getEnergy() - 30);
                            BulletPeer sBullet = new BulletPeer(this, battle);
                            sBullet.setX(teammate.getX());
                            sBullet.setY(teammate.getY());
                            sBullet.setVictim(teammate);
                            sBullet.hitVictim = true;
                            sBullet.setPower(4);
                            sBullet.setActive(false);
                            battle.addBullet(sBullet);
                        }
                    }
                }
                battle.generateDeathEvents(this);
                // 'fake' bullet for explosion on self
                BulletPeer sBullet = new ExplosionPeer(this, battle);
                sBullet.setX(x);
                sBullet.setY(y);
                battle.addBullet(sBullet);
            }
            this.setEnergy(0.0);
        }
        this.dead = dead;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 12:34:06 PM)
     */
    public void run() {

        setRunning(true);

        try {
            if (robot != null) {
                robot.run();
            }
//			while (true) tick();
            while (true) ;

        } catch (DeathException e) {
            out.println("SYSTEM: " + getName() + " has died");
        } catch (WinException e) {
        } catch (DisabledException e) {
            setEnergy(0);
            String msg = e.getMessage();
            if (msg == null) {
                msg = "";
            } else {
                msg = ": " + msg;
            }
            out.println("SYSTEM: Robot disabled" + msg);
        } catch (Exception e) {
            out.println(getName() + ": Exception: " + e);
            out.printStackTrace(e);
        } catch (Throwable t) {
            if (!(t instanceof ThreadDeath)) {
                out.println(getName() + ": Throwable: " + t);
                out.printStackTrace(t);
            } else {
                log(getName() + " stopped successfully.");
            }
        }
        setRunning(false);
        // If battle is waiting for us, well, all done!
        synchronized (this) {
            this.notify();
        }
    }

    public Rectangle2D getScannableBoundingBox() {

        Rectangle2D scannableBoundingBox = (Rectangle2D) getBoundingBox().clone();

        scannableBoundingBox.setRect(x - width / 2 + 4, (getBattleFieldHeight() - y) - height / 2 + 4, width -
                8, height - 8);

        return scannableBoundingBox;
    }

    public boolean isObjectBlockingViewTo(RobotPeer r) {

        Line2D.Double
                centerToCenter =
                new Line2D.Double(this.x, this.getBattleFieldHeight() - this.y, r.x, this.getBattleFieldHeight() - r.y);

        for (int i = 0; i < battle.getObjects().size(); i++) {
            MapObject mo = battle.getObjects().elementAt(i);
            if (mo != null) {
                if (centerToCenter.intersects(mo.getBoundingBox())) {
                    return true;
                }
            }
        }
        return false;
    }

    public Arc2D makeArc(double start, double extent) {
        return makeArc(this.getX(), this.getY(), this.maxScanRadius, start, extent, this.getBattleFieldHeight());
    }

    /**
     * Scan around the robot to find other robots and obstacles. All returns for distances are the leading edge of
     * the radar arc.
     * Creation date: (12/23/2000 5:59:25 PM)
     * Modified (6/18/2007) to include scan obstruction by objects
     * Modified (10/25/2019) to fix intersection detection with robot boundingBoxes
     */
    public void scan() {

        scannedObjectEvent.setActive(false);

        if (isDroid()) {
            return;
        }

        double scanStart = scanStart(getRadarHeading(), getLastRadarHeading());
        double scanExtent = scanExtent(getRadarHeading(), getLastRadarHeading());

        scanArc.setArc(makeArc(scanStart, scanExtent));

        // do not scan through objects
        double newScanRadius = maxScanRadius;
        boolean objecthit = false;
        for (int i = 0; i < battle.getObjects().size(); i++) {
            MapObject mo = battle.getObjects().elementAt(i);
            if (mo != null) {
                if (intersects(scanArc, mo.getBoundingBox())) {
                    Line2D.Double
                            arcLine =
                            new Line2D.Double(this.x, this.y, scanArc.getEndPoint().getX(), scanArc.getEndPoint()
                                    .getY());
                    // make sure scan is blocked by closest object
                    if (getIntersectionLine(arcLine, mo) < newScanRadius) {
                        newScanRadius = getIntersectionLine(arcLine, mo);
                    }
                    double bearing = bearing(radarHeading, heading);
                    scannedObjectEvent.setBearing(bearing);
                    scannedObjectEvent.setDistance(newScanRadius);
                    scannedObjectEvent.setActive(true);
                    //eventManager.add(new ScannedObjectEvent(Utils.normalRelativeAngle(heading - radarHeading),newScanRadius));
                    objecthit = true;
                }
            }
        }

        // if we didn't hit an object, how far is it to the wall? Count the wall as an obstacle.
        if (!objecthit) {
            Line2D.Double
                    arcLine =
                    new Line2D.Double(this.x, (this.getBattleFieldHeight() - this.y), scanArc.getEndPoint()
                            .getX(), scanArc.getEndPoint().getY());
            newScanRadius = getIntersectionLine(arcLine, battleField.getBoundingBox());
            if (newScanRadius < maxScanRadius) {
                double bearing = bearing(radarHeading, heading);
                scannedObjectEvent.setBearing(bearing);
                scannedObjectEvent.setDistance(newScanRadius);
                scannedObjectEvent.setActive(true);
//				eventManager.add(new ScannedObjectEvent(Utils.normalRelativeAngle(heading - radarHeading),newScanRadius));
            }
        }

        //get information about scanned robot
        scannedRobotEvents.clear();
        for (int i = 0; i < battle.getRobots().size(); i++) {
            RobotPeer r = battle.getRobots().elementAt(i);
            if (r != null && r != this && !r.isDead()) {
                // checks that 1) r is in scanned area and 2) either no objects were in the scan area or at least no objects are blocking the scan view to r
                if (intersects(scanArc, r.getScannableBoundingBox()) && !isObjectBlockingViewTo(r)) {
                    double dx, dy, angle, dist;
                    dx = r.getX() - x;
                    dy = r.getY() - y;
                    dist = Math.sqrt(dx * dx + dy * dy);
                    angle = Math.atan2(dy, dx); // returns clockwise rotation
                    if (dy < 0.0) {
                        angle = angle + (2 * Math.PI);
                    }
                    double bearing = angle - heading;
                    if (bearing < 0.0) {
                        bearing = bearing + (2 * Math.PI);
                    }
                    scannedRobotEvents.add(new ScannedRobotEvent(r.getName(), r.energy, bearing, dist, r.getHeading(), r
                            .getVelocity()));
                }
            }
        }
    }

    /*
     * Function for determining the distance to the nearest scanned object.
     * This distance is then used to determine the length of the scanArc so
     * that it does not penetrate any objects.
     */
    public double getIntersectionLine(Line2D.Double arc, MapObject mo) {
        double nr, r = maxScanRadius;
        //Line2D.Double intersectionLine = new Line2D.Double();
        Line2D.Double[] lines = {mo.top, mo.right, mo.bottom, mo.left};
        for (int i = 0; i < lines.length; i++) {
            if (arc.intersectsLine(lines[i])) {
                Point2D.Double l = getIntersectionPoint(lines[i], arc);
                Line2D.Double scanLine = new Line2D.Double(x, y, l.x, l.y);
                nr =
                        Math.sqrt((scanLine.x2 - scanLine.x1) * (scanLine.x2 - scanLine.x1) +
                                (scanLine.y2 - scanLine.y1) * (scanLine.y2 - scanLine.y1));
                if (nr < r) {
                    r = nr;
                }
            }
        }
        return r;
    }

    /*
     * Function for determining the distance to the nearest scanned object.
     * This distance is then used to determine the length of the scanArc so
     * that it does not penetrate any objects.
     */
    public double getIntersectionLine(Line2D.Double arc, BoundingRectangle mo) {
        double nr, r = maxScanRadius;
        //Line2D.Double intersectionLine = new Line2D.Double();
        Line2D.Double top = new Line2D.Double(mo.x, mo.y + mo.height, mo.x + mo.width, mo.y + mo.height);
        Line2D.Double bottom = new Line2D.Double(mo.x, mo.y, mo.x + mo.width, mo.y);
        Line2D.Double left = new Line2D.Double(mo.x, mo.y, mo.x, mo.y + mo.height);
        Line2D.Double right = new Line2D.Double(mo.x + mo.width, mo.y, mo.x + mo.width, mo.y + mo.height);
        Line2D.Double[] lines = {top, left, right, bottom};
        for (int i = 0; i < lines.length; i++) {
            if (arc.intersectsLine(lines[i])) {
                Point2D.Double l = getIntersectionPoint(lines[i], arc);
                Line2D.Double scanLine = new Line2D.Double(x, y, l.x, l.y);
                nr =
                        Math.sqrt((scanLine.x2 - scanLine.x1) * (scanLine.x2 - scanLine.x1) +
                                (scanLine.y2 - scanLine.y1) * (scanLine.y2 - scanLine.y1));
                if (nr < r) {
                    r = nr;
                }
            }
        }
        return r;
    }

    /*
     * Function for finding the point of intersection between two lines.
     *
     * @param line1 first line
     * @param line2 second line
     * @return (x,y) the point of intersection
     */
    public Point2D.Double getIntersectionPoint(Line2D.Double line1, Line2D.Double line2) {

        double a1 = 0, b1 = 0, a2 = 0, b2 = 0, x = 0, y = 0;
        if (line1.y2 == line1.y1) {
            a1 = 0;
            b1 = line1.y1;
        } else if (line1.x2 == line1.x1) {
            a1 = 0;
            b1 = 0;
        } else {
            a1 = (line1.y2 - line1.y1) / (line1.x2 - line1.x1);
            b1 = line1.y1 - a1 * line1.x1;
        }

        if (line2.y2 == line2.y1) {
            a2 = 0;
            b2 = line2.y1;
        } else if (line2.x2 == line2.x1) {
            a2 = 0;
            b2 = 0;
        } else {
            a2 = (line2.y2 - line2.y1) / (line2.x2 - line2.x1);
            b2 = line2.y1 - a2 * line2.x1;
        }

//		 y = a1x + b1
//		 y = a2x + b2
//		 a1x + b1 = a2x + b2
//		 (a1 - a2)x = b2 - b1

        if (line1.x1 != line1.x2) {
            x = (b2 - b1) / (a1 - a2);
        } else {
            x = line1.x1;
        }
        y = a2 * x + b2;

        return new Point2D.Double(x, y);
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/24/2000 12:34:06 PM)
     *
     * @param
     */
    public ScannedObjectEvent getScannedObjectEvent() {
        return scannedObjectEvent;
    }

    public Vector<ScannedRobotEvent> getScannedRobotEvents() {
        return scannedRobotEvents;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/24/2000 12:34:06 PM)
     *
     * @param newAdjustGunForBodyTurn boolean
     */
    public HitObjectEvent getHitObjectEvent() {
        return hitObjectEvent;
    }

    public HitByBulletEvent getHitByBulletEvent() {
        return hitByBulletEvent;
    }

    public void setHitByBulletEvent(double bearing, Bullet bullet) {
        hitByBulletEvent.setHitByBulletEvent(bearing, bullet);
    }

    public BulletHitEvent getBulletHitEvent() {
        return bulletHitEvent;
    }

    public void setBulletHitEvent(String name, double energy, Bullet bullet) {
        bulletHitEvent.setBulletHitEvent(name, energy, bullet);
    }

    public HitRobotEvent getHitRobotEvent() {
        return hitRobotEvent;
    }

    public void setHitRobotEvent(String name, double bearing, double energy, boolean atFault) {
        hitRobotEvent.setHitRobotEvent(name, bearing, energy, atFault);
    }

    public void clearHitRobotEvent() {
        hitRobotEvent.clearHitRobotEvent();
    }

    public synchronized void preInitialize() {
        this.dead = true;
    }

    /**
     * Sets all turn and movment rates to 0. This method is subject
     * to the physics engine.  It does not reset the location, energy
     * or headings of the robot.
     */
    public final synchronized void allStop() {
        desiredVelocity = 0.0;
        desiredTurnRate = 0.0;
        desiredGunTurnRate = 0.0;
        desiredRadarTurnRate = 0.0;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/14/2000 3:39:32 PM)
     */
    public final void tick() {
        if (newBullet != null) {
            battle.addBullet(newBullet);
            newBullet = null;
        }


        //log("Entering tick.");
        if (Thread.currentThread() != robotThreadManager.getRunThread()) {
            throw new RobotException("You cannot take action in this thread!");
        }
        if (getTestingCondition()) {
            throw new RobotException("You cannot take action inside Condition.test().  You should handle onCustomEvent instead.");
        }

        setSetCallCount(0);
        setGetCallCount(0);

        // This stops autoscan from scanning...
        if (waitCondition != null && waitCondition.test() == true) {
            waitCondition = null;
        }

        // If we are stopping, yet the robot took action (in onWin or onDeath), stop now.
        if (halt) {
            if (isDead()) {
                death();
            } else if (isWinner()) {
                throw new WinException();
            }
        }

        synchronized (this) {
            // Notify the battle that we are now asleep.
            // This ends any pending wait() call in battle.runRound().
            // Should not actually take place until we release the lock in wait(), below.
            this.notify();
            sleeping = true;
            //log("Notifying battle that we're asleep");
            //log("Sleeping and waiting for battle to wake us up.");
            try {
                this.wait(1200); // attempt to catch bug.
            } catch (InterruptedException e) {
                log("Wait interrupted");
            }
            sleeping = false;

            // Notify battle thread, which is waiting in
            // our wakeup() call, to return.
            // It's quite possible, by the way, that we'll be back in sleep (above)
            // before the battle thread actually wakes up
            this.notify();
        }

        if (isDead()) {
            halt();
        }

        out.resetCounter();
    }

    /**
     * Returns the current velocity of the robot.
     *
     * @return double the velocity of the robot, in distance/tick
     */
    public synchronized double getVelocity() {
        return velocity;
    }

    /**
     * Allows the robot's target velocity to be specified.
     * Boundary checking occurs that clips invalid values to their
     * closest allowable value. (i.e. setVelocity(-1000.0) will set
     * the robot's target velocity to -8, the maximum negative value)
     *
     * @param velocity double
     */
    public synchronized void setVelocity(double velocity) {
        if (getEnergy() == 0) {
            return;
        }
        // Do a little boundary checking
        if (velocity < -maxVelocity) {
            velocity = -maxVelocity;
        }
        if (velocity > maxVelocity) {
            velocity = maxVelocity;
        }
        desiredVelocity = velocity;
    }

    /**
     * Returns the current turn rate of the robot.
     *
     * @return double the turn rate of the chassie, in radians/tick
     */
    public synchronized double getTurnRate() {
        return turnRate;
    }

    /**
     * Returns the current turn rate of the gun.
     *
     * @return double the turn rate of the gun, in radians/tick
     */
    public double getGunTurnRate() {
        return gunTurnRate;
    }

    /**
     * Sets the turn rate of the gun.
     *
     * @param turnRate double is the gun turn rate, in radians/tick
     */
    public synchronized void setGunTurnRate(double turnRate) {
        if (getEnergy() == 0) {
            return;
        }
//		Use RHR
//		turnRate = -turnRate;

        // Do a little boundary checking
        if (turnRate < -maxGunTurnRate) {
            turnRate = -maxGunTurnRate;
        }
        if (turnRate > maxGunTurnRate) {
            turnRate = maxGunTurnRate;
        }
        desiredGunTurnRate = turnRate;
    }

    /**
     * Returns the current turn rate of the radar.
     *
     * @return double the turn rate of the radar, in radians/tick
     */
    public synchronized double getRadarTurnRate() {
        return radarTurnRate;
    }

    /**
     * Sets the turn rate of the radar.
     *
     * @param turnRate double is the radar turn rate, in radians/tick
     */
    public synchronized void setRadarTurnRate(double turnRate) {
        if (getEnergy() == 0) {
            return;
        }
//		Use RHR
//		turnRate = -turnRate;
        // Do a little boundary checking
        if (turnRate < -maxRadarTurnRate) {
            turnRate = -maxRadarTurnRate;
        }
        if (turnRate > maxRadarTurnRate) {
            turnRate = maxRadarTurnRate;
        }
        desiredRadarTurnRate = turnRate;
    }

    /**
     * Sets the turn rate of the robot.
     *
     * @param turnRate double is the robots turn rate, in radians/tick
     */
    public synchronized void setRobotTurnRate(double turnRate) {
        if (getEnergy() == 0) {
            return;
        }
        //Use RHR
//		turnRate = -turnRate;
        // Do a little boundary checking
        if (turnRate < -maxTurnRate) {
            turnRate = -maxTurnRate;
        }
        if (turnRate > maxTurnRate) {
            turnRate = maxTurnRate;
        }
        desiredTurnRate = turnRate;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/18/2000 5:07:28 PM)
     */
    public final synchronized void update() {

        updateGunHeat();
        hitByBulletEvent.clearHitByBulletEvent();
        bulletHitEvent.clearBulletHitEvent();
        bulletHitBullet = false;
        bulletMissed = false;

        lastHeading = heading;
        lastGunHeading = gunHeading;
        lastRadarHeading = radarHeading;

        if (!inCollision) {
            updateHeading();
        }

        updateMovement();
        updateGunHeading();
        updateRadarHeading();

        // At this point, robot has turned then moved.
        // We could be touching a wall or another bot...

        // First and foremost, we can never go through a wall or an object:
        checkObjectCollision();

        // Now check for robot collision
        checkRobotCollision();

        // Scan false means robot did not call scan() manually.
        // But if we're moving, scan
        if (scan == false) {
            if (lastHeading != heading ||
                    lastGunHeading != gunHeading ||
                    lastRadarHeading != radarHeading ||
                    lastX != x ||
                    lastY != y ||
                    waitCondition != null) {
                //if (noScan == false)
                scan = true;
            }
        }
    }

    public synchronized void updateBoundingBox() {
        // this commented code is technically more correct since the Rect2D object has an origin in the upper-left corner while
        // robocode has its origin in the bottom-left corner ... but ... this code also breaks some things with
        // robots running off the edge of the map etc...
        // boundingBox.setRect(x - width / 2 + 4, (getBattleFieldHeight() - y) - height / 2 + 4, width - 8, height - 8);\
        // instead of fixing this issue everywhere, I'm just fixing it for the intersect call so that robot scanning will work.

        boundingBox.setRect(x - width / 2 + 4, y - height / 2 + 4, width - 8, height - 8);
    }

    /**
     * The turnRate adjusts the heading at each tick.
     */
    private void updateHeading() {

        double diff = desiredTurnRate - turnRate;
        if (Math.abs(diff) > turnAcceleration) {
            if (turnRate > desiredTurnRate) {
                turnRate -= turnAcceleration;
            }
            if (turnRate < desiredTurnRate) {
                turnRate += turnAcceleration;
            }
        } else {
            turnRate += diff;
        }

        if (turnRate != 0.0) {
            heading += turnRate;
            heading = Utils.normalAbsoluteAngle(heading);
            if (!adjustGunForBodyTurn) {
                gunHeading += turnRate;
                gunHeading = Utils.normalAbsoluteAngle(gunHeading);
            }
            if (!adjustRadarForBodyTurn) {
                radarHeading += turnRate;
                radarHeading = Utils.normalAbsoluteAngle(radarHeading);
            }
        }
    }

    /**
     * The updateGunHeading updates the gunTurnRate to meet the desiredGunTurnRate, and
     * updates the gunHeading based on the new gunTurnRate.
     * If the radar turning is bound to the gun, the radar is also updated.
     */
    private void updateGunHeading() {
        double diff = desiredGunTurnRate - gunTurnRate;
        if (Math.abs(diff) > gunTurnAcceleration) {
            if (gunTurnRate > desiredGunTurnRate) {
                gunTurnRate -= gunTurnAcceleration;
            }
            if (gunTurnRate < desiredGunTurnRate) {
                gunTurnRate += gunTurnAcceleration;
            }
        } else {
            gunTurnRate += diff;
        }

        if (gunTurnRate != 0) {
            gunHeading += gunTurnRate;
            gunHeading = Utils.normalAbsoluteAngle(gunHeading);
            if (!adjustRadarForGunTurn) {
                radarHeading += gunTurnRate;
                radarHeading = Utils.normalAbsoluteAngle(radarHeading);
            }
        }
    }

    /**
     * The updateRadarHeading updates the radarTurnRate to meet the desiredRadarTurnRate, and
     * updates the radarHeading based on the new radarTurnRate.
     */
    private void updateRadarHeading() {

        double diff = desiredRadarTurnRate - radarTurnRate;
        if (Math.abs(diff) > radarTurnAcceleration) {
            if (radarTurnRate > desiredRadarTurnRate) {
                radarTurnRate -= radarTurnAcceleration;
            }
            if (radarTurnRate < desiredRadarTurnRate) {
                radarTurnRate += radarTurnAcceleration;
            }
        } else {
            radarTurnRate += diff;
        }

        if (radarTurnRate != 0) {
            radarHeading += radarTurnRate;
            radarHeading = Utils.normalAbsoluteAngle(radarHeading);
        }
    }

    /**
     * The velocity adjusts the position at each tick.
     */
    private void updateMovement() {

        lastX = x;
        lastY = y;

        // Allow the robot to accelerate
        double diff = desiredVelocity - velocity;
        if (Math.abs(diff) > acceleration) {
            if (velocity > desiredVelocity) {
                velocity -= acceleration;
            }
            if (velocity < desiredVelocity) {
                velocity += acceleration;
            }
        } else {
            velocity += diff;
        }

        if (velocity != 0.0) {
            // Move the robot using velocity
            double dx = velocity * Math.cos(heading);
            double dy = velocity * Math.sin(heading);
            x += dx;
            y += dy;

            // Do a little boundary checking
            if (dx != 0 || dy != 0) {
                updateBoundingBox();
            }
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/14/2000 5:20:01 PM)
     *
     * @param b robocode.Battle
     */
    public synchronized void wakeup(Battle b) {
        if (sleeping) {
            //log("Waking up " + getName());
            // Wake up the thread
            this.notify();
            try {
                this.wait(10);
                //log("Wakeup returning.");
            } catch (InterruptedException e) {
            }
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/18/2000 9:40:21 PM)
     */
    public void halt() {
        halt = true;
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/16/2001 4:40:01 PM)
     *
     * @param o java.lang.Object
     * @return int
     */
    public int compareTo(Object o) {
        if (!(o instanceof ContestantPeer)) {
            return 0;
        }
        ContestantPeer r = (ContestantPeer) o;
        if (r.getStatistics().getTotalScore() > statistics.getTotalScore()) {
            return 1;
        } else if (r.getStatistics().getTotalScore() < statistics.getTotalScore()) {
            return -1;
        } else {
            return 0;
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 12:16:13 PM)
     *
     * @return robocode.Robot
     */
    public Robot getRobot() {
        return robot;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 12:16:13 PM)
     *
     * @param newRobot robocode.Robot
     */
    public void setRobot(Robot newRobot) {
        robot = newRobot;
        if (robot instanceof robocode.TeamRobot) {
            //log(getName() + " IS a team robot.");

            messageManager = new RobotMessageManager(this);
        } else {
            //log(newRobot + " (" + getName() + ") is not a team robot.");
        }
    }

    public TeamPeer getTeamPeer() {
        return teamPeer;
    }

    public boolean isTeamLeader() {
        return getTeamPeer() != null && getTeamPeer().getTeamLeader() == this;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/21/2000 2:24:41 PM)
     *
     * @return long
     */
    public synchronized long getTime() {
        return battle.getCurrentTime();
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/29/2000 9:47:25 AM)
     */
    public void initialize(double x, double y, double heading) {
        setDead(false);
        setWinner(false);
        setX(x);
        setY(y);
        lastX = x;
        lastY = y;
        setHeading(heading);
        setGunHeading(heading);
        setRadarHeading(heading);
        lastHeading = heading;
        lastGunHeading = heading;
        lastRadarHeading = heading;

        velocity = 0.0;
        desiredVelocity = 0.0;
        turnRate = 0.0;
        gunTurnRate = 0.0;
        radarTurnRate = 0.0;
        desiredTurnRate = 0.0;
        desiredGunTurnRate = 0.0;
        desiredRadarTurnRate = 0.0;

        if (isTeamLeader() && isDroid()) {
            setEnergy(220.0);
        } else if (isTeamLeader()) {
            setEnergy(200.0);
        } else if (isDroid()) {
            setEnergy(120.0);
        } else {
            setEnergy(100.0);
        }
        gunHeat = 3;

        scan = false;
        scanArc.setAngleStart(0);
        scanArc.setAngleExtent(0);
        scanRadius = 0;
        scanArc.setFrame(-100, -100, 1, 1);
        statistics.initializeRound();
        halt = false;
        out.resetCounter();
        inCollision = false;
        setCallCount = 0;
        getCallCount = 0;
        skippedTurns = 0;
        getRobotThreadManager().resetCpuTime();

        adjustGunForBodyTurn = false;
        adjustRadarForGunTurn = false;
        adjustRadarForBodyTurn = false;
        adjustRadarForBodyTurnSet = false;

        newBullet = null;
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/4/2001 6:17:34 PM)
     *
     * @return boolean
     */
    public boolean isWinner() {
        return winner;
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/4/2001 6:17:34 PM)
     *
     * @param newWinner boolean
     */
    public void setWinner(boolean newWinner) {
        winner = newWinner;
        if (winner) {
            out.println("SYSTEM: " + getName() + " wins the round.");
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/27/2001 10:24:16 AM)
     *
     * @param condition robocode.JCondition
     */
    public void waitFor(Condition condition) {
        waitCondition = condition;
        tick();
        while (condition.test() == false) {
            tick();
        }
        waitCondition = null;
    }

    /**
     * Insert the method's description here.
     *
     * @return double
     */
    public double getLastGunHeading() {
        return lastGunHeading;
    }

    /**
     * Insert the method's description here.
     *
     * @return double
     */
    public double getLastRadarHeading() {
        return lastRadarHeading;
    }

    public robocode.Bullet setFire(double power) {
        if (Double.isNaN(power)) {
            out.println("SYSTEM: You cannot call fire(NaN)");
            return null;
        }
        double firePower = power;
        if (firePower < .1) {
            firePower = .1;
        }
        if (firePower > 3) {
            firePower = 3;
        }

        if (gunHeat > 0 || getEnergy() == 0) {
            return null;
        }

        if (firePower > energy) {
            firePower = energy;
        }
        this.setEnergy(energy - firePower);

        gunHeat += 1 + (firePower / 5);
        BulletPeer bullet = new BulletPeer(this, battle);
        bullet.setPower(firePower);
        bullet.setVelocity(20 - 3 * firePower);
        bullet.setHeading(getGunHeading());
        bullet.setOwner(this);
        bullet.setX(x);
        bullet.setY(y);

        if (bullet != null) {
            newBullet = bullet;
        }

        return bullet.getBullet();
    }

    /**
     * Return the robots energy level.
     *
     * @return double
     */
    public synchronized double getEnergy() {
        return energy;
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/4/2001 3:14:44 AM)
     *
     * @param newEnergy double
     */
    public void setEnergy(double newEnergy) {
        setEnergy(newEnergy, true);
    }

    /**
     * Return the heat of the gun.
     *
     * @return double
     */
    public synchronized double getGunHeat() {
        return gunHeat;
    }

    /**
     * Insert the method's description here.
     * Creation date: (3/27/2001 8:49:46 PM)
     *
     * @param newGunHeat double
     */
    public synchronized void setGunHeat(double newGunHeat) {
        gunHeat = newGunHeat;
    }

    /**
     * Return the maximum velocity achievable.
     *
     * @return double
     */
    public synchronized double getMaxVelocity() {
        return maxVelocity;
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/26/2001 4:48:33 PM)
     *
     * @return int
     */
    public synchronized int getNumRounds() {
        return getBattle().getNumRounds();
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/12/2001 10:07:37 PM)
     *
     * @return RobocodeOutputStream
     */
    public synchronized RobotOutputStream getOut() {
        if (out == null) {
            if (battle == null) {
                return null;
            }
//			throw new RuntimeException("Cannot create robot's output stream with a null battle.");
            out = new RobotOutputStream(battle.getBattleThread());

        }
        return out;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/21/2000 2:32:17 PM)
     *
     * @return java.lang.String
     */
    public RobotClassManager getRobotClassManager() {
        return robotClassManager;
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/27/2001 7:08:26 PM)
     *
     * @return robocode.peer.robot.RobotFileSystemManager
     */
    public RobotFileSystemManager getRobotFileSystemManager() {
        return robotFileSystemManager;
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/18/2001 6:00:15 PM)
     *
     * @return robocode.peer.robot.RobotThreadHandler
     */
    public RobotThreadManager getRobotThreadManager() {
        return robotThreadManager;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/21/2000 2:24:24 PM)
     *
     * @return int
     */
    public synchronized int getRoundNum() {
        return getBattle().getRoundNum();
    }

    /**
     * Insert the method's description here.
     */
    public synchronized boolean getScan() {
        return this.scan;
    }

    /**
     * Insert the method's description here.
     *
     * @param scan boolean
     */
    public synchronized void setScan(boolean scan) {
        this.scan = scan;
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/10/2001 7:26:33 PM)
     *
     * @return java.awt.geom.Arc2D.Double
     */
    public synchronized Arc2D.Double getScanArc() {
        return scanArc;
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/10/2001 7:27:09 PM)
     *
     * @return double
     */
    public double getScanRadius() {
        return scanRadius;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 4:00:00 PM)
     *
     * @return java.lang.String
     */
    public String getShortName() {
        if (shortName == null) {
            return robotClassManager.getClassNameManager().getUniqueShortClassNameWithVersion();
        } else {
            return shortName;
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (11/3/2001 11:02:21 PM)
     *
     * @return int
     */
    public int getSkippedTurns() {
        return skippedTurns;
    }

    /**
     * Insert the method's description here.
     * Creation date: (11/3/2001 11:02:21 PM)
     *
     * @param newSkippedTurns int
     */
    public void setSkippedTurns(int newSkippedTurns) {
        // Notify the robot it has skipped a turn
        if (getRobot() != null && getRobot() instanceof AdvancedRobot) {
            getRobot().onSkippedTurn();
        }
        // Update the number of skipped turns
        skippedTurns = newSkippedTurns;
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/18/2001 3:49:45 PM)
     *
     * @return robocode.peer.robot.RobotStatistics
     */
    public RobotStatistics getRobotStatistics() {
        return statistics;
    }

    public ContestantStatistics getStatistics() {
        return statistics;
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/18/2001 3:49:45 PM)
     *
     * @param newStatistics robocode.peer.robot.RobotStatistics
     */
    public void setStatistics(RobotStatistics newStatistics) {
        statistics = newStatistics;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 4:00:00 PM)
     *
     * @return java.lang.String
     */
    public String getVeryShortName() {
        if (shortName == null) {
            return robotClassManager.getClassNameManager().getUniqueVeryShortClassNameWithVersion();
        } else {
            return shortName;
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (11/1/2001 11:03:09 PM)
     *
     * @return boolean
     */
    public synchronized boolean isAdjustRadarForBodyTurn() {
        return adjustRadarForBodyTurn;
    }

    /**
     * Insert the method's description here.
     * Creation date: (11/1/2001 11:03:09 PM)
     *
     * @param newAdjustRadarForBodyTurn boolean
     */
    public synchronized void setAdjustRadarForBodyTurn(boolean newAdjustRadarForBodyTurn) {
        adjustRadarForBodyTurn = newAdjustRadarForBodyTurn;
        adjustRadarForBodyTurnSet = true;
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/27/2001 2:50:41 PM)
     *
     * @return boolean
     */
    public boolean isCheckFileQuota() {
        return checkFileQuota;
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/27/2001 2:50:41 PM)
     *
     * @param newCheckFileQuota boolean
     */
    public void setCheckFileQuota(boolean newCheckFileQuota) {
        out.println("CheckFileQuota on");
        checkFileQuota = newCheckFileQuota;
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/23/2001 5:29:16 PM)
     *
     * @param s java.lang.String
     */
    public void log(String s) {
        Utils.log(s);
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/3/2001 6:22:54 PM)
     */
    public synchronized void setCall() {
        setCallCount++;
        if (setCallCount == maxSetCallCount) {
            out.println("SYSTEM: You have made " + setCallCount + " calls to setXX methods without calling execute()");
            throw new DisabledException("Too many calls to setXX methods");
			/*		out.println("SYSTEM: Stopping robot due to excessive calls to setXX methods.");
			 halt = true;
			 setDead(true);
			 tick(); */
        }
    }

    public synchronized void getCall() {
        getCallCount++;
        if (getCallCount == maxGetCallCount) {
            out.println("SYSTEM: You have made " + getCallCount + " calls to getXX methods without calling execute()");
            throw new DisabledException("Too many calls to getXX methods");
        }
    }

    public boolean isDuplicate() {
        return duplicate;
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/4/2001 3:14:44 AM)
     *
     * @param count int
     */
    public void setDuplicate(int count) {
        this.duplicate = true;
        this.name =
                getRobotClassManager().getClassNameManager().getFullClassNameWithVersion() + " (" + (count + 1) + ")";
        this.shortName =
                getRobotClassManager().getClassNameManager().getUniqueShortClassNameWithVersion() +
                        " (" +
                        (count + 1) +
                        ")";
        this.nonVersionedName =
                getRobotClassManager().getClassNameManager().getFullClassName() + " (" + (count + 1) + ")";
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/4/2001 3:14:44 AM)
     *
     * @param newEnergy double
     */
    public synchronized void setEnergy(double newEnergy, boolean resetInactiveTurnCount) {
        if (resetInactiveTurnCount && (energy != newEnergy)) {
            battle.resetInactiveTurnCount(energy - newEnergy);
        }
        energy = newEnergy;
        if (energy < .01) {
            energy = 0;
            allStop();
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/15/2000 6:34:48 PM)
     */
    public synchronized void updateGunHeat() {

        gunHeat -= battle.getGunCoolingRate();

        if (gunHeat < 0) {
            gunHeat = 0;
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/4/2001 3:20:21 AM)
     */
    public synchronized void zap(double zapAmount) {
        if (energy == 0) {
            setDead(true);
            return;
        }
        energy -= Math.abs(zapAmount);
        if (energy < .1) {
            energy = 0;
            desiredVelocity = 0.0;
            desiredTurnRate = 0.0;
        }
    }

    /**
     * Gets the running.
     *
     * @return Returns a boolean
     */
    public synchronized boolean isRunning() {
        return running;
    }


    /**
     * Sets the running.
     *
     * @param running The running to set
     */
    public synchronized void setRunning(boolean running) {
        this.running = running;
    }

    /**
     * Gets the sleeping.
     *
     * @return Returns a boolean
     */
    public synchronized boolean isSleeping() {
        return sleeping;
    }


    /**
     * Sets the setCallCount.
     *
     * @param setCallCount The setCallCount to set
     */
    public synchronized void setSetCallCount(int setCallCount) {
        this.setCallCount = setCallCount;
    }

    public synchronized void setGetCallCount(int getCallCount) {
        this.getCallCount = getCallCount;
    }

    public boolean intersectsLine(BoundingRectangle r, double x1, double y1, double x2, double y2) {
        int out1, out2;
        if ((out2 = r.outcode(x2, y2)) == 0) {
            return true;
        }
        while ((out1 = r.outcode(x1, y1)) != 0) {
            log("testing: " + x1 + "," + y1);
            if ((out1 & out2) != 0) {
                return false;
            }
            if ((out1 & (Rectangle2D.OUT_LEFT | Rectangle2D.OUT_RIGHT)) != 0) {
                double x = r.getX();
                if ((out1 & Rectangle2D.OUT_RIGHT) != 0) {
                    log("adding r.getWidth");
                    x += r.getWidth();
                    log("x is now: " + x);
                }
                y1 = y1 + (x - x1) * (y2 - y1) / (x2 - x1);
                x1 = x;
                log("x1 is now: " + x1);
            } else {
                double y = r.getY();
                if ((out1 & Rectangle2D.OUT_BOTTOM) != 0) {
                    log("adding r.getHeight");
                    y += r.getHeight();
                }
                x1 = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
                y1 = y;
            }
        }
        return true;
    }

    /**
     * Gets the colorIndex.
     *
     * @return Returns a int
     */
    public synchronized int getColorIndex() {
        return colorIndex;
    }

    public synchronized void setColors(Color robotColor, Color gunColor, Color radarColor) {
        if (getBattle().getManager().getProperties().getOptionsBattleAllowColorChanges() == false) {
            if (getRoundNum() == setColorRoundNum) {
                return;
            }
            //this.robotColor != -1 || this.gunColor != -1 || this.radarColor != -1)
            //throw new RobotException("You may only call setColors once.");
            if (getRoundNum() != 0) {
                return;
            }
        }

        if (this.colorIndex == -1) {
            this.colorIndex = imageManager.getNewColorsIndex(robotColor, gunColor, radarColor);
            setColorRoundNum = getRoundNum();
        } else {
            imageManager.replaceColorsIndex(colorIndex, robotColor, gunColor, radarColor);
        }
    }

    /**
     * Gets the messageManager.
     *
     * @return Returns a RobotMessageManager
     */
    public RobotMessageManager getMessageManager() {
        return messageManager;
    }

    public boolean say(String text) {
        if (sayTextPeer == null) {
            sayTextPeer = new TextPeer();
        }

        if (sayTextPeer.isReady()) {
            if (text.length() > 100) {
                return false;
            }
            sayTextPeer.setText(getVeryShortName() + ": " + text);
            sayTextPeer.setX((int) getX());
            sayTextPeer.setY((int) getY());
            sayTextPeer.setDuration(20 + text.length());
            return true;
        } else {
            return false;
        }
    }

    public void updateSayText() {
        if (sayTextPeer != null) {
            sayTextPeer.tick();
        }
    }

    public String toString() {
        return this.name + ":" + this.hashCode();
    }

    public static class RobotPeerShell {
        Random rand = new Random();
        boolean dead = false;
        double x = 0.0;
        double y = 0.0;
        double w = 32.0;
        double h = 32.0;
        BoundingRectangle boundingBox = new BoundingRectangle();
        String name = "default";
        double energy = 100.0;
        double heading = 0.0;
        double velocity = 0.0;

        public RobotPeerShell randomize() {
            x = rand.nextDouble() * 400.0;
            y = rand.nextDouble() * 400.0;
            name = "Robot" + rand.nextInt(100);
            energy = Math.round(rand.nextDouble() * 1000.0) / 10.0;
            heading = rand.nextDouble() * Math.PI * 2;
            velocity = (rand.nextDouble() - .5) * 20.0;
            boundingBox = getBoundingBox();
            return this;
        }

        public boolean isDead() {
            return dead;
        }

        public double getX() {
            return x;
        }

        public void setX(double x) {
            this.x = x;
        }

        public double getY() {
            return y;
        }

        public void setY(double y) {
            this.y = y;
        }

        public double getW() {
            return w;
        }

        public void setW(double w) {
            this.w = w;
        }

        public double getH() {
            return h;
        }

        public void setH(double h) {
            this.h = h;
        }

        public BoundingRectangle getBoundingBox() {
            boundingBox = new BoundingRectangle(getX() - w / 2, getY() + h / 2, getW(), getH());
            return boundingBox;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public double getEnergy() {
            return energy;
        }

        public void setEnergy(double energy) {
            this.energy = energy;
        }

        public double getHeading() {
            return heading;
        }

        public void setHeading(double heading) {
            this.heading = heading;
        }

        public double getVelocity() {
            return velocity;
        }

        public void setVelocity(double velocity) {
            this.velocity = velocity;
        }


    }
}
/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode.packager;

import robocode.dialog.WizardPanel;
import robocode.repository.FileSpecification;
import robocode.repository.FileSpecificationVector;
import robocode.util.LimitedDocument;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

/**
 * Insert the type's description here.
 * Creation date: (10/19/2001 12:07:51 PM)
 *
 * @author: Administrator
 */
public class PackagerOptionsPanel extends WizardPanel {
    public JPanel robotListPanel = null;
    RobotPackager robotPackager = null;
    JCheckBox includeSource = null;
    EventHandler eventHandler = new EventHandler();
    JLabel authorLabel = null;
    JTextField authorField = null;
    JLabel descriptionLabel = null;
    JTextArea descriptionArea = null;
    JLabel versionLabel = null;
    JTextField versionField = null;
    JLabel versionHelpLabel = null;
    JLabel webpageLabel = null;
    JTextField webpageField = null;
    JLabel webpageHelpLabel = null;

    /**
     * PackagerOptionsPanel constructor comment.
     */
    public PackagerOptionsPanel(RobotPackager robotPackager) {
        super();
        this.robotPackager = robotPackager;
        initialize();
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/19/2001 2:27:51 PM)
     *
     * @param args java.lang.String[]
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("options");
        frame.setSize(new Dimension(500, 300));
        frame.getContentPane().add(new PackagerOptionsPanel(null));
        frame.pack();
        frame.show();
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                e.getWindow().dispose();
            }

            public void windowClosed(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/19/2001 12:28:02 PM)
     *
     * @return javax.swing.JCheckBox
     */
    public JCheckBox getIncludeSource() {
        if (includeSource == null) {
            includeSource = new JCheckBox("Include source", true);
        }
        return includeSource;
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/19/2001 12:09:49 PM)
     */
    private void initialize() {
        setName("packagerOptionsPanel");
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        JLabel
                label =
                new JLabel("It is up to you whether or not to include the source when you distribute your robot.");
        label.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(label);

        label =
                new JLabel("If you include the source, other people will be able to look at your code and learn from it.");
        label.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(label);

        getIncludeSource().setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(getIncludeSource());

        label = new JLabel(" ");
        label.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(label);

        add(getVersionLabel());

        JPanel p = new JPanel();
        p.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        p.setAlignmentX(JPanel.LEFT_ALIGNMENT);
        getVersionField().setAlignmentX(JLabel.LEFT_ALIGNMENT);
        getVersionField().setMaximumSize(getVersionField().getPreferredSize());
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, getVersionField().getPreferredSize().height));
        p.add(getVersionField());
        p.add(getVersionHelpLabel());
        add(p);

        label = new JLabel(" ");
        label.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(label);

        add(getDescriptionLabel());

        //System.out.println(getDescriptionArea().getPreferredSize());
        //System.out.println(getDescriptionArea().getPreferredScrollableViewportSize());

        JScrollPane
                scrollPane =
                new JScrollPane(getDescriptionArea(), JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        //System.out.println(scrollPane.getPreferredSize());
        scrollPane.setMaximumSize(scrollPane.getPreferredSize());
        scrollPane.setMinimumSize(new Dimension(100, scrollPane.getPreferredSize().height));
        scrollPane.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(scrollPane);

        label = new JLabel(" ");
        label.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(label);

        add(getAuthorLabel());

        getAuthorField().setAlignmentX(JTextField.LEFT_ALIGNMENT);
        getAuthorField().setMaximumSize(getAuthorField().getPreferredSize());
        add(getAuthorField());

        label = new JLabel(" ");
        label.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(label);

        add(getWebpageLabel());

        getWebpageField().setAlignmentX(JTextField.LEFT_ALIGNMENT);
        getWebpageField().setMaximumSize(getWebpageField().getPreferredSize());
        add(getWebpageField());

        getWebpageHelpLabel().setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(getWebpageHelpLabel());

        JPanel panel = new JPanel();
//	panel.setBackground(Color.blue);
        panel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        add(panel);
        addComponentListener(eventHandler);
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/20/2001 11:24:52 AM)
     */
    public boolean isReady() {
        if (getVersionLabel().isVisible()) {
            if (getVersionField().getText().equals("")) {
                return false;
            }
            if (getVersionField().getText().indexOf(",") >= 0) {
                return false;
            }
            if (getVersionField().getText().indexOf(" ") >= 0) {
                return false;
            }
            if (getVersionField().getText().indexOf("*") >= 0) {
                return false;
            }
            if (getVersionField().getText().indexOf("(") >= 0) {
                return false;
            }
            if (getVersionField().getText().indexOf(")") >= 0) {
                return false;
            }
            if (getVersionField().getText().indexOf("[") >= 0) {
                return false;
            }
            if (getVersionField().getText().indexOf("]") >= 0) {
                return false;
            }
            if (getVersionField().getText().indexOf("{") >= 0) {
                return false;
            }
            if (getVersionField().getText().indexOf("}") >= 0) {
                return false;
            }
        }
        return !getDescriptionArea().getText().equals("");
    }

    private JLabel getAuthorLabel() {
        if (authorLabel == null) {
            authorLabel = new JLabel("Please enter your name. (optional)");
            authorLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        }
        return authorLabel;
    }

    /**
     * Insert the method's description here.
     * Creation date: (11/1/2001 5:05:39 PM)
     *
     * @return javax.swing.JTextField
     */
    public JTextField getAuthorField() {
        if (authorField == null) {
            authorField = new JTextField(40);
        }
        return authorField;
    }

    public JLabel getDescriptionLabel() {
        if (descriptionLabel == null) {
            descriptionLabel = new JLabel("");
            descriptionLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        }
        return descriptionLabel;
    }

    public JTextArea getDescriptionArea() {
        if (descriptionArea == null) {
            LimitedDocument doc = new LimitedDocument(3, 72);
            descriptionArea = new JTextArea(doc, null, 3, 72);
            doc.addDocumentListener(eventHandler);
            //descriptionArea.setMaximumSize(descriptionArea.getPreferredScrollableViewportSize());
            //descriptionArea.setLineWrap(true);
            //descriptionArea.setWrapStyleWord(true);
        }
        return descriptionArea;
    }

    private JLabel getVersionLabel() {
        if (versionLabel == null) {
            versionLabel =
                    new JLabel("Please enter a version number for this robot (up to 10 chars, no spaces,commas,asterisks, or brackets).");
            versionLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        }
        return versionLabel;
    }

    public JTextField getVersionField() {
        if (versionField == null) {
            LimitedDocument doc = new LimitedDocument(1, 10);
            versionField = new JTextField(doc, null, 10);
            doc.addDocumentListener(eventHandler);
            //descriptionArea.setMaximumSize(descriptionArea.getPreferredScrollableViewportSize());
            //descriptionArea.setLineWrap(true);
            //descriptionArea.setWrapStyleWord(true);
        }
        return versionField;
    }

    /**
     * Insert the method's description here.
     * Creation date: (11/1/2001 4:58:14 PM)
     *
     * @return javax.swing.JLabel
     */
    public JLabel getVersionHelpLabel() {
        if (versionHelpLabel == null) {
            versionHelpLabel = new JLabel("<-- Make sure to delete the asterisk and type in a new version number");
        }
        return versionHelpLabel;
    }

    public JLabel getWebpageLabel() {
        if (webpageLabel == null) {
            webpageLabel = new JLabel("Please enter a URL for your robot's webpage. (optional)");
            webpageLabel.setAlignmentX(JLabel.LEFT_ALIGNMENT);
        }
        return webpageLabel;
    }

    public JTextField getWebpageField() {
        if (webpageField == null) {
            webpageField = new JTextField(40);
        }
        return webpageField;
    }

    /**
     * Insert the method's description here.
     * Creation date: (11/1/2001 5:13:42 PM)
     *
     * @return javax.swing.JLabel
     */
    public JLabel getWebpageHelpLabel() {
        if (webpageHelpLabel == null) {
            webpageHelpLabel = new JLabel("");
        }
        return webpageHelpLabel;
    }

    class EventHandler implements ComponentListener, KeyListener, DocumentListener {
        int count = 0;

        public void insertUpdate(DocumentEvent e) {
            fireStateChanged();
        }

        public void changedUpdate(DocumentEvent e) {
            fireStateChanged();
        }

        public void removeUpdate(DocumentEvent e) {
            fireStateChanged();
        }

        public void componentMoved(ComponentEvent e) {
        }

        public void componentHidden(ComponentEvent e) {
        }

        public void componentShown(ComponentEvent e) {
            //log("Component Shown!");
            FileSpecificationVector selectedRobots = robotPackager.getRobotSelectionPanel().getSelectedRobots();
            if (selectedRobots != null && (/*robotPackager.isTeamPackager() ||*/ selectedRobots.size() == 1)) {
                FileSpecification fileSpecification = selectedRobots.elementAt(0);
                String v = fileSpecification.getVersion();
                if (v == null || v.equals("")) {
                    getVersionHelpLabel().setVisible(false);
                    //log("Help Label not visible.");
                    v = "1.0";
                } else {
                    if (v.length() == 10) {
                        v = v.substring(0, 9);
                    }
                    v += "*";
                    getVersionHelpLabel().setVisible(true);
                }
                getVersionField().setText(v);
                String d = fileSpecification.getDescription();
                if (d == null) {
                    d = "";
                }
                getDescriptionArea().setText(d);
                String a = fileSpecification.getAuthorName();
                if (a == null) {
                    a = "";
                }
                getAuthorField().setText(a);
                URL u = fileSpecification.getWebpage();
                if (u == null) {
                    getWebpageField().setText("");
                } else {
                    getWebpageField().setText(u.toString());
                }

                String filepath = fileSpecification.getFilePath();
                if (filepath != null && filepath.indexOf(".") > 0) {
                    String htmlfn = filepath.substring(0, filepath.lastIndexOf(".")) + ".html";
                    getWebpageHelpLabel().setText("(You may also leave this blank, and simply create the file: " +
                            htmlfn +
                            ")");
                } else {
                    getWebpageHelpLabel().setText("");
                }

                getVersionLabel().setVisible(true);
                getVersionField().setVisible(true);
                getAuthorLabel().setVisible(true);
                getAuthorField().setVisible(true);
                getWebpageLabel().setVisible(true);
                getWebpageField().setVisible(true);
                getWebpageHelpLabel().setVisible(true);
                getDescriptionLabel().setText("Please enter a short description of your robot (up to 3 lines of 72 chars each).");

            } else if (/*!robotPackager.isTeamPackager() &&*/ selectedRobots.size() > 1) {
                getVersionLabel().setVisible(false);
                getVersionField().setVisible(false);
                getVersionHelpLabel().setVisible(false);
                getAuthorLabel().setVisible(false);
                getAuthorField().setVisible(false);
                getWebpageLabel().setVisible(false);
                getWebpageField().setVisible(false);
                getWebpageHelpLabel().setVisible(false);
                getDescriptionLabel().setText("Please enter a short description of this robot collection (up to 3 lines of 72 chars each).");
                if (getDescriptionArea().getText() == null || getDescriptionArea().getText().equals("")) {
                    getDescriptionArea().setText("(Example)This robot comes from the ... robot collection\n");
                }
            }
        }

        public void componentResized(ComponentEvent e) {
        }

        public void keyPressed(KeyEvent e) {
        }

        public void keyReleased(KeyEvent e) {
        }

        public void keyTyped(KeyEvent e) {
            //if (e.getSource() == getJarFilenameTextField())
            //	PackagerOptionsPanel.this.keyTyped = true;
        }

    }
}
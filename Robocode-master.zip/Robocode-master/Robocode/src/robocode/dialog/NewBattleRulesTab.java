/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode.dialog;

import robocode.util.Utils;

import javax.swing.*;

/**
 * Insert the type's description here.
 * Creation date: (1/18/2001 1:24:23 PM)
 *
 * @author: Mathew A. Nelson
 */
public class NewBattleRulesTab extends JPanel {
    private JLabel gunCoolingRateLabel = null;
    private JTextField gunCoolingRateField = null;

    private JLabel inactivityTimeLabel = null;
    private JTextField inactivityTimeField = null;


    /**
     * NewBattleRulesTab constructor
     */
    public NewBattleRulesTab() {
        super();
        initialize();
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/18/2001 1:34:13 PM)
     */
    public double getGunCoolingRate() {

        return Double.parseDouble(getGunCoolingRateField().getText());
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/18/2001 1:34:13 PM)
     */
    public void setGunCoolingRate(double gunCoolingRate) {
        getGunCoolingRateField().setText("" + gunCoolingRate);
    }

    /**
     * Return the gunRechargeRateField
     *
     * @return javax.swing.JTextField
     */
    private JTextField getGunCoolingRateField() {
        if (gunCoolingRateField == null) {
            try {
                gunCoolingRateField = new JTextField();
                gunCoolingRateField.setName("gunCoolingRateField");
                gunCoolingRateField.setPreferredSize(new java.awt.Dimension(50, 16));
            } catch (Throwable e) {
                log(e);
            }
        }
        return gunCoolingRateField;
    }

    /**
     * Return the gunCoolingRateLabel
     *
     * @return javax.swing.JLabel
     */
    private JLabel getGunCoolingRateLabel() {
        if (gunCoolingRateLabel == null) {
            try {
                gunCoolingRateLabel = new JLabel();
                gunCoolingRateLabel.setName("gunCoolingRateLabel");
                gunCoolingRateLabel.setAlignmentX(java.awt.Component.RIGHT_ALIGNMENT);
                gunCoolingRateLabel.setText("Gun Cooling Rate:");
                gunCoolingRateLabel.setHorizontalTextPosition(SwingConstants.CENTER);
                gunCoolingRateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
            } catch (Throwable e) {
                log(e);
            }
        }
        return gunCoolingRateLabel;
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/18/2001 1:34:13 PM)
     */
    public long getInactivityTime() {
        return Long.parseLong(getInactivityTimeField().getText());
    }

    /**
     * Insert the method's description here.
     * Creation date: (1/18/2001 1:34:13 PM)
     */
    public void setInactivityTime(long inactivityTime) {
        getInactivityTimeField().setText("" + inactivityTime);
    }

    /**
     * Return the inactivityTimeField
     *
     * @return javax.swing.JTextField
     */
    private JTextField getInactivityTimeField() {
        if (inactivityTimeField == null) {
            try {
                inactivityTimeField = new JTextField();
                inactivityTimeField.setName("inactivityTimeField");
            } catch (Throwable e) {
                log(e);
            }
        }
        return inactivityTimeField;
    }

    /**
     * Return the inactivityTimeLabel
     *
     * @return javax.swing.JLabel
     */
    private JLabel getInactivityTimeLabel() {
        if (inactivityTimeLabel == null) {
            try {
                inactivityTimeLabel = new JLabel();
                inactivityTimeLabel.setName("JLabel1");
                inactivityTimeLabel.setText("Inactivity Time:");
                inactivityTimeLabel.setHorizontalAlignment(SwingConstants.RIGHT);
            } catch (Throwable e) {
                log(e);
            }
        }
        return inactivityTimeLabel;
    }

    /**
     * Initialize the class.
     */
    private void initialize() {
        try {
            setName("newBattleRulesTab");
            JPanel j = new JPanel();
            j.setLayout(new java.awt.GridLayout(4, 2, 5, 5));
            j.setBorder(BorderFactory.createEtchedBorder());
//		j.setSize(10,200);
            j.add(getGunCoolingRateLabel(), getGunCoolingRateLabel().getName());
            j.add(getGunCoolingRateField(), getGunCoolingRateField().getName());

            j.add(getInactivityTimeLabel(), getInactivityTimeLabel().getName());
            j.add(getInactivityTimeField(), getInactivityTimeField().getName());

            add(j);
        } catch (Throwable e) {
            log(e);
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/22/2001 1:41:21 PM)
     *
     * @param e java.lang.Exception
     */
    public void log(Throwable e) {
        Utils.log(e);
    }
}

/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode.dialog;

import robocode.manager.MapRepositoryManager;
import robocode.repository.FileSpecificationVector;
import robocode.util.Utils;

import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

/**
 * Insert the type's description here.
 * Creation date: (8/26/2001 6:20:26 PM)
 *
 * @author: Mathew A. Nelson
 */
public class NewBattleBattleFieldTab extends WizardPanel {

    EventHandler eventHandler = new EventHandler();
    private JButton button1000x1000 = null;
    private JButton button1000x800 = null;
    private JButton button2000x2000 = null;
    private JButton button400x400 = null;
    private JButton button5000x5000 = null;
    private JButton button600x400 = null;
    private JButton button600x600 = null;
    private JButton button800x600 = null;
    private JButton button800x800 = null;
    private JScrollPane availableMapsScrollPane = null;
    private JList availableMapsList = null;
    private JPanel mapButtonsPanel = null;
    private JButton mapBrowserButton = null;
    private JButton mapBrowserButton2 = null;
    private JButton mapSelectButton = null;
    private JTextField pathTextField;
    private JTextField pathTextField2;
    private JPanel mainPanel = null;
    private JPanel buttonsPanel = null;
    private JPanel sliderPanel = null;
    private JPanel mapsPanel = null;
    private MapRepositoryManager mapManager;
    private FileSpecificationVector mapList;
    //	private String[] mapListString = {};
    private DefaultListModel mapListModel = new DefaultListModel();
    private int battleFieldHeight = 600;
    private int battleFieldWidth = 800;
    private JSlider battleFieldHeightSlider = null;
    private JLabel battleFieldSizeLabel = null;
    private JSlider battleFieldWidthSlider = null;

    //private ListSelectionListener eventListener = new ListSelectionListener();


    /**
     * NewBattleBattleFieldTab
     */
    public NewBattleBattleFieldTab(MapRepositoryManager mapManager) {
        super();
        this.mapManager = mapManager;
        initialize();
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/19/2001 6:44:02 PM)
     *
     * @return boolean
     */
    public boolean isReady() {
        return true;
    }

    /**
     * Comment
     */
    public void button1000x1000ActionPerformed() {
        getBattleFieldWidthSlider().setValue(1000);
        getBattleFieldHeightSlider().setValue(1000);
        battleFieldSliderValuesChanged();
        return;
    }

    /**
     * Comment
     */
    public void button1000x800ActionPerformed() {
        getBattleFieldWidthSlider().setValue(1000);
        getBattleFieldHeightSlider().setValue(800);
        battleFieldSliderValuesChanged();
        return;
    }

    /**
     * Comment
     */
    public void button2000x2000ActionPerformed() {
        getBattleFieldWidthSlider().setValue(2000);
        getBattleFieldHeightSlider().setValue(2000);
        battleFieldSliderValuesChanged();
        return;
    }

    /**
     * Comment
     */
    public void button400x400ActionPerformed() {
        getBattleFieldWidthSlider().setValue(400);
        getBattleFieldHeightSlider().setValue(400);
        battleFieldSliderValuesChanged();
        return;
    }

    /**
     * Comment
     */
    public void button5000x5000ActionPerformed() {
        getBattleFieldWidthSlider().setValue(5000);
        getBattleFieldHeightSlider().setValue(5000);
        battleFieldSliderValuesChanged();
        return;
    }

    /**
     * Comment
     */
    public void button600x400ActionPerformed() {
        getBattleFieldWidthSlider().setValue(600);
        getBattleFieldHeightSlider().setValue(400);
        battleFieldSliderValuesChanged();
        return;
    }

    /**
     * Comment
     */
    public void button600x600ActionPerformed() {
        getBattleFieldWidthSlider().setValue(600);
        getBattleFieldHeightSlider().setValue(600);
        battleFieldSliderValuesChanged();
        return;
    }

    /**
     * Comment
     */
    public void button800x600ActionPerformed() {
        getBattleFieldWidthSlider().setValue(800);
        getBattleFieldHeightSlider().setValue(600);
        battleFieldSliderValuesChanged();
        return;
    }

    /**
     * Comment
     */
    public void button800x800ActionPerformed() {
        getBattleFieldWidthSlider().setValue(800);
        getBattleFieldHeightSlider().setValue(800);
        battleFieldSliderValuesChanged();
        return;
    }

    /**
     * Return the Button1000x1000
     *
     * @return javax.swing.JButton
     */
    private JButton getButton1000x1000() {
        if (button1000x1000 == null) {
            try {
                button1000x1000 = new JButton();
                button1000x1000.setName("Button1000x1000");
                button1000x1000.setText("1000x1000");
                button1000x1000.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return button1000x1000;
    }

    /**
     * Return the button1000x800
     *
     * @return javax.swing.JButton
     */
    private JButton getButton1000x800() {
        if (button1000x800 == null) {
            try {
                button1000x800 = new JButton();
                button1000x800.setName("Button1000x800");
                button1000x800.setText("1000x800");
                button1000x800.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return button1000x800;
    }

    /**
     * Return the Button2000x2000
     *
     * @return javax.swing.JButton
     */
    private JButton getButton2000x2000() {
        if (button2000x2000 == null) {
            try {
                button2000x2000 = new JButton();
                button2000x2000.setName("Button2000x2000");
                button2000x2000.setText("2000x2000");
                button2000x2000.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return button2000x2000;
    }

    /**
     * Return the Button400x400
     *
     * @return javax.swing.JButton
     */
    private JButton getButton400x400() {
        if (button400x400 == null) {
            try {
                button400x400 = new JButton();
                button400x400.setName("Button400x400");
                button400x400.setText("400x400");
                button400x400.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return button400x400;
    }

    /**
     * Return the Button5000x5000
     *
     * @return javax.swing.JButton
     */
    private JButton getButton5000x5000() {
        if (button5000x5000 == null) {
            try {
                button5000x5000 = new JButton();
                button5000x5000.setName("Button5000x5000");
                button5000x5000.setText("5000x5000");
                button5000x5000.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return button5000x5000;
    }

    /**
     * Return the Button600x400
     *
     * @return javax.swing.JButton
     */
    private JButton getButton600x400() {
        if (button600x400 == null) {
            try {
                button600x400 = new JButton();
                button600x400.setName("Button600x400");
                button600x400.setText("600x400");
                button600x400.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return button600x400;
    }

    /**
     * Return the Button600x600
     *
     * @return javax.swing.JButton
     */
    private JButton getButton600x600() {
        if (button600x600 == null) {
            try {
                button600x600 = new JButton();
                button600x600.setName("Button600x600");
                button600x600.setText("600x600");
                button600x600.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return button600x600;
    }

    /**
     * Return the Button800x600
     *
     * @return javax.swing.JButton
     */
    private JButton getButton800x600() {
        if (button800x600 == null) {
            try {
                button800x600 = new JButton();
                button800x600.setName("Button800x600");
                button800x600.setText("800x600");
                button800x600.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return button800x600;
    }

    /**
     * Return the Button800x800
     *
     * @return javax.swing.JButton
     */
    private JButton getButton800x800() {
        if (button800x800 == null) {
            try {
                button800x800 = new JButton();
                button800x800.setName("Button800x800");
                button800x800.setText("800x800");
                button800x800.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return button800x800;
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/22/2001 1:41:21 PM)
     *
     * @param e java.lang.Exception
     */
    public void log(Throwable e) {
        Utils.log(e);
    }

    /**
     * Return the battleFieldSizeLabel.
     *
     * @return javax.swing.JLabel
     */
    private JLabel getBattleFieldSizeLabel() {
        if (battleFieldSizeLabel == null) {
            try {
                battleFieldSizeLabel = new JLabel();
                battleFieldSizeLabel.setName("JSizeLabel");
                battleFieldSizeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                battleFieldSizeLabel.setText("w x h");
                battleFieldSizeLabel.setHorizontalAlignment(SwingConstants.CENTER);
                battleFieldSizeLabel.setHorizontalTextPosition(SwingConstants.CENTER);
            } catch (Throwable e) {
                log(e);
            }
        }
        return battleFieldSizeLabel;
    }

    /**
     * Return the battleFieldWidthSlider
     *
     * @return javax.swing.JSlider
     */
    private JSlider getBattleFieldWidthSlider() {
        if (battleFieldWidthSlider == null) {
            try {
                battleFieldWidthSlider = new JSlider();
                battleFieldWidthSlider.setName("JWidthSlider");
                battleFieldWidthSlider.setValue(800);
                battleFieldWidthSlider.setMajorTickSpacing(100);
                battleFieldWidthSlider.setSnapToTicks(true);
                battleFieldWidthSlider.setMaximum(5000);
                battleFieldWidthSlider.setMinimum(400);
                battleFieldWidthSlider.setMinorTickSpacing(10);
                battleFieldWidthSlider.addChangeListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return battleFieldWidthSlider;
    }

    /**
     * Return the battleFieldHeightSlider
     *
     * @return javax.swing.JSlider
     */
    private JSlider getBattleFieldHeightSlider() {
        if (battleFieldHeightSlider == null) {
            try {
                battleFieldHeightSlider = new JSlider();
                battleFieldHeightSlider.setName("battleFieldHeightSlider");
                battleFieldHeightSlider.setPaintLabels(false);
                battleFieldHeightSlider.setValue(600);
                battleFieldHeightSlider.setMajorTickSpacing(100);
                battleFieldHeightSlider.setSnapToTicks(true);
                battleFieldHeightSlider.setMaximum(5000);
                battleFieldHeightSlider.setMinimum(400);
                battleFieldHeightSlider.setMinorTickSpacing(10);
                battleFieldHeightSlider.setOrientation(JSlider.VERTICAL);
                battleFieldHeightSlider.addChangeListener(eventHandler);

            } catch (Throwable e) {
                log(e);
            }
        }
        return battleFieldHeightSlider;
    }

    /**
     * Comment
     */
    public void battleFieldSliderValuesChanged() {
        this.battleFieldWidth = getBattleFieldWidthSlider().getValue();
        this.battleFieldHeight = getBattleFieldHeightSlider().getValue();
        getBattleFieldSizeLabel().setText(battleFieldWidth + " x " + battleFieldHeight);
        repaint();
        return;
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/26/2001 7:57:51 PM)
     *
     * @return int
     */
    public int getBattleFieldHeight() {
        return getBattleFieldHeightSlider().getValue();
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/26/2001 8:08:50 PM)
     *
     * @param width int
     */
    public void setBattleFieldHeight(int height) {
        getBattleFieldHeightSlider().setValue(height);
        battleFieldSliderValuesChanged();
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/26/2001 7:57:51 PM)
     *
     * @return int
     */
    public int getBattleFieldWidth() {
        return getBattleFieldWidthSlider().getValue();
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/26/2001 8:08:50 PM)
     *
     * @param width int
     */
    public void setBattleFieldWidth(int width) {
        getBattleFieldWidthSlider().setValue(width);
        battleFieldSliderValuesChanged();
    }

    /**
     * Return the BattleField property value.
     *
     * @return javax.swing.JPanel
     */
    private void initialize() {
        try {
            setName("BattleField");
            buildMapList(null);
            //currentMap = battleManager.getMapFilename();
            setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            setLayout(new BorderLayout());
            add(getMainPanel(), BorderLayout.CENTER);
            add(getMapsPanel(), BorderLayout.SOUTH);
        } catch (Throwable e) {
            log(e);
        }
    }

    /**
     * The upper half of the Battle Field tab in the New Battle menu.
     * Includes the battle size buttons and the slider bars giving
     * the user the ability to change the map size. (You cannot change
     * the size of a loaded map).
     *
     * @return mainPanel
     */
    private JPanel getMainPanel() {
        if (mainPanel == null) {
            try {
                mainPanel = new JPanel();
                mainPanel.setName("mainPanel");

                mainPanel.setPreferredSize(new Dimension(550, 250));
                GridBagLayout layout = new GridBagLayout();
                mainPanel.setLayout(layout);

                GridBagConstraints constraints = new GridBagConstraints();

                JPanel j1 = new JPanel();
                j1.setLayout(new BorderLayout());
                j1.setPreferredSize(new Dimension(200, 240));
                j1.add(getButtonsPanel(), BorderLayout.EAST);

                constraints.gridwidth = 1;
                constraints.gridheight = 1;
                constraints.weightx = 1;
                constraints.weighty = 1;
                constraints.anchor = GridBagConstraints.WEST;
                layout.setConstraints(j1, constraints);
                mainPanel.add(j1);

                JPanel j2 = new JPanel();
                j2.setLayout(new BorderLayout());
                j2.setPreferredSize(new Dimension(300, 240));
                j2.add(getSliderPanel(), BorderLayout.WEST);

                constraints.gridwidth = 2;
                constraints.gridheight = 1;
                constraints.weightx = 1;
                constraints.weighty = 1;
                constraints.anchor = GridBagConstraints.CENTER;
                layout.setConstraints(j2, constraints);
                mainPanel.add(j2);


            } catch (Throwable e) {
                log(e);
            }
        }
        return mainPanel;
    }

    /**
     * Return the buttonsPanel.
     *
     * @return buttonsPanel
     */
    private JPanel getButtonsPanel() {
        if (buttonsPanel == null) {
            try {
                buttonsPanel = new JPanel();
                buttonsPanel.setLayout(new java.awt.GridLayout(9, 1)); //buttonsPanel,BoxLayout.Y_AXIS));
                buttonsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Default Sizes"));
                buttonsPanel.add(getButton400x400());
                buttonsPanel.add(getButton600x400());
                buttonsPanel.add(getButton600x600());
                buttonsPanel.add(getButton800x600());
                buttonsPanel.add(getButton800x800());
                buttonsPanel.add(getButton1000x800());
                buttonsPanel.add(getButton1000x1000());
                buttonsPanel.add(getButton2000x2000());
                buttonsPanel.add(getButton5000x5000());

            } catch (Throwable e) {
                log(e);
            }
        }
        return buttonsPanel;
    }

    /**
     * Return the sliderPanel.
     *
     * @return sliderPanel
     */
    private JPanel getSliderPanel() {
        if (sliderPanel == null) {
            try {
                sliderPanel = new JPanel();
                sliderPanel.setLayout(new BorderLayout());
                sliderPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Battlefield Size"));
                sliderPanel.add(getBattleFieldHeightSlider(), BorderLayout.EAST);

                // We want the BorderLayout to put the vertical scrollbar
                // to the right of the horizontal one... so small hack:
                JPanel j = new JPanel();
                j.setLayout(new BorderLayout());
                j.add(getBattleFieldWidthSlider(), BorderLayout.SOUTH);
                j.add(getBattleFieldSizeLabel(), BorderLayout.CENTER);

                sliderPanel.add(j, BorderLayout.CENTER);
            } catch (Throwable e) {
                log(e);
            }
        }
        return sliderPanel;
    }

    /**
     * This panel encompasses the lower half of the BattleField tab which
     * gives the user the ability to select a map for the new battle
     * without having to use the Map menu bar.
     *
     * @return mapsPanel
     */
    private JPanel getMapsPanel() {
        if (mapsPanel == null) {
            try {
                mapsPanel = new JPanel();
                mapsPanel.setPreferredSize(new Dimension(550, 125));

                mapsPanel.setLayout(new BorderLayout());
                mapsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Maps"));

                JPanel l = new JPanel();
                l.setLayout(new BorderLayout());
                l.setBackground(Color.gray);
                l.setPreferredSize(new Dimension(125, 150));
                l.add(getAvailableMapsScrollPane(), BorderLayout.NORTH);
                l.add(getMapSelectButton(), BorderLayout.SOUTH);

                mapsPanel.add(l, BorderLayout.WEST);
                mapsPanel.add(getMapButtonsPanel(), BorderLayout.EAST);
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapsPanel;
    }

    /**
     * The panel contains the "browse" and "load" buttons as well as both
     * text fields on the BattleField tab in the New Battle menu
     *
     * @return mapButtonsPanel
     */
    private JPanel getMapButtonsPanel() {
        if (mapButtonsPanel == null) {
            try {
                mapButtonsPanel = new JPanel();
                mapButtonsPanel.setPreferredSize(new Dimension(400, 150));

                //mapButtonsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), ""));

                GridBagLayout layout = new GridBagLayout();

                mapButtonsPanel.setLayout(layout);
                GridBagConstraints c = new GridBagConstraints();

                c.insets = new Insets(5, 5, 5, 5);
                c.anchor = GridBagConstraints.NORTHWEST;

                c.fill = GridBagConstraints.HORIZONTAL;
                c.gridwidth = 2;
                c.weightx = 0;
                c.gridx = 2;

                mapButtonsPanel.add(new JLabel("Input path to maps folder"), c);

                c.fill = GridBagConstraints.NONE;
                c.gridwidth = 1;
                c.gridy = 1;
                c.gridx = 1;
                c.insets = new Insets(3, 3, 3, 3);
                mapButtonsPanel.add(getMapBrowserButton(), c);

                c.fill = GridBagConstraints.HORIZONTAL;
                c.weightx = 1;
                c.gridx = 2;
                c.insets = new Insets(5, 5, 5, 5);
                mapButtonsPanel.add(getPathTextField(), c);

                c.fill = GridBagConstraints.HORIZONTAL;
                c.gridwidth = 2;
                c.weightx = 0;
                c.gridx = 2;
                c.gridy = 2;

                mapButtonsPanel.add(new JLabel("Path to map"), c);

                c.fill = GridBagConstraints.NONE;
                c.gridwidth = 1;
                c.gridy = 3;
                c.gridx = 1;
                c.insets = new Insets(3, 3, 3, 3);
                mapButtonsPanel.add(getMapBrowserButton2(), c);

                c.fill = GridBagConstraints.HORIZONTAL;
                c.weightx = 1;
                c.gridx = 2;
                c.gridy = 3;
                c.insets = new Insets(5, 5, 5, 5);
                mapButtonsPanel.add(getPathTextField2(), c);
//
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapButtonsPanel;
    }

    /**
     * @return mapBrowserButton
     */
    private JButton getMapBrowserButton() {
        if (mapBrowserButton == null) {
            try {
                mapBrowserButton = new JButton();
                mapBrowserButton.setName("mapBrowserButton");
                mapBrowserButton.setText("browse");
                mapBrowserButton.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapBrowserButton;
    }

    /**
     * @return mapBrowserButton2
     */
    private JButton getMapBrowserButton2() {
        if (mapBrowserButton2 == null) {
            try {
                mapBrowserButton2 = new JButton();
                mapBrowserButton2.setName("mapBrowserButton2");
                mapBrowserButton2.setText(" load ");
                mapBrowserButton2.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapBrowserButton2;
    }

    /**
     * @return mapSelectButton
     */
    private JButton getMapSelectButton() {
        if (mapSelectButton == null) {
            try {
                mapSelectButton = new JButton();
                mapSelectButton.setPreferredSize(new Dimension(50, 25));
                mapSelectButton.setName("mapSelectButton");
                mapSelectButton.setText("Select");
                mapSelectButton.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapSelectButton;
    }

    /**
     * Used for the "select" button in the battleField tab to select
     * a particular map from the list compiled in the scroll pane.
     */
    public void mapSelectButtonActionPerformed() {
        for (int i = 0; i < mapList.size(); i++) {
            if (getAvailableMapsList().isSelectedIndex(i)) {
                String newMapFilename = mapList.elementAt(i).getFilePath();

                //currentMap=mapList.elementAt(i).getFileName();
                pathTextField2.setText(newMapFilename);
                //battleManager.setMapFilename(newMapFilename);
            }
        }
    }

    /**
     * Used for the "browse" button in the battleField tab to specify
     * map file directory.
     */
    public void browserButtonActionPerformed() {
        JFileChooser chooser = new JFileChooser();

        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        javax.swing.filechooser.FileFilter filter = new javax.swing.filechooser.FileFilter() {
            public boolean accept(File pathname) {
                if (pathname.isDirectory()) {
                    return true;
                }
                String fn = pathname.getName();
                int idx = fn.lastIndexOf('.');
                String extension = "";
                if (idx >= 0) {
                    extension = fn.substring(idx);
                }
                return extension.equalsIgnoreCase(".maps");
            }

            public String getDescription() {
                return "Maps";
            }
        };
        chooser.setFileFilter(filter);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            pathTextField.setText(chooser.getSelectedFile().getAbsolutePath());
            File f = new File(chooser.getSelectedFile().getAbsolutePath());
            buildMapList(f);
        }

    }

    /**
     * Used for the "load" button in the BattleField Tab to specify a map file.
     */
    public void browserButtonActionPerformed2() {
        JFileChooser chooser = new JFileChooser();

        javax.swing.filechooser.FileFilter filter = new javax.swing.filechooser.FileFilter() {
            public boolean accept(File pathname) {
                if (pathname.isDirectory()) {
                    return true;
                }
                String fn = pathname.getName();
                int idx = fn.lastIndexOf('.');
                String extension = "";
                if (idx >= 0) {
                    extension = fn.substring(idx);
                }
                return extension.equalsIgnoreCase(".maps");
            }

            public String getDescription() {
                return "Maps";
            }
        };
        chooser.setFileFilter(filter);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            pathTextField2.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    /**
     * Field for absolute path to map folder.  This field is used
     * in buildMapList to construct a list of map files in this
     * directory.
     *
     * @return pathTextField
     */
    public JTextField getPathTextField() {
        if (pathTextField == null) {
            pathTextField = new JTextField("", 60);
        }
        return pathTextField;
    }

    /**
     * Field for absolute path to a map file. This field is
     * loaded by NewBattleDialog to determine the map for a new battle
     *
     * @return pathTextField2
     */
    public JTextField getPathTextField2() {
        if (pathTextField2 == null) {
            pathTextField2 = new JTextField("", 60);
        }
        return pathTextField2;
    }

    /**
     * Returns a scroll pane containing the list of map files
     *
     * @return availableMapsScrollPane
     */
    private JScrollPane getAvailableMapsScrollPane() {
        if (availableMapsScrollPane == null) {
            try {
                availableMapsScrollPane = new JScrollPane();
                availableMapsScrollPane.setPreferredSize(new Dimension(150, 75));
                availableMapsScrollPane.setName("availibleMapsScrollPane");
                availableMapsScrollPane.setViewportView(getAvailableMapsList());
            } catch (Throwable e) {
                log(e);
            }
        }
        return availableMapsScrollPane;
    }

    /**
     * Creates a JList from the list compiled by buildMapList(File dir)
     *
     * @return availableMapsList
     */
    private JList getAvailableMapsList() {
        if (availableMapsList == null) {
            try {
                availableMapsList = new JList(mapListModel);
                availableMapsList.setName("availableMapsList");
                availableMapsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                MouseListener mouseListener = new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        if (e.getClickCount() == 2) {
                            mapSelectButtonActionPerformed();
                        }
                    }
                };
                availableMapsList.addMouseListener(mouseListener);
                availableMapsList.addListSelectionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return availableMapsList;
    }

    /**
     * Build the list of map files (.maps) in a given directory
     * If the dir is null, builds a list of files in the default
     * robocode maps directory
     * <p>
     * Creation date: (6/20/2007)
     *
     * @param dir directory to look for map files
     */
    public void buildMapList(File dir) {

        try {
            //mapList = new FileSpecificationVector();
            mapList = this.mapManager.getMapList(dir);
            mapListModel.removeAllElements();
            //mapListString = getMapsAsString();
            // System.out.println("Done building map list.");
            for (int i = 0; i < mapList.size(); i++) {
                //	System.out.println(mapList.elementAt(i).getFileName());
                //	mapListString[i]=mapList.elementAt(i).getFileName();
                mapListModel.addElement(mapList.elementAt(i).getFileName());
            }
        } catch (Throwable e) {
            log(e);
        }
    }

    class EventHandler implements ActionListener, ChangeListener, ListSelectionListener {
        public void actionPerformed(java.awt.event.ActionEvent e) {
            if (e.getSource() == NewBattleBattleFieldTab.this.getButton400x400()) {
                button400x400ActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getButton600x400()) {
                button600x400ActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getButton600x600()) {
                button600x600ActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getButton800x600()) {
                button800x600ActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getButton800x800()) {
                button800x800ActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getButton1000x800()) {
                button1000x800ActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getButton1000x1000()) {
                button1000x1000ActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getButton2000x2000()) {
                button2000x2000ActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getButton5000x5000()) {
                button5000x5000ActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getMapBrowserButton()) {
                browserButtonActionPerformed();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getMapBrowserButton2()) {
                browserButtonActionPerformed2();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getMapSelectButton()) {
                mapSelectButtonActionPerformed();
            }

        }

        public void stateChanged(javax.swing.event.ChangeEvent e) {
            if (e.getSource() == NewBattleBattleFieldTab.this.getBattleFieldHeightSlider()) {
                battleFieldSliderValuesChanged();
            }
            if (e.getSource() == NewBattleBattleFieldTab.this.getBattleFieldWidthSlider()) {
                battleFieldSliderValuesChanged();
            }
        }

        public void valueChanged(ListSelectionEvent e) {
            if (e.getValueIsAdjusting() == true) {
                return;
            }

            if (e.getSource() == getAvailableMapsList()) {
//				System.out.println(availableMapsList.isSelectedIndex(0));
//				System.out.println(availableMapsList.isSelectedIndex(1));
//				System.out.println(availableMapsList.isSelectedIndex(2));
            }
        }
    }

}
/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode.dialog;

import robocode.manager.RobocodeManager;
import robocode.util.Utils;

import javax.swing.*;

/**
 * Handles menu display and interaction for Robocode.
 * Creation date: (8/22/2001 1:15:52 PM)
 *
 * @author: Mathew Nelson
 */
public class RobocodeMenuBar extends JMenuBar {

    // Map menu
    public JMenu mapMenu = null;
    public EventHandler eventHandler = new EventHandler();
    // Battle menu
    private JMenu battleMenu = null;
    private JMenuItem battleNewMenuItem = null;
    private JMenuItem battleOpenMenuItem = null;
    private JSeparator battleMenuSeparator1 = null;
    private JMenuItem battleSaveMenuItem = null;
    private JMenuItem battleSaveAsMenuItem = null;
    private JMenuItem battleExitMenuItem = null;
    // Robot menu
    private JMenu robotMenu = null;
    private JMenuItem robotEditorMenuItem = null;
    private JMenuItem robotImportMenuItem = null;
    private JMenuItem robotPackagerMenuItem = null;
    // Team menu
    private JMenu teamMenu = null;
    private JMenuItem teamCreateTeamMenuItem = null;
    private JMenuItem mapEditorMapMenuItem = null;
    private JMenuItem mapLoadMapMenuItem = null;
    private JMenuItem mapSaveMapMenuItem = null;
    private JMenuItem mapSaveAsMapMenuItem = null;
    // Options menu
    private JMenu optionsMenu = null;
    private JMenuItem optionsPreferencesMenuItem = null;
    private JMenuItem optionsFitWindowMenuItem = null;
    // Help Menu
    private JMenu helpMenu = null;
    private JMenuItem helpOnlineHelpMenuItem = null;
    private JMenuItem helpCheckForNewVersionMenuItem = null;
    private JMenuItem helpVersionsTxtMenuItem = null;
    private JMenuItem helpRobocodeApiMenuItem = null;
    private JMenuItem helpFaqMenuItem = null;
    private JMenuItem helpAboutMenuItem = null;
    private RobocodeFrame robocodeFrame = null;
    private RobocodeManager manager = null;

    /**
     * RoboCodeMenu constructor comment.
     */
    public RobocodeMenuBar(RobocodeManager manager, RobocodeFrame robocodeFrame) {
        super();
        this.manager = manager;
        this.robocodeFrame = robocodeFrame;
        setName("RobocodeMenu");
        add(getBattleMenu());
        add(getRobotMenu());
        add(getMapMenu());
        add(getOptionsMenu());
        add(getHelpMenu());
    }

    /**
     * Comment
     */
    public void battleExitActionPerformed() {
        java.awt.AWTEvent
                evt =
                new java.awt.event.WindowEvent(robocodeFrame, java.awt.event.WindowEvent.WINDOW_CLOSING);
        robocodeFrame.dispatchEvent(evt);
        return;
    }

    /**
     * Handle battleNew menu item action
     */
    public void battleNewActionPerformed() {

        manager.getWindowManager().showNewBattleDialog(manager.getBattleManager().getBattleProperties());

        return;
    }

    /**
     * Comment
     */
    public void battleOpenActionPerformed() {
        manager.getWindowManager().showBattleOpenDialog();
        return;
    }

    /**
     * Comment
     */
    public void battleSaveActionPerformed() {
        manager.getBattleManager().saveBattle();
        return;
    }

    /**
     * Comment
     */
    public void battleSaveAsActionPerformed() {
        manager.getBattleManager().saveBattleAs();
        return;
    }

    /**
     * Return the battleExitMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getBattleExitMenuItem() {
        if (battleExitMenuItem == null) {
            try {
                battleExitMenuItem = new JMenuItem();
                battleExitMenuItem.setName("battleExitMenuItem");
                battleExitMenuItem.setText("Exit");
                battleExitMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return battleExitMenuItem;
    }

    /**
     * Return the Battle Menu
     *
     * @return javax.swing.JMenu
     */
    public JMenu getBattleMenu() {
        if (battleMenu == null) {
            try {
                battleMenu = new JMenu();
                battleMenu.setName("battleMenu");
                battleMenu.setText("Battle");

                battleMenu.add(getBattleNewMenuItem());
                battleMenu.add(getBattleOpenMenuItem());
                battleMenu.add(getBattleMenuSeparator1());
                battleMenu.add(getBattleSaveMenuItem());
                battleMenu.add(getBattleSaveAsMenuItem());
                battleMenu.add(getBattleExitMenuItem());

                battleMenu.addMenuListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return battleMenu;
    }

    /**
     * Return the battleMenuSeparator1.
     *
     * @return javax.swing.JSeparator
     */
    private JSeparator getBattleMenuSeparator1() {
        if (battleMenuSeparator1 == null) {
            try {
                battleMenuSeparator1 = new JSeparator();
                battleMenuSeparator1.setName("battleMenuSeparator1");
            } catch (Throwable e) {
                log(e);
            }
        }
        return battleMenuSeparator1;
    }

    /**
     * Return the battleNewMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getBattleNewMenuItem() {
        if (battleNewMenuItem == null) {
            try {
                battleNewMenuItem = new JMenuItem();
                battleNewMenuItem.setName("battleNewMenuItem");
                battleNewMenuItem.setText("New");
                battleNewMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return battleNewMenuItem;
    }

    /**
     * Return the battleOpenMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getBattleOpenMenuItem() {
        if (battleOpenMenuItem == null) {
            try {
                battleOpenMenuItem = new JMenuItem();
                battleOpenMenuItem.setName("battleOpenMenuItem");
                battleOpenMenuItem.setText("Open");
                battleOpenMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return battleOpenMenuItem;
    }

    /**
     * Return the battleSaveAsMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    public JMenuItem getBattleSaveAsMenuItem() {
        if (battleSaveAsMenuItem == null) {
            try {
                battleSaveAsMenuItem = new JMenuItem();
                battleSaveAsMenuItem.setName("battleSaveAsMenuItem");
                battleSaveAsMenuItem.setText("Save As");
                battleSaveAsMenuItem.setEnabled(false);
                battleSaveAsMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return battleSaveAsMenuItem;
    }

    /**
     * Return the battleSaveMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    public JMenuItem getBattleSaveMenuItem() {
        if (battleSaveMenuItem == null) {
            try {
                battleSaveMenuItem = new JMenuItem();
                battleSaveMenuItem.setName("battleSaveMenuItem");
                battleSaveMenuItem.setText("Save");
                battleSaveMenuItem.setEnabled(false);
                battleSaveMenuItem.addActionListener(eventHandler);
            } catch (Exception e) {
                log(e);
            }
        }
        return battleSaveMenuItem;
    }

    /**
     * Return the helpAboutMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getHelpAboutMenuItem() {
        if (helpAboutMenuItem == null) {
            try {
                helpAboutMenuItem = new JMenuItem();
                helpAboutMenuItem.setName("helpAboutMenuItem");
                helpAboutMenuItem.setText("About");
                helpAboutMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return helpAboutMenuItem;
    }

    /**
     * Return the helpCheckForNewVersion menu item.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getHelpCheckForNewVersionMenuItem() {
        if (helpCheckForNewVersionMenuItem == null) {
            try {
                helpCheckForNewVersionMenuItem = new JMenuItem();
                helpCheckForNewVersionMenuItem.setName("helpCheckForNewVersionMenuItem");
                helpCheckForNewVersionMenuItem.setText("Check for new version");
                helpCheckForNewVersionMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return helpCheckForNewVersionMenuItem;
    }

    /**
     * Return the Help Menu.
     *
     * @return javax.swing.JMenu
     */
    public JMenu getHelpMenu() {
        if (helpMenu == null) {
            try {
                helpMenu = new JMenu();
                helpMenu.setName("helpMenu");
                helpMenu.setText("Help");
                helpMenu.add(getHelpOnlineHelpMenuItem());
                helpMenu.add(getHelpRobocodeApiMenuItem());
                helpMenu.add(getHelpCheckForNewVersionMenuItem());
                helpMenu.add(getHelpVersionsTxtMenuItem());
                helpMenu.add(getHelpFaqMenuItem());
                helpMenu.add(getHelpAboutMenuItem());
                helpMenu.addMenuListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return helpMenu;
    }

    /**
     * Return the helpOnlineHelpMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getHelpFaqMenuItem() {
        if (helpFaqMenuItem == null) {
            try {
                helpFaqMenuItem = new JMenuItem();
                helpFaqMenuItem.setName("helpFaqMenuItem");
                helpFaqMenuItem.setText("Robocode FAQ");
                helpFaqMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return helpFaqMenuItem;
    }

    /**
     * Return the helpOnlineHelpMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getHelpOnlineHelpMenuItem() {
        if (helpOnlineHelpMenuItem == null) {
            try {
                helpOnlineHelpMenuItem = new JMenuItem();
                helpOnlineHelpMenuItem.setName("helpOnlineHelpMenuItem");
                helpOnlineHelpMenuItem.setText("Online Help");
                helpOnlineHelpMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return helpOnlineHelpMenuItem;
    }

    /**
     * Return the helpVersionsTxtMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getHelpVersionsTxtMenuItem() {
        if (helpVersionsTxtMenuItem == null) {
            try {
                helpVersionsTxtMenuItem = new JMenuItem();
                helpVersionsTxtMenuItem.setName("VersionsTxt");
                helpVersionsTxtMenuItem.setText("Version Info");
                helpVersionsTxtMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return helpVersionsTxtMenuItem;
    }

    /**
     * Return the helpRobocodeApiMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getHelpRobocodeApiMenuItem() {
        if (helpRobocodeApiMenuItem == null) {
            try {
                helpRobocodeApiMenuItem = new JMenuItem();
                helpRobocodeApiMenuItem.setName("helpRobocodeApiMenuItem");
                helpRobocodeApiMenuItem.setText("Robocode API");
                helpRobocodeApiMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return helpRobocodeApiMenuItem;
    }

    /**
     * Return the optionsPreferencesMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getOptionsFitWindowMenuItem() {
        if (optionsFitWindowMenuItem == null) {
            try {
                optionsFitWindowMenuItem = new JMenuItem();
                optionsFitWindowMenuItem.setName("optionsFitWindowMenuItem");
                optionsFitWindowMenuItem.setText("Default Window Size");
                optionsFitWindowMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return optionsFitWindowMenuItem;
    }

    /**
     * Return the Options Menu.
     *
     * @return javax.swing.JMenu
     */
    private JMenu getOptionsMenu() {
        if (optionsMenu == null) {
            try {
                optionsMenu = new JMenu();
                optionsMenu.setName("optionsMenu");
                optionsMenu.setText("Options");
                optionsMenu.add(getOptionsPreferencesMenuItem());
                optionsMenu.add(getOptionsFitWindowMenuItem());
                optionsMenu.addMenuListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return optionsMenu;
    }

    /**
     * Return the optionsPreferencesMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getOptionsPreferencesMenuItem() {
        if (optionsPreferencesMenuItem == null) {
            try {
                optionsPreferencesMenuItem = new JMenuItem();
                optionsPreferencesMenuItem.setName("optionsPreferencesMenuItem");
                optionsPreferencesMenuItem.setText("Preferences");
                optionsPreferencesMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return optionsPreferencesMenuItem;
    }

    /**
     * Return the robotEditorMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getRobotEditorMenuItem() {
        if (robotEditorMenuItem == null) {
            try {
                robotEditorMenuItem = new JMenuItem();
                robotEditorMenuItem.setName("robotEditorMenuItem");
                robotEditorMenuItem.setText("Editor");
                robotEditorMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return robotEditorMenuItem;
    }

    /**
     * Return the robotImportMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getRobotImportMenuItem() {
        if (robotImportMenuItem == null) {
            try {
                robotImportMenuItem = new JMenuItem();
                robotImportMenuItem.setName("robotImportMenuItem");
                robotImportMenuItem.setText("Import downloaded robot");
                robotImportMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return robotImportMenuItem;
    }

    /**
     * Return the Robot Menu.
     *
     * @return javax.swing.JMenu
     */
    public JMenu getRobotMenu() {
        if (robotMenu == null) {
            try {
                robotMenu = new JMenu();
                robotMenu.setName("robotMenu");
                robotMenu.setText("Robot");
                robotMenu.add(getRobotEditorMenuItem());
                robotMenu.add(getRobotImportMenuItem());
                robotMenu.add(getRobotPackagerMenuItem());
                robotMenu.add(getTeamMenu());
                robotMenu.addMenuListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return robotMenu;
    }

    /**
     * Return the robotPackagerMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getRobotPackagerMenuItem() {
        if (robotPackagerMenuItem == null) {
            try {
                robotPackagerMenuItem = new JMenuItem();
                robotPackagerMenuItem.setName("robotPackagerMenuItem");
                robotPackagerMenuItem.setText("Package robot for upload");
                robotPackagerMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return robotPackagerMenuItem;
    }

    /**
     * Return the Map Menu.
     *
     * @return javax.swing.JMenu
     */
    public JMenu getMapMenu() {
        if (mapMenu == null) {
            try {
                mapMenu = new JMenu();
                mapMenu.setName("mapMenu");
                mapMenu.setText("Maps");

                mapMenu.add(getMapEditorMapMenuItem());
                mapMenu.add(getMapLoadMapMenuItem());
                mapMenu.addMenuListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapMenu;
    }

    /**
     * Return the mapCreateMapMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getMapEditorMapMenuItem() {
        if (mapEditorMapMenuItem == null) {
            try {
                mapEditorMapMenuItem = new JMenuItem();
                mapEditorMapMenuItem.setName("mapEditorMapMenuItem");
                mapEditorMapMenuItem.setText("Editor");
                mapEditorMapMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapEditorMapMenuItem;
    }

    /**
     * Return the mapLoadMapMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getMapLoadMapMenuItem() {
        if (mapLoadMapMenuItem == null) {
            try {
                mapLoadMapMenuItem = new JMenuItem();
                mapLoadMapMenuItem.setName("mapLoadMapMenuItem");
                mapLoadMapMenuItem.setText("Load Map");
                mapLoadMapMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapLoadMapMenuItem;
    }

    /**
     * Return the mapSaveMapMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    public JMenuItem getMapSaveMapMenuItem() {
        if (mapSaveMapMenuItem == null) {
            try {
                mapSaveMapMenuItem = new JMenuItem();
                mapSaveMapMenuItem.setName("mapSaveMapMenuItem");
                mapSaveMapMenuItem.setText("Save");
                mapSaveMapMenuItem.setEnabled(false);
                mapSaveMapMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapSaveMapMenuItem;
    }

    /**
     * Return the mapSaveAsMapMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    public JMenuItem getMapSaveAsMapMenuItem() {
        if (mapSaveAsMapMenuItem == null) {
            try {
                mapSaveAsMapMenuItem = new JMenuItem();
                mapSaveAsMapMenuItem.setName("mapSaveAsMapMenuItem");
                mapSaveAsMapMenuItem.setText("Save As");
                mapSaveAsMapMenuItem.setEnabled(false);
                mapSaveAsMapMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return mapSaveAsMapMenuItem;
    }

    /**
     * Perform action for creating a new map
     */
    public void mapEditorMapActionPerformed() {
        // replace the argument of this command with
        // function call needed for creating new map
        manager.getWindowManager().showRobocodeEditor(true);
        //manager.getWindowManager().showNewMapDialog(manager.getBattleManager().getBattleProperties());

        return;
    }

    /**
     * Perform action for editing an old map
     */
    public void mapLoadMapActionPerformed() {
        manager.getWindowManager().showMapOpenDialog();
        return;
    }

    /**
     * Return the Team Menu.
     *
     * @return javax.swing.JMenu
     */
    public JMenu getTeamMenu() {
        if (teamMenu == null) {
            try {
                teamMenu = new JMenu();
                teamMenu.setName("teamMenu");
                teamMenu.setText("Team");
                teamMenu.add(getTeamCreateTeamMenuItem());
                teamMenu.addMenuListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return teamMenu;
    }

    /**
     * Return the teamCreateTeamMenuItem.
     *
     * @return javax.swing.JMenuItem
     */
    private JMenuItem getTeamCreateTeamMenuItem() {
        if (teamCreateTeamMenuItem == null) {
            try {
                teamCreateTeamMenuItem = new JMenuItem();
                teamCreateTeamMenuItem.setName("teamCreateTeamMenuItem");
                teamCreateTeamMenuItem.setText("Create Team");
                teamCreateTeamMenuItem.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return teamCreateTeamMenuItem;
    }

    /**
     * Comment
     */
    public void teamCreateTeamActionPerformed() {
        manager.getWindowManager().showCreateTeamDialog();
    }

    /**
     * Comment
     */
    public void helpAboutActionPerformed() {
        manager.getWindowManager().showAboutBox();
        return;
    }

    /**
     * Comment
     */
    public void helpCheckForNewVersionActionPerformed() {
        manager.getVersionManager().checkForNewVersion(true);
        return;
    }

    /**
     * Comment
     */
    public void helpFaqActionPerformed() {

        manager.getWindowManager().showFaq();
        return;
    }

    /**
     * Comment
     */
    public void helpOnlineHelpActionPerformed() {

        manager.getWindowManager().showOnlineHelp();
        return;
    }

    /**
     * Comment
     */
    public void helpVersionsTxtActionPerformed() {

        manager.getWindowManager().showVersionsTxt();
        return;
    }

    /**
     * Comment
     */
    public void helpRobocodeApiActionPerformed() {
        manager.getWindowManager().showHelpApi();
        return;
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/22/2001 1:41:21 PM)
     *
     * @param e java.lang.Exception
     */
    public void log(Throwable e) {
        Utils.log(e);
    }

    /**
     * Comment
     */
    public void optionsFitWindowActionPerformed() {
        Utils.fitWindow(manager.getWindowManager().getRobocodeFrame());
        return;
    }

    /**
     * Comment
     */
    public void optionsPreferencesActionPerformed() {

        manager.getWindowManager().showOptionsPreferences();
        return;
    }

    /**
     * Comment
     */
    public void robotEditorActionPerformed() {
        manager.getWindowManager().showRobocodeEditor(false);
    }

    /**
     * Comment
     */
    public void robotImportActionPerformed() {
        manager.getWindowManager().showImportRobotDialog();
    }

    /**
     * Comment
     */
    public void robotPackagerActionPerformed() {
        manager.getWindowManager().showRobotPackager();
    }

    class EventHandler implements java.awt.event.ActionListener, javax.swing.event.MenuListener {
        public void actionPerformed(java.awt.event.ActionEvent e) {
            if (e.getSource() == RobocodeMenuBar.this.getBattleNewMenuItem()) {
                battleNewActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getBattleOpenMenuItem()) {
                battleOpenActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getBattleSaveMenuItem()) {
                battleSaveActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getBattleSaveAsMenuItem()) {
                battleSaveAsActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getBattleExitMenuItem()) {
                battleExitActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getRobotEditorMenuItem()) {
                robotEditorActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getRobotImportMenuItem()) {
                robotImportActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getRobotPackagerMenuItem()) {
                robotPackagerActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getTeamCreateTeamMenuItem()) {
                teamCreateTeamActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getMapEditorMapMenuItem()) {
                mapEditorMapActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getMapLoadMapMenuItem()) {
                mapLoadMapActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getOptionsPreferencesMenuItem()) {
                optionsPreferencesActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getOptionsFitWindowMenuItem()) {
                optionsFitWindowActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getHelpFaqMenuItem()) {
                helpFaqActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getHelpOnlineHelpMenuItem()) {
                helpOnlineHelpActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getHelpRobocodeApiMenuItem()) {
                helpRobocodeApiActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getHelpCheckForNewVersionMenuItem()) {
                helpCheckForNewVersionActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getHelpVersionsTxtMenuItem()) {
                helpVersionsTxtActionPerformed();
            }
            if (e.getSource() == RobocodeMenuBar.this.getHelpAboutMenuItem()) {
                helpAboutActionPerformed();
            }
        }

        public void menuDeselected(javax.swing.event.MenuEvent e) {
            manager.getBattleManager().resumeBattle();
        }

        public void menuSelected(javax.swing.event.MenuEvent e) {
            manager.getBattleManager().pauseBattle();
        }

        public void menuCanceled(javax.swing.event.MenuEvent e) {
        }
    }
}

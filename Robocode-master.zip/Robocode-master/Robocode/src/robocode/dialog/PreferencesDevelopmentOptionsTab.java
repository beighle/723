/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode.dialog;

import robocode.manager.RobocodeManager;
import robocode.manager.RobocodeProperties;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Insert the type's description here.
 * Creation date: (1/7/2001 11:07:52 PM)
 *
 * @author: Mathew A. Nelson
 */
public class PreferencesDevelopmentOptionsTab extends WizardPanel {
    public RobocodeManager manager = null;
    EventHandler eventHandler = new EventHandler();
    private JTextField optionsDevelopmentPathTextField = null;
    private JPanel developmentOptionsPanel = null;
    private JPanel optionsPanel;
    private JButton browseButton;
    private JTextField pathTextField;

    /**
     * PreferencesDialog constructor
     */
    public PreferencesDevelopmentOptionsTab(RobocodeManager manager) {
        super();
        this.manager = manager;
        initialize();
    }

    private JTextField getOptionsDevelopmentPathTextField() {
        if (optionsDevelopmentPathTextField == null) {
            try {
                optionsDevelopmentPathTextField = new JTextField("", 80);
                optionsDevelopmentPathTextField.setName("optionsDevelopmentPathTextField");
                optionsDevelopmentPathTextField.setMaximumSize(optionsDevelopmentPathTextField.getPreferredSize());
            } catch (Throwable e) {
                log(e);
            }
        }
        return optionsDevelopmentPathTextField;
    }

    private JButton getBrowseButton() {
        if (browseButton == null) {
            browseButton = new JButton("Browse");
            browseButton.setMnemonic('o');
            browseButton.setDisplayedMnemonicIndex(2);
            browseButton.addActionListener(eventHandler);
        }
        return browseButton;
    }

    private JTextField getPathTextField() {
        if (pathTextField == null) {
            pathTextField = new JTextField("", 80);
        }
        return pathTextField;
    }

    private JPanel getOptionsPanel() {
        if (optionsPanel == null) {
            optionsPanel = new JPanel();
            optionsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Development"));

            GridBagLayout layout = new GridBagLayout();

            optionsPanel.setLayout(layout);
            GridBagConstraints c = new GridBagConstraints();

            c.insets = new Insets(5, 5, 5, 5);
            c.anchor = GridBagConstraints.NORTHWEST;

            c.fill = GridBagConstraints.HORIZONTAL;
            c.gridwidth = 2;
            c.weightx = 0;

            optionsPanel.add(new JLabel("If you are using an external IDE to develop robots, you may enter the classpath to those robots here."), c);
            c.gridy = 1;
            optionsPanel.add(new JLabel("Example:  c:\\eclipse\\workspace\\MyRobotProject" +
                    java.io.File.pathSeparator +
                    "c:\\eclipse\\workspace\\AnotherRobotProject"), c);

            c.fill = GridBagConstraints.NONE;
            c.gridwidth = 1;
            c.gridy = 2;
            c.insets = new Insets(3, 3, 3, 3);
            optionsPanel.add(getBrowseButton(), c);

            c.fill = GridBagConstraints.HORIZONTAL;
            c.weightx = 1;
            c.gridx = 1;
            c.insets = new Insets(5, 5, 5, 5);
            optionsPanel.add(getPathTextField(), c);

            c.fill = GridBagConstraints.VERTICAL;
            c.weighty = 1;
            c.gridy = 3;
            optionsPanel.add(new JPanel(), c);
        }
        return optionsPanel;
    }

    private void initialize() {
        try {
            setLayout(new GridLayout(1, 2));
            add(getOptionsPanel());
            loadPreferences(manager.getProperties());
        } catch (Throwable e) {
            log(e);
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/4/2001 11:16:59 AM)
     *
     * @param props java.util.Properties
     */
    private void loadPreferences(RobocodeProperties robocodeProperties) {
        getOptionsDevelopmentPathTextField().setText(robocodeProperties.getOptionsDevelopmentPath());
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/4/2001 11:16:59 AM)
     *
     * @param props java.util.Properties
     */
    public void storePreferences() {
        manager.getProperties().setOptionsDevelopmentPath(getPathTextField().getText());
        manager.saveProperties();
    }

    public boolean isReady() {
        return true;
    }

    private class EventHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {

            if (e.getSource() == getBrowseButton()) {
                JFileChooser chooser = new JFileChooser();

                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                if (chooser.showOpenDialog(optionsPanel) == JFileChooser.APPROVE_OPTION) {
                    pathTextField.setText(chooser.getSelectedFile().getAbsolutePath());
                }
            }
        }
    }
}

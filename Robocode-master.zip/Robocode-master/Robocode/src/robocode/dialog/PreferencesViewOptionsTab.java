/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode.dialog;

import robocode.manager.RobocodeManager;
import robocode.manager.RobocodeProperties;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;

/**
 * Insert the type's description here.
 * Creation date: (1/7/2001 11:07:52 PM)
 *
 * @author: Mathew A. Nelson
 */
public class PreferencesViewOptionsTab extends WizardPanel {
    public RobocodeManager manager = null;
    EventHandler eventHandler = new EventHandler();
    private JCheckBox visibleRobotEnergyCheckBox = null;
    private JCheckBox visibleRobotNameCheckBox = null;
    private JCheckBox visibleScanArcsCheckBox = null;
    private JTextField desiredFpsTextField = null;
    private JLabel desiredFpsLabel = null;
    private JButton defaultsButton = null;
    private JCheckBox displayFpsCheckBox = null;
    private JCheckBox optionsBattleAllowColorChangesCheckBox = null;
    private JPanel visibleOptionsPanel = null;
    private JPanel fpsOptionsPanel = null;
    private JButton minFpsButton = null;
    private JButton defaultFpsButton = null;
    private JButton fastFpsButton = null;
    private JButton maxFpsButton = null;
    private int MINFPS = 1;
    private int DEFAULTFPS = 30;
    private int FASTFPS = 45;
    private int MAXFPS = 10000;

    /**
     * PreferencesDialog constructor
     */
    public PreferencesViewOptionsTab(RobocodeManager manager) {
        super();
        this.manager = manager;
        initialize();
    }

    /**
     * Comment
     */
    private void defaultsButtonActionPerformed() {
        getVisibleRobotEnergyCheckBox().setSelected(true);
        getVisibleRobotNameCheckBox().setSelected(true);
        getVisibleScanArcsCheckBox().setSelected(false);
        return;
    }

    /**
     * Comment
     */
    private void desiredFpsTextFieldStateChanged() {
        fireStateChanged();
        try {
            int fps = Integer.parseInt(getDesiredFpsTextField().getText());
            String s = "" + fps;
            if (fps < MINFPS) {
                s = "Too low, must be at least " + MINFPS;
            } else if (fps > MAXFPS) {
                s = "Too high, max is " + MAXFPS;
            }
            getDesiredFpsLabel().setText("Desired FPS: " + s);
        } catch (NumberFormatException e) {
            getDesiredFpsLabel().setText("Desired FPS: ???");
        }
        return;
    }

    private void maxFpsButtonActionPerformed() {
        getDesiredFpsTextField().setText("" + MAXFPS);
        return;
    }

    private void minFpsButtonActionPerformed() {
        getDesiredFpsTextField().setText("" + MINFPS);
        return;
    }

    private void fastFpsButtonActionPerformed() {
        getDesiredFpsTextField().setText("" + FASTFPS);
        return;
    }

    /**
     * Comment
     */
    private void defaultFpsButtonActionPerformed() {
        getDesiredFpsTextField().setText("" + DEFAULTFPS);
        return;
    }

    /**
     * Return the defaultsButton
     *
     * @return javax.swing.JButton
     */
    private JButton getDefaultsButton() {
        if (defaultsButton == null) {
            try {
                defaultsButton = new JButton();
                defaultsButton.setName("defaultsButton");
                defaultsButton.setText("Defaults");
                defaultsButton.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return defaultsButton;
    }

    /**
     * Return the desiredFpsLabel property value.
     *
     * @return javax.swing.JLabel
     */
    private JLabel getDesiredFpsLabel() {
        if (desiredFpsLabel == null) {
            try {
                desiredFpsLabel = new JLabel();
                desiredFpsLabel.setName("desiredFpsLabel");
                desiredFpsLabel.setText("Desired FPS: ");
            } catch (Throwable e) {
                log(e);
            }
        }
        return desiredFpsLabel;
    }

    /**
     * Return the fpsSlider property value.
     *
     * @return javax.swing.JSlider
     */
    private JTextField getDesiredFpsTextField() {
        if (desiredFpsTextField == null) {
            try {
                desiredFpsTextField = new JTextField();
                desiredFpsTextField.setName("desiredFpsTextField");
                desiredFpsTextField.setColumns(5);
                desiredFpsTextField.getDocument().addDocumentListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return desiredFpsTextField;
    }

    /**
     * Return the displayFpsCheckBox
     *
     * @return javax.swing.JCheckBox
     */
    private JCheckBox getDisplayFpsCheckBox() {
        if (displayFpsCheckBox == null) {
            try {
                displayFpsCheckBox = new JCheckBox();
                displayFpsCheckBox.setName("displayFpsCheckBox");
                displayFpsCheckBox.setText("Display FPS in titlebar");
            } catch (Throwable e) {
                log(e);
            }
        }
        return displayFpsCheckBox;
    }

    /**
     * Return the displayFpsCheckBox
     *
     * @return javax.swing.JCheckBox
     */
    private JCheckBox getOptionsBattleAllowColorChangesCheckBox() {
        if (optionsBattleAllowColorChangesCheckBox == null) {
            try {
                optionsBattleAllowColorChangesCheckBox = new JCheckBox();
                optionsBattleAllowColorChangesCheckBox.setName("optionsBattleAllowColorChangesCheckBox");
                optionsBattleAllowColorChangesCheckBox.setText("Allow robots to change colors repeatedly (Slow, not recommended)");
            } catch (Throwable e) {
                log(e);
            }
        }
        return optionsBattleAllowColorChangesCheckBox;
    }

    /**
     * Return the maxFpsButton
     *
     * @return javax.swing.JButton
     */
    private JButton getMaxFpsButton() {
        if (maxFpsButton == null) {
            try {
                maxFpsButton = new JButton();
                maxFpsButton.setName("maxFpsButton");
                maxFpsButton.setText("Max FPS");
                maxFpsButton.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return maxFpsButton;
    }

    /**
     * Return the defaultFpsButton
     *
     * @return javax.swing.JButton
     */
    private JButton getDefaultFpsButton() {
        if (defaultFpsButton == null) {
            try {
                defaultFpsButton = new JButton();
                defaultFpsButton.setName("defaultFpsButton");
                defaultFpsButton.setText("Default");
                defaultFpsButton.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return defaultFpsButton;
    }

    /**
     * Return the minFpsButton
     *
     * @return javax.swing.JButton
     */
    private JButton getMinFpsButton() {
        if (minFpsButton == null) {
            try {
                minFpsButton = new JButton();
                minFpsButton.setName("minFpsButton");
                minFpsButton.setText("Minimum");
                minFpsButton.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return minFpsButton;
    }

    /**
     * Return the fastFpsButton
     *
     * @return javax.swing.JButton
     */
    private JButton getFastFpsButton() {
        if (fastFpsButton == null) {
            try {
                fastFpsButton = new JButton();
                fastFpsButton.setName("fastFpsButton");
                fastFpsButton.setText("Fast");
                fastFpsButton.addActionListener(eventHandler);
            } catch (Throwable e) {
                log(e);
            }
        }
        return fastFpsButton;
    }

    /**
     * Return the fpsOptionsPanel
     *
     * @return javax.swing.JPanel
     */
    private JPanel getFpsOptionsPanel() {
        if (fpsOptionsPanel == null) {
            try {
                fpsOptionsPanel = new JPanel();
                fpsOptionsPanel.setName("fpsOptionsPanel");
                fpsOptionsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Frames Per Second"));

                GridBagLayout layout = new GridBagLayout();
                fpsOptionsPanel.setLayout(layout);

                GridBagConstraints constraints = new GridBagConstraints();
                constraints.fill = 1;
                constraints.weightx = 1;
                constraints.anchor = GridBagConstraints.NORTHWEST;

//			fpsOptionsPanel.setLayout(new BoxLayout(fpsOptionsPanel,BoxLayout.Y_AXIS));

                constraints.gridwidth = GridBagConstraints.REMAINDER;
                layout.setConstraints(getDisplayFpsCheckBox(), constraints);
                fpsOptionsPanel.add(getDisplayFpsCheckBox());


                JLabel label = new JLabel(" ");
                layout.setConstraints(label, constraints);
                fpsOptionsPanel.add(label);

                constraints.gridwidth = GridBagConstraints.REMAINDER;
                layout.setConstraints(getDesiredFpsLabel(), constraints);
                fpsOptionsPanel.add(getDesiredFpsLabel());
//			getDesiredFpsLabel().setAlignmentX(JLabel.CENTER_ALIGNMENT);
                getDesiredFpsLabel().setHorizontalAlignment(JLabel.CENTER);
//			getDesiredFpsLabel().setHorizontalTextPosition(JLabel.CENTER);

                JPanel p = new JPanel();
                JPanel q = new JPanel();
                q.setLayout(new GridLayout(1, 3));

                p.add(q);

                p.add(getDesiredFpsTextField());

                q = new JPanel();
                p.add(q);

                constraints.gridwidth = GridBagConstraints.REMAINDER;
                layout.setConstraints(p, constraints);
                fpsOptionsPanel.add(p);

                JLabel label2 = new JLabel(" ");
                layout.setConstraints(label2, constraints);
                fpsOptionsPanel.add(label2);

                constraints.gridwidth = 1;
                constraints.fill = 0;
                constraints.weighty = 1;
                constraints.weightx = 0;
                layout.setConstraints(getMinFpsButton(), constraints);
                fpsOptionsPanel.add(getMinFpsButton());

                layout.setConstraints(getDefaultFpsButton(), constraints);
                fpsOptionsPanel.add(getDefaultFpsButton());

                layout.setConstraints(getFastFpsButton(), constraints);
                fpsOptionsPanel.add(getFastFpsButton());

                constraints.weightx = 1;
                constraints.gridwidth = GridBagConstraints.REMAINDER;
                layout.setConstraints(getMaxFpsButton(), constraints);
                fpsOptionsPanel.add(getMaxFpsButton());
            } catch (Throwable e) {
                log(e);
            }
        }
        return fpsOptionsPanel;
    }

    /**
     * Return the displayOptionsPanel
     *
     * @return javax.swing.JPanel
     */
    private JPanel getVisibleOptionsPanel() {
        if (visibleOptionsPanel == null) {
            try {
                visibleOptionsPanel = new JPanel();
                visibleOptionsPanel.setName("displayOptionsPanel");
                visibleOptionsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Arena"));
                //BorderFactory.createEtchedBorder());
                visibleOptionsPanel.setLayout(new BoxLayout(visibleOptionsPanel, BoxLayout.Y_AXIS));
                visibleOptionsPanel.add(getVisibleRobotEnergyCheckBox());
                visibleOptionsPanel.add(getVisibleRobotNameCheckBox());
                visibleOptionsPanel.add(getVisibleScanArcsCheckBox());
                visibleOptionsPanel.add(getOptionsBattleAllowColorChangesCheckBox());
                visibleOptionsPanel.add(new JLabel(" "));
                visibleOptionsPanel.add(getDefaultsButton());
            } catch (Throwable e) {
                log(e);
            }
        }
        return visibleOptionsPanel;
    }

    /**
     * Return the visibleRobotEnergyCheckBox
     *
     * @return javax.swing.JCheckBox
     */
    private JCheckBox getVisibleRobotEnergyCheckBox() {
        if (visibleRobotEnergyCheckBox == null) {
            try {
                visibleRobotEnergyCheckBox = new JCheckBox();
                visibleRobotEnergyCheckBox.setName("visibleRobotEnergyCheckBox");
                visibleRobotEnergyCheckBox.setText("Visible Robot Energy");
            } catch (Throwable e) {
                log(e);
            }
        }
        return visibleRobotEnergyCheckBox;
    }

    /**
     * Return the visibleRobotNameCheckBox
     *
     * @return javax.swing.JCheckBox
     */
    private JCheckBox getVisibleRobotNameCheckBox() {
        if (visibleRobotNameCheckBox == null) {
            try {
                visibleRobotNameCheckBox = new JCheckBox();
                visibleRobotNameCheckBox.setName("visibleRobotNameCheckBox");
                visibleRobotNameCheckBox.setText("Visible Robot Name");
            } catch (Throwable e) {
                log(e);
            }
        }
        return visibleRobotNameCheckBox;
    }

    /**
     * Return the visibleScanArcsCheckBox
     *
     * @return javax.swing.JCheckBox
     */
    private JCheckBox getVisibleScanArcsCheckBox() {
        if (visibleScanArcsCheckBox == null) {
            try {
                visibleScanArcsCheckBox = new JCheckBox();
                visibleScanArcsCheckBox.setName("visibleScanArcsCheckBox");
                visibleScanArcsCheckBox.setText("Visible Scan Arcs (Cool, but may slow down game)");
            } catch (Throwable e) {
                log(e);
            }
        }
        return visibleScanArcsCheckBox;
    }

    /**
     * Initialize the class.
     */
    private void initialize() {
        try {
//		setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
            setLayout(new GridLayout(1, 2));
            add(getVisibleOptionsPanel());
            add(getFpsOptionsPanel());
            loadPreferences(manager.getProperties());
        } catch (Throwable e) {
            log(e);
        }
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/4/2001 11:16:59 AM)
     *
     * @param props java.util.Properties
     */
    private void loadPreferences(RobocodeProperties robocodeProperties) {
        getDisplayFpsCheckBox().setSelected(robocodeProperties.getOptionsViewFps());
        getVisibleRobotNameCheckBox().setSelected(robocodeProperties.getOptionsViewRobotNames());
        getVisibleRobotEnergyCheckBox().setSelected(robocodeProperties.getOptionsViewRobotEnergy());
        getVisibleScanArcsCheckBox().setSelected(robocodeProperties.getOptionsViewScanArcs());
        getDesiredFpsTextField().setText("" + robocodeProperties.getOptionsBattleDesiredFps());
        getOptionsBattleAllowColorChangesCheckBox().setSelected(robocodeProperties.getOptionsBattleAllowColorChanges());
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/4/2001 11:16:59 AM)
     *
     * @param props java.util.Properties
     */
    public void storePreferences() {
        manager.getProperties().setOptionsViewRobotNames(getVisibleRobotNameCheckBox().isSelected());
        manager.getProperties().setOptionsViewRobotEnergy(getVisibleRobotEnergyCheckBox().isSelected());
        manager.getProperties().setOptionsViewFps(getDisplayFpsCheckBox().isSelected());
        manager.getProperties().setOptionsViewScanArcs(getVisibleScanArcsCheckBox().isSelected());
        manager.getProperties().setOptionsBattleDesiredFps(Integer.parseInt(getDesiredFpsTextField().getText()));
        manager.getProperties()
                .setOptionsBattleAllowColorChanges(getOptionsBattleAllowColorChangesCheckBox().isSelected());
        manager.saveProperties();
    }

    public boolean isReady() {
        try {
            int fps = Integer.parseInt(getDesiredFpsTextField().getText());
            if (fps < MINFPS) {
                return false;
            } else if (fps > MAXFPS) {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    class EventHandler implements java.awt.event.ActionListener, DocumentListener {
        public void actionPerformed(java.awt.event.ActionEvent e) {
            if (e.getSource() == PreferencesViewOptionsTab.this.getDefaultsButton()) {
                defaultsButtonActionPerformed();
            }
            if (e.getSource() == PreferencesViewOptionsTab.this.getDefaultFpsButton()) {
                defaultFpsButtonActionPerformed();
            }
            if (e.getSource() == PreferencesViewOptionsTab.this.getMinFpsButton()) {
                minFpsButtonActionPerformed();
            }
            if (e.getSource() == PreferencesViewOptionsTab.this.getFastFpsButton()) {
                fastFpsButtonActionPerformed();
            }
            if (e.getSource() == PreferencesViewOptionsTab.this.getMaxFpsButton()) {
                maxFpsButtonActionPerformed();
            }
        }

        public void changedUpdate(DocumentEvent e) {
            PreferencesViewOptionsTab.this.desiredFpsTextFieldStateChanged();
        }

        public void insertUpdate(DocumentEvent e) {
            PreferencesViewOptionsTab.this.desiredFpsTextFieldStateChanged();
        }

        public void removeUpdate(DocumentEvent e) {
            PreferencesViewOptionsTab.this.desiredFpsTextFieldStateChanged();
        }
    }
}

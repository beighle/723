package robocode.dialog;

import javax.swing.*;

public class MapEditor extends JDialog {


    public void finishButtonActionPerformed() {
//		try {
//		int rc = createTeam();
//		if (rc == 0)
//		{
//		JOptionPane.showMessageDialog(this,"Team created successfully.","Success",JOptionPane.INFORMATION_MESSAGE,null);
//		this.dispose();
//		}
//		else
//		JOptionPane.showMessageDialog(this,"Team creation cancelled","Cancelled",JOptionPane.INFORMATION_MESSAGE,null);
//		} catch (Exception e) {
//		JOptionPane.showMessageDialog(this,e.toString(),"Team Creation Failed",JOptionPane.ERROR_MESSAGE,null);
//		}
    }

    public void cancelButtonActionPerformed() {

    }

}
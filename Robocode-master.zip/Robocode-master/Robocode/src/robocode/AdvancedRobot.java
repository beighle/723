/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *     Brian Woolley - implemented a motor control variation of the AdvancedRobot
 *     					for use by AFIT/ENG - CSCE623 and CSCE723
 *******************************************************************************/
package robocode;


/**
 * A more advanced type of robot that allows non-blocking calls, custom events,
 * and writes to the filesystem.  This version of Advanced Robot implements a
 * velocity/turnRate control schema instead of a distance/heading control schema.
 * <p>
 * This change requires the AFIT versions of Robot.class and RobotPeer.class.
 */
public abstract class AdvancedRobot extends Robot implements Runnable {

    /**
     * Executes any pending actions, or continues executing actions that are in process.
     * This returns after the actions have been started.
     * Advanced robots will probably call this function repeatedly...
     *
     * <P>In this example the robot will move while turning
     * <PRE>
     * setTurnRight(90);
     * setAhead(100);
     * execute();
     * while (getDistanceRemaining() != 0 && getTurnRemaining() != 0) {
     * execute();
     * }
     * </PRE>
     */
    public void execute() {
        if (peer != null) {
            //	peer.update(); // Also being called in Battle.java line 664
            peer.tick();
        } else {
            uninitializedException("execute");
        }
    }

    /**
     * Sets the robots velocity, in distance/tick
     * <BR> Positive values indicate forward motion
     * <BR> Negative values indicate backward motion
     * <BR> A zero value indicates that the robot is not moving
     * This call returns immediately, and will not execute until you call execute()
     * or take an action that executes.
     */
    public void setVelocity(double velocity) {
        if (peer != null) {
            peer.setCall();
            peer.setVelocity(velocity);
        } else {
            uninitializedException("setVelocity");
        }
    }

    /**
     * Sets the turn rate of the robot, in degrees/tick
     * <BR> Positive values indicate clockwise motion
     * <BR> Negative values indicate counter-clockwise motion
     * <BR> A zero value indicates that the robot is not rotating
     * This call returns immediately, and will not execute until you call execute()
     * or take an action that executes.
     */
    public void setTurnRate(double newTurnRate) {
        if (peer != null) {
            peer.setCall();
            peer.setRobotTurnRate(Math.toRadians(newTurnRate));
        } else {
            uninitializedException("setTurnRate");
        }
    }

    /**
     * Sets the rotation rate of the gun, in degrees/tick
     * <BR> Positive values indicate clockwise motion
     * <BR> Negative values indicate counter-clockwise motion
     * <BR> A zero value indicates that the robot is not rotating
     * This call returns immediately, and will not execute until you call execute()
     * or take an action that executes.
     */
    public void setGunRotation(double newTurnRate) {
        if (peer != null) {
            peer.setCall();
            peer.setGunTurnRate(Math.toRadians(newTurnRate));
        } else {
            uninitializedException("setGunRotation");
        }
    }

    /**
     * Sets the rotation rate of the radar, in degrees/tick
     * <BR> Positive values indicate clockwise motion
     * <BR> Negative values indicate counter-clockwise motion
     * <BR> A zero value indicates that the robot is not rotating
     * This call returns immediately, and will not execute until you call execute()
     * or take an action that executes.
     */
    public void setRadarRotation(double newTurnRate) {
        if (peer != null) {
            peer.setCall();
            peer.setRadarTurnRate(Math.toRadians(newTurnRate));
        } else {
            uninitializedException("setRadarTurnLeft");
        }
    }

    /**
     * Fires a bullet.  This call is exactly like setFire(double),
     * but returns the Bullet object you fired.
     * This call returns immediately, and will not execute until you call execute() or take an action that executes.
     *
     * @see Robot#fire
     */
    public Bullet fire(double power) {
        if (peer != null) {
            peer.setCall();
            return peer.setFire(power);
        } else {
            uninitializedException("fire");
            return null;
        }
    }

    /**
     * Causes the robot to stop moving and turning.  It also stops the gun and
     * the radar from turning.
     * This call returns immediately, and will not execute until you call execute() or take an action that executes.
     */
    public void allStop() {
        if (peer != null) {
            peer.setCall();
            peer.allStop();
        } else {
            uninitializedException("allStop");
        }
    }

    public void scan() {
        if (peer != null) {
            peer.setCall();
            peer.scan();
        } else {
            uninitializedException("scan");
        }
    }

    /**
     * Returns a file representing a directory you can write to using RobocodeOutputStream.
     * The system will create the directory for you, you do not need to create it.
     *
     * @see #getDataFile
     */
    public java.io.File getDataDirectory() {
        if (peer != null) {
            peer.getCall();
            peer.setIORobot(true);
            return peer.getRobotFileSystemManager().getWritableDirectory();
        } else {
            uninitializedException("getDataDirectory");
            return null; // never called
        }

    }

    /**
     * Returns a file in your data directory that you can write to RobocodeOutputStream.
     * The system will create the directory for you, you do not need to create it.
     * See the sample robots for examples.
     *
     * @see #getDataDirectory
     */
    public java.io.File getDataFile(String filename) {
        if (peer != null) {
            peer.getCall();
            peer.setIORobot(true);
            return new java.io.File(peer.getRobotFileSystemManager().getWritableDirectory(), filename);
        } else {
            uninitializedException("getDataFile");
            return null; // never called
        }
    }

    /**
     * Returns the quota available in your data directory, in bytes.
     *
     * @see #getDataDirectory
     */
    public long getDataQuotaAvailable() {
        if (peer != null) {
            peer.getCall();
            return peer.getRobotFileSystemManager().getMaxQuota() - peer.getRobotFileSystemManager().getQuotaUsed();
        } else {
            uninitializedException("getDataQuotaAvailable");
            return 0; // never called
        }
    }

}
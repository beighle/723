/*******************************************************************************
 * Copyright (c) 2001 Mathew Nelson
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.robocode.net/license/CPLv1.0.html
 *
 * Contributors:
 *     Mathew Nelson - initial API and implementation
 *******************************************************************************/
package robocode.manager;

import robocode.repository.FileSpecification;
import robocode.repository.FileSpecificationDatabase;
import robocode.repository.FileSpecificationVector;
import robocode.repository.Repository;
import robocode.util.Constants;
import robocode.util.RobocodeFileFilter;
import robocode.util.Utils;

import java.io.File;
import java.util.Vector;

public class MapRepositoryManager {

    boolean alwaysYes = false;
    boolean alwaysNo = false;
    private FileSpecificationDatabase mapDatabase = null;

    private File mapsDirectory = null;
    private File mapCache = null;

    private Repository repository = null;
    private boolean cacheWarning = false;
    private RobocodeManager manager = null;
    private Vector updatedJarVector = new Vector();
    private boolean write = false;
    private boolean duplicatePrompt = false;
    private FileSpecificationVector mapList = null;


    public MapRepositoryManager(RobocodeManager manager) {
        this.manager = manager;
        String classpath = System.getProperty("java.class.path");
        // not even finished... but just in case.
//	if (classpath != null && classpath.toLowerCase().indexOf(getWriteMapPath().toLowerCase()) >= 0)
//		log("Robocode halted:  " + getWriteMapPath() + " may not be in your classpath!");
    }

    private void log(String s) {
        Utils.log(s);
    }

    private void log(String s, Throwable t) {
        Utils.log(s, t);
    }

    private void log(Throwable e) {
        Utils.log(e);
    }

    public ImageManager getImageManager() {
        return manager.getImageManager();
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/24/2001 12:31:19 PM)
     *
     * @return java.lang.String
     */
    public File getMapCache() {
        if (mapCache == null) {
            // Doesn't work with my cwd(), File does not resolve absolute path correctly
            // (as far as I can see from the Javadocs for this constructor)
            // ---> robotCache = System.getProperty("ROBOTCACHE");


            File oldMapCache = new File(Constants.cwd(), "mapcache");
            if (oldMapCache.exists()) {
                oldMapCache.renameTo(new File(Constants.cwd(), ".mapcache"));
            }

            mapCache = new File(Constants.cwd(), ".mapcache");
        }
        return mapCache;
    }

    public FileSpecificationVector getMapList(File dir) {

        try {
            mapList = new FileSpecificationVector();
            File rootDir = new File("");
            if (dir == null) {
                rootDir = Constants.cwd();
                dir = new File("maps");

            } else {
                rootDir = new File(dir.getParent());
                dir = new File(dir.getName());
            }
//		System.out.println("dir: "+dir);
//		System.out.println("rootDir: "+rootDir);
            mapList = getSpecificationsInDirectory(rootDir, dir);
        } catch (Throwable e) {
            log(e);
        }
        return mapList;
    }

    /**
     * Insert the method's description here.
     * Creation date: (12/29/2000 12:29:38 PM)
     *
     * @param rootDir java.io.File
     * @param dir     java.io.File
     * @param mapList java.util.Vector
     */
    private FileSpecificationVector getSpecificationsInDirectory(File rootDir, File dir) {
        //log("getting specs in directory " + rootDir + " - " + dir);
        FileSpecificationVector mList = new FileSpecificationVector();
        String[] fileTypes = {".maps"};

        File f = new File(rootDir + "/" + dir);
        File[] files = f.listFiles(new RobocodeFileFilter(fileTypes));
        if (files == null) {
            log("Warning:  Unable to read directory " + dir);
            return mList;
        }
        for (int i = 0; i < files.length; i++) {
            if (files[i].isDirectory()) {
                int jidx = files[i].getName().lastIndexOf(".maps");
                if (jidx > 0 && jidx == files[i].getName().length() - 5) {
                    mList.add(getSpecificationsInDirectory(files[i], files[i]));
                }
            } else {
                FileSpecification
                        fileSpecification =
                        FileSpecification.createSpecification(this, files[i], rootDir, "", false);
                if (fileSpecification.getValid()) {
                    mList.add(fileSpecification);
                }
            }
        }
        return mList;
    }

    /**
     * Insert the method's description here.
     * Creation date: (9/24/2001 12:31:19 PM)
     *
     * @return java.lang.String
     */
    public File getMapsDirectory() {
        if (mapsDirectory == null) {
            mapsDirectory = new File(Constants.cwd(), "maps");

        }
        return mapsDirectory;
    }

    /**
     * Insert the method's description here.
     * Creation date: (8/27/2001 6:16:36 PM)
     *
     * @return java.util.Vector
     */
    public void clearMapList() {
        repository = null;
    }

    /**
     * Insert the method's description here.
     * Creation date: (10/1/2001 5:39:08 PM)
     */
//public boolean cleanupOldSampleMaps() {
//	return cleanupOldSampleMaps(true);
//}
    public boolean cleanupOldSampleMaps(boolean delete) {
        String[] oldSampleList = {"default.maps"};

        File f = getMapsDirectory();
        if (f.isDirectory()) // it better be!
        {
            File[] sampleBots = f.listFiles();
            for (int i = 0; i < sampleBots.length; i++) {
                if (!sampleBots[i].isDirectory()) {
                    for (int j = 0; j < oldSampleList.length; j++) {
                        if (sampleBots[i].getName().equals(oldSampleList[j])) {
                            log("Deleting old sample file: " + sampleBots[i].getName());
                            if (delete) {
                                sampleBots[i].delete();
                            } else {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Gets the manager.
     *
     * @return Returns a RobocodeManager
     */
    public RobocodeManager getManager() {
        return manager;
    }

}


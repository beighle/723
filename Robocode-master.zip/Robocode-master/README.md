# Robo5000

The easiest way to compile this is to bring up the Intellij project file in the idea directory
Robo5000 needs everything in the beighle source folder that can be found within the BehaviorFramework model of the project
Robo5000 also needs jbehavior.XML file in the root directory as a runtime config 
Please reach out with questions
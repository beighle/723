package evolutionEngine;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.StringTokenizer;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import behaviorFramework.Behavior;



import common.BehaviorFactory;
import common.Util;

public class GeneticProgram {
	private Random rand = new Random();
	private BehaviorFactory factory = BehaviorFactory.getInstance();
	
	@SuppressWarnings("unchecked")
	public void turnEpoch() throws IOException {
		Map<String, Integer> memberScore = new HashMap<String, Integer>();
		Map<String, Double> probabilityOfSelection = new HashMap<String, Double>();
		Map<String, Evolveable> populationCurrent = new HashMap<String, Evolveable>();
		ArrayList<Evolveable> populationNext = new ArrayList<Evolveable>();

		// Read in the results from the fitness evaluation of population(t)		
		BufferedReader in = new BufferedReader(
							new InputStreamReader(
							new FileInputStream(
							new File(Util.resultsFile))));
		int totalScore = 0;
		String line;
		// Load a Map of all <memberName, score> pairs
		line = in.readLine();		// Throw away the first line...
		line = in.readLine();		// Throw away the second line...		
		line = in.readLine();		// This is the 1st place member
		while (line != null)
		{				
			StringTokenizer parser = new StringTokenizer(line, "\t\r\n", true);
			String member = null;
			int score = 0;
			
			String token = parser.nextToken();
			member = token.substring(token.lastIndexOf(".")+1);
			
			parser.nextToken();
			score = Integer.parseInt(parser.nextToken());
			memberScore.put(member, score);
			
			totalScore += score;
			
			line = in.readLine();
		}
		in.close();

		// Construct the Behaviors for each member
		for (String member : memberScore.keySet())
			populationCurrent.put(member, factory.getBehaviorFromXML(member));

		// Generate the member selection probabilities
		for (String member : memberScore.keySet())
			probabilityOfSelection.put(member, (double)memberScore.get(member)/totalScore);

		// Copy the 1st place member from population(t) into population(t+1) as is
		int highScore = -1;
		String bestBoy = null;
		for (String member : memberScore.keySet())
		{
			if (memberScore.get(member) > highScore) 
				bestBoy = member;
		}
		if (bestBoy == null) throw new IllegalStateException("No 1st place member was found.");
		
		System.out.println(bestBoy + " was selected as the best boy (" + probabilityOfSelection.get(bestBoy) + ").");
		populationNext.add(factory.cloneEvolveable(populationCurrent.get(bestBoy)));
		
		// Select eight(8) members to contribute towards the next
		// generation of members, (repetition is allowed)
		ArrayList<Evolveable> donorList = new ArrayList<Evolveable>();
		double selector = (rand.nextDouble()) * 0.125;
		double floor = 0.0;
		
		System.out.print("Donor list: ");
		for (String member : memberScore.keySet())
		{
			floor += probabilityOfSelection.get(member);
			while (selector < floor)
			{
				System.out.print(member + ", ");
				donorList.add(factory.cloneEvolveable(populationCurrent.get(member)));
				selector += (0.125);
			}
		}
		System.out.println();
		if (donorList.size() != 8)
			throw new IllegalStateException(donorList.size() + " members were selected to be donors.");
		
		// Select one (1) member to move from population(t) into
		// population(t+1) after a major mutation
		String mutant = selectMember(probabilityOfSelection);
		Evolveable mutation = factory.cloneEvolveable(populationCurrent.get(mutant));
		mutation.majorMutation();
		populationNext.add(mutation);
		
		System.out.print("Beginning Crossover...");
		for (int i=0; i<4; i++)
		{
			Evolveable e1 = donorList.remove(rand.nextInt(donorList.size()));
			Evolveable e1sub = e1.placeCrossoverMarker();
			
			Evolveable e2 = donorList.remove(rand.nextInt(donorList.size()));
			Evolveable e2sub = e2.placeCrossoverMarker();

			if ( !e1.placeAtMarker(e2sub))
				throw new IllegalStateException("No crossover marker was found...operation failed.");
			if ( !e2.placeAtMarker(e1sub))
				throw new IllegalStateException("No crossover marker was found...operation failed.");

			e1.minorMutation();
			e2.minorMutation();
			
			populationNext.add(e1);
			populationNext.add(e2);
		}
		
		// Limit MaxDepth to 7
		for (Evolveable e : populationNext)
		{
			e.prune(7);
			assert (e.depth() < 8);
		}
		
		System.out.println("Crossover Complete.");
		
		System.out.println("Turn Epoch... population(t) <= population(t+1)");

		Element populationElement = new Element(Util.POPULATION_TAG);
		populationElement.setAttribute(Util.VERSION_TAG, Util.SAVEFILE_VERSION);

		// Create a bestBoy XML representation
		Element bestBoyElement = new Element(Util.MEMBER_TAG);
		bestBoyElement.setAttribute(Util.NAME_TAG, "bestBoy");
		bestBoyElement.addContent(populationCurrent.get(bestBoy).genXML());		
		populationElement.addContent(bestBoyElement);

		populationCurrent.clear();
		for (String member : memberScore.keySet())
		{
			populationCurrent.put(member, populationNext.remove(rand.nextInt(populationNext.size())));
		}
		
		// Add XML for member behaviors
		for (String member : populationCurrent.keySet()) 
		{
			Element memberElement = new Element(Util.MEMBER_TAG);
			memberElement.setAttribute(Util.NAME_TAG, member);
			memberElement.addContent(populationCurrent.get(member).genXML());

			populationElement.addContent(memberElement);
		}		
				
		Document populationInformation = new Document(populationElement);
		
		try {
			OutputStream save = new BufferedOutputStream(new FileOutputStream(Util.behaviorFile));
			// XML outPutter with two-space indentation and newlines after elements
			XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
			// actually output the XML tree to the save file
			outputter.output(populationInformation, save);
			save.close();
		} catch (IOException e) {
			// something went wrong
			throw new IllegalStateException("Unable to write population file", e);
		}		
	}

	
	public void testAgainstBenchmark() throws IOException {
		Map<String, Integer> memberScore = new HashMap<String, Integer>();
		// Read in the results from the benchmark results		
		BufferedReader in = new BufferedReader(
							new InputStreamReader(
							new FileInputStream(
							new File(Util.benchmarkResultsFile))));
		String line;
		// Load a Map of all <memberName, score> pairs
		line = in.readLine();		// Throw away the first line...
		line = in.readLine();		// Throw away the second line...		
		line = in.readLine();		// This is the 1st place member

		String member = null;
		int score = 0;
		while (line != null)
		{				
			StringTokenizer parser = new StringTokenizer(line, "\t\r\n", true);
			
			String token = parser.nextToken();
			member = token.substring(token.lastIndexOf(".")+1);
			
			parser.nextToken();
			score = Integer.parseInt(parser.nextToken());
			System.out.println(member + " " + score);
			memberScore.put(member, score);
			line = in.readLine();
		}

		in.close();
		PrintWriter out = new PrintWriter(
				new FileOutputStream(
						new File(Util.historyFile), true));
		out.append("Osprey:\t"  + memberScore.get("myRobot")  + 
				 "\tBestBoy:\t" + memberScore.get("BestBoy") + "\n");
		out.close();							// Close the print stream
	}
	
	public void testInterPopulation() throws IOException {
		Map<String, Integer> memberScore = new HashMap<String, Integer>();
		// Read in the results from the inter-population results		
		BufferedReader in = new BufferedReader(
							new InputStreamReader(
							new FileInputStream(
							new File(Util.benchmarkResultsFile))));
		String line;
		// Load a Map of all <memberName, score> pairs
		line = in.readLine();		// Throw away the first line...
		line = in.readLine();		// Throw away the second line...		
		line = in.readLine();		// This is the 1st place member

		String member = null;
		int score = 0;
		while (line != null)
		{				
			StringTokenizer parser = new StringTokenizer(line, "\t\r\n", true);
			
			String token = parser.nextToken();
			member = token.substring(token.lastIndexOf(".")+1);
			
			parser.nextToken();
			score = Integer.parseInt(parser.nextToken());
			System.out.println(member + " " + score);
			memberScore.put(member, score);
			line = in.readLine();
		}

		in.close();
		PrintWriter out = new PrintWriter(
				new FileOutputStream(
						new File(Util.historyFile), true));
		out.append("Alpha:\t"	+ memberScore.get("Alpha")	+ 
				 "\tBravo:\t"	+ memberScore.get("Bravo")	+
				 "\tCharlie:\t"	+ memberScore.get("Charlie")+
				 "\tDelta:\t"	+ memberScore.get("Delta")	+
				 "\tEcho:\t"	+ memberScore.get("Echo")	+
				 "\tFoxtrot:\t"	+ memberScore.get("Foxtrot")+
				 "\tGolf:\t"	+ memberScore.get("Golf")	+
				 "\tHotel:\t"	+ memberScore.get("Hotel")	+ "\n");
		out.close();							// Close the print stream
	}

	public void genRandPopulation(File file) {		
		Map<String, Behavior> memberBehaviorMap = new HashMap<String, Behavior>();
		memberBehaviorMap.put("alpha", factory.genRandomBehavior());
		memberBehaviorMap.put("bravo", factory.genRandomBehavior());
		memberBehaviorMap.put("charlie", factory.genRandomBehavior());
		memberBehaviorMap.put("delta", factory.genRandomBehavior());
		memberBehaviorMap.put("echo", factory.genRandomBehavior());
		memberBehaviorMap.put("foxtrot", factory.genRandomBehavior());
		memberBehaviorMap.put("golf", factory.genRandomBehavior());
		memberBehaviorMap.put("hotel", factory.genRandomBehavior());
		memberBehaviorMap.put("indigo", factory.genRandomBehavior());
		memberBehaviorMap.put("juliet", factory.genRandomBehavior());

		Element populationElement = new Element(Util.POPULATION_TAG);
		populationElement.setAttribute(Util.VERSION_TAG, Util.SAVEFILE_VERSION);

		/*
		 * Add XML for members
		 */
		for (String member : memberBehaviorMap.keySet())
		{
			Element memberElement = new Element(Util.MEMBER_TAG);
			memberElement.setAttribute(Util.NAME_TAG, member);
			memberElement.addContent(memberBehaviorMap.get(member).genXML());

			populationElement.addContent(memberElement);
		}		
				
		Document populationInformation = new Document(populationElement);
		
		try {
			OutputStream save = new BufferedOutputStream(new FileOutputStream(file));
			// XML outPutter with two-space indentation and newlines after elements
			XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
			// actually output the XML tree to the save file
			outputter.output(populationInformation, save);
			save.close();
		} catch (IOException e) {
			// something went wrong
			throw new IllegalStateException("Unable to write population file", e);
		}	
	}

	private String selectMember(Map<String, Double> probabilityMap) {
		String retVal = null;

		double ratio = 0.0;
		for (Double d : probabilityMap.values())
			ratio += d;
		
		double selector = (rand.nextDouble() * ratio);
		for (String s : probabilityMap.keySet())
		{
			if (selector < probabilityMap.get(s))
			{
				retVal = s;
				break;
			}
			selector -= probabilityMap.get(s);
		}
		assert (retVal != null);
		return retVal;
	}
}

package evolutionEngine;

import java.io.File;
import java.io.IOException;

import common.Util;

public class EvolutionEngine {
	
	/**
	 * Generates an initial population of 10 random behavior structures
	 * using the elemental behaviors and arbitration units available.
	 * The population file is directed to: "D:\robocode\behavior.XML"
	 * 
	 * @param args: [-newPopulation], [-turnEpoch], [-measureAbsFitness]
	 */
	public static void main(String[] args) {
		GeneticProgram gp = new GeneticProgram();
		
		try {
			if (args[0].equalsIgnoreCase("-newPopulation"))
			{
				gp.genRandPopulation(new File(Util.behaviorFile));
				System.out.println("A random member population was generated at: "
									+ Util.behaviorFile);	
			}
			else if (args[0].equalsIgnoreCase("-turnEpoch"))
			{
				gp.turnEpoch();
				System.out.println("An evolutionary cycle has completed...");
			}
			else if (args[0].equalsIgnoreCase("-measureAbsFitness"))
			{
				gp.testAgainstBenchmark();
				System.out.println("The bestBoy has been benchmarked against Osprey...");
			}
			else if (args[0].equalsIgnoreCase("-interPopulationFitness"))
			{
				gp.testInterPopulation();
				System.out.println("The inter-populations results have been captured...");
			}		
			else
			{
				System.out.println("Unknown Usage: " + args[0]);
				System.out.println("evolutionEngine [-newPopulation], [-turnEpoch], [-measureAbsFitness]");
			}
		}
		catch (IOException e) {
			e.printStackTrace();
			return;
		}
	}
}

package evolutionEngine;

import behaviorFramework.Behavior;

public interface Evolveable extends Representable {
	public abstract int depth();
	public abstract void prune(int maxDepth);
	public abstract int nodeCount();
	public abstract Behavior placeCrossoverMarker();
	public abstract boolean placeAtMarker(Evolveable newSubTree);
	public abstract void minorMutation();
	public abstract void majorMutation();
}

package common;

public class Util {
	public static final String behaviorFile = "./behavior.XML";
	public static final String resultsFile = "./results/meleeResults.txt";
	public static final String benchmarkResultsFile = "./results/benchmarkResults.txt";
	public static final String historyFile = "./results/resultsHistory.txt";
	
	public static final int memberCount = 10;

	public static final String ARBITER_TAG = "arbiter";
	public static final String COMPOSITE_TAG = "composite";
	public static final String MEMBER_TAG = "member";
	public static final String NAME_TAG = "name";	
	public static final String NODE_TAG = "node";
	public static final String POPULATION_TAG = "behaviorPopulation";
	public static final String SAVEFILE_VERSION = "1.0";
	public static final String VERSION_TAG = "version";
	public static final String WEIGHT_1_TAG = "w1";
	public static final String WEIGHT_2_TAG = "w2";
	public static final String WEIGHT_3_TAG = "w3";
	public static final String WEIGHT_4_TAG = "w4";
}

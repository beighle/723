package common;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import behaviorFramework.ArbitrationUnit;
import behaviorFramework.Behavior;
import behaviorFramework.CompositeBehavior;
import behaviorFramework.Leaf;
import behaviorFramework.arbiters.ActivationFusion;
import behaviorFramework.arbiters.CommandFusion;
import behaviorFramework.arbiters.HighestActivation;
import behaviorFramework.arbiters.HighestPriority;
import behaviorFramework.arbiters.MonteCarlo;
import behaviorFramework.arbiters.NullArbiter;
import behaviorFramework.behaviors.Charge;
import behaviorFramework.behaviors.Dodge;
import behaviorFramework.behaviors.Fire_v1;
import behaviorFramework.behaviors.Fire_v2;
import behaviorFramework.behaviors.ReturnFire;
import behaviorFramework.behaviors.ScanLeft;
import behaviorFramework.behaviors.ScanRight;
import behaviorFramework.behaviors.ShortRngFire;
import behaviorFramework.behaviors.SittingDuck;
import behaviorFramework.behaviors.SniperFire;
import behaviorFramework.behaviors.Wander_v1;
import behaviorFramework.behaviors.Wander_v2;
import behaviorFramework.behaviors.Wander_v3;
import evolutionEngine.Evolveable;



/**
 * This factory is the main access point for robots using the behaviorFramwork
 * package.  The BehaviorFactory accepts a robot's name or identifier and then
 * retrieves and builds a behavior tree from either the persistent behavior.XML
 * file or from a direct specification. 
 *  
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class BehaviorFactory {
	
	// Singleton Object Construction
	private static BehaviorFactory uniqueInstance = new BehaviorFactory();
	private BehaviorFactory() {}
	
	public static BehaviorFactory getInstance () {
		return uniqueInstance;
	}
	
	private Random rand = new Random();

	/**
	 * 
	 * @param id
	 * @return
	 */
	public Behavior getBehaviorFromXML(String id) {
		assert (id != null);
		
		// ID will is used to retrieve and build an behavior
		// hierarchy from the persistent behavior.XML file		
		SAXBuilder builder = new SAXBuilder();
		try
		{
			Document behaviorXML = builder.build(new File(Util.behaviorFile));
			Element root = behaviorXML.getRootElement();
			Element member = findMember(root, id);
			if (member != null)
				return buildBehavior(member.getChild(Util.NODE_TAG));
			else
				return new SittingDuck();			
		}
		catch (Throwable e) {
			e.printStackTrace();
		}
		return new SittingDuck();
	}
	
	/**
	 * 
	 * @param name
	 * @return
	 */
	public Behavior getMyBehavior(String name) {

		if (name.equalsIgnoreCase("myRobot")) {
			CompositeBehavior cb = new CompositeBehavior();
			cb.setArbitrationUnit(new ActivationFusion());
			cb.add(new Wander_v3());
			cb.add(new Dodge());
			cb.add(new Charge());
			cb.add(new Fire_v1());
			return cb;		
		} else if (name.equalsIgnoreCase("TrackFire")) {
			return new Fire_v1();
		} else if (name.equalsIgnoreCase("Wander")) {
			return new Wander_v3();
		} else
			return new SittingDuck();
	}
	
	/**
	 * 
	 * @return
	 */
	public Behavior genRandomBehavior() {
		return genRandomCompositeBehavior();
	}

	public Evolveable cloneEvolveable(Evolveable item) {
		assert (item != null);
		
		if (item instanceof Behavior)
			return cloneBehavior((Behavior)item);
		else
			throw new IllegalStateException("Attempting to clone an object of type: " + item.getClass());
	}
	
	private Behavior cloneBehavior(Behavior behavior) {
		assert (behavior != null);
		
		if (behavior instanceof CompositeBehavior)
			return cloneCompositeBehavior((CompositeBehavior) behavior);
		else if (behavior instanceof Leaf)
			return cloneLeafBehavior((Leaf) behavior);
		else throw new IllegalStateException();
	}

	private Behavior genRandomCompositeBehavior() {
		CompositeBehavior cb = new CompositeBehavior();

		cb.setArbitrationUnit(genRandomArbiter());
		for (int i=0; i<4; i++)		// the branching factor
			if (rand.nextDouble() > 0.80)
				cb.add(genRandomCompositeBehavior());
			else
				cb.add(genRandomLeaf());				
		return cb;
	}

	public ArbitrationUnit genRandomArbiter() {
		ArrayList<Double> w = new ArrayList<Double>();
		for (int i=0; i<4; i++)
			w.add(rand.nextDouble());
		
		ArbitrationUnit au = null;
		
		double selector = rand.nextDouble();
		if (selector > 0.8)
			au = new CommandFusion(w);
		else if (selector > 0.6)
			au = new MonteCarlo(w);
		else if (selector > 0.4)
			au = new HighestPriority(w);
		else if (selector > 0.2)
			au = new HighestActivation(w);
		else if (selector > 0.00)
			au = new ActivationFusion(w);
			
		assert (au != null);
		return au;
	}

	public Leaf genRandomLeaf() {
		Leaf leaf = null;
		
		double selector = rand.nextDouble();
		if (selector > 0.9228)		leaf = new Fire_v2();
		else if (selector > 0.8459)	leaf = new ReturnFire();
		else if (selector > 0.7690)	leaf = new ShortRngFire();
		else if (selector > 0.6921)	leaf = new ScanLeft();
		else if (selector > 0.6152)	leaf = new ScanRight();
		else if (selector > 0.5383)	leaf = new SittingDuck();
		else if (selector > 0.4614)	leaf = new SniperFire();
		else if (selector > 0.3845)	leaf = new Wander_v1();
		else if (selector > 0.3076) leaf = new Wander_v2();
		else if (selector > 0.2307) leaf = new Wander_v3();
		else if (selector > 0.1538) leaf = new Dodge();
		else if (selector > 0.0769) leaf = new Charge();
		else if (selector > 0.00)	leaf = new Fire_v1();

		assert (leaf != null);
		return leaf;
	}
	
	@SuppressWarnings("unchecked")
	private Element findMember(Element root, String id) {
		List<Element> memberList = root.getChildren(Util.MEMBER_TAG);
		Boolean memberFound = false;
		for (Element memberElement : memberList)
		{
			String name = memberElement.getAttributeValue(Util.NAME_TAG);
			assert (name != null);
			if (name.equalsIgnoreCase(id))
				return memberElement;
		}
		// notify the user: "The robot name was not found in behavior.XML."
		if (!memberFound)
			System.err.println("The robot identifier: " + id + " was not found in " + Util.behaviorFile);
		return null;
	}
	
	@SuppressWarnings("unchecked")
	private Behavior buildBehavior(Element currentNode) {
		// This is a composite behavior node.
		if ("Y".equalsIgnoreCase(currentNode.getAttributeValue(Util.COMPOSITE_TAG)))
		{
			CompositeBehavior compositeBehaviorNode = new CompositeBehavior();
			// Setup and add the ArbitrationUnit.
			Element arbiterElement = currentNode.getChild(Util.ARBITER_TAG);
			compositeBehaviorNode.setArbitrationUnit(buildArbiter(arbiterElement));
			
			// Recursively obtain and add the composing behaviors.
			List<Element> nodeList = currentNode.getChildren(Util.NODE_TAG);
			for (Element subNode : nodeList)
			{
				compositeBehaviorNode.add(buildBehavior(subNode));
			}
			// This behavior is complete.
			return compositeBehaviorNode;
		}
		// This is a leaf behavior node, as well as the recursive termination.
		else
		{
			String behaviorName = currentNode.getText();
			if 		("Charge".equalsIgnoreCase(behaviorName)) 	return new Charge();
			else if ("Dodge".equalsIgnoreCase(behaviorName))		return new Dodge();
			else if ("Fire_v1".equalsIgnoreCase(behaviorName))		return new Fire_v1();
			else if ("Fire_v2".equalsIgnoreCase(behaviorName))		return new Fire_v2();
			else if ("ReturnFire".equalsIgnoreCase(behaviorName))	return new ReturnFire();
			else if ("ShortRngFire".equalsIgnoreCase(behaviorName))	return new ShortRngFire();
			else if ("ScanLeft".equalsIgnoreCase(behaviorName))		return new ScanLeft();
			else if ("ScanRight".equalsIgnoreCase(behaviorName))	return new ScanRight();
			else if ("SittingDuck".equalsIgnoreCase(behaviorName))	return new SittingDuck();
			else if ("SniperFire".equalsIgnoreCase(behaviorName))	return new SniperFire();
			else if ("Wander_v1".equalsIgnoreCase(behaviorName)) 	return new Wander_v1();
			else if ("Wander_v2".equalsIgnoreCase(behaviorName)) 	return new Wander_v2();
			else if ("Wander_v3".equalsIgnoreCase(behaviorName)) 	return new Wander_v3();
			else
			{
				System.err.println("The behavior identifier: " + behaviorName +
								   " is not a known behavior type.");				
				return new SittingDuck();
			}
		}
	}
	
	private ArbitrationUnit buildArbiter(Element arbiterElement) {
		String arbiterName = arbiterElement.getText();
		ArrayList<Double> w = new ArrayList<Double>();
		ArbitrationUnit arbiter = null;
		
		if ("CommandFusion".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_4_TAG)));
			arbiter = new CommandFusion(w);
		} else
		if ("MonteCarlo".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_4_TAG)));
			arbiter = new MonteCarlo(w);
		} else
		if ("NullArbiter".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_4_TAG)));
			arbiter = new NullArbiter(w);
		} else
		if ("HighestPriority".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_4_TAG)));
			arbiter = new HighestPriority(w);
		} else
		if ("HighestActivation".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_4_TAG)));
			arbiter = new HighestActivation(w);
		} else
		if ("ActivationFusion".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(Util.WEIGHT_4_TAG)));
			arbiter = new ActivationFusion(w);
		} else {
			System.err.println("The arbiter identifier: " + arbiterName +
							   " is not a known arbitration type.");				
			arbiter = new HighestPriority();
		}
		return arbiter;
	}
	
	private Behavior cloneCompositeBehavior(CompositeBehavior node) {
		CompositeBehavior cb = new CompositeBehavior();

		cb.setArbitrationUnit(cloneArbiter(node.getArbiter()));
		for (Behavior b : node.getBehaviorSet())
			cb.add(cloneBehavior(b));
		
		return cb;
	}

	private ArbitrationUnit cloneArbiter(ArbitrationUnit arbiter) {		
		ArbitrationUnit au = null;


		if (arbiter instanceof CommandFusion)
			au = new CommandFusion();
		else if (arbiter instanceof MonteCarlo)
			au = new MonteCarlo();
		else if (arbiter instanceof NullArbiter)
			au = new NullArbiter();
		else if (arbiter instanceof HighestPriority)
			au = new HighestPriority();
		else if (arbiter instanceof HighestActivation)
			au = new HighestActivation();
		else if (arbiter instanceof ActivationFusion)
			au = new ActivationFusion();
		else throw new IllegalStateException("Attempting to clone an unknown type of Arbiter.");
		
		assert (au != null);
		ArrayList<Double> w = arbiter.getWeights();
		au.setWeights(w);
		return au;
	}

	private Behavior cloneLeafBehavior(Leaf leaf) {
		Leaf behavior = null;

		if (leaf instanceof Charge)
			behavior = new Charge();
		else if (leaf instanceof Dodge)
			behavior = new Dodge();
		else if (leaf instanceof Fire_v1)
			behavior = new Fire_v1();
		else if (leaf instanceof Fire_v2)
			behavior = new Fire_v2();
		else if (leaf instanceof ReturnFire)
			behavior = new ReturnFire();
		else if (leaf instanceof ShortRngFire)
			behavior = new ShortRngFire();
		else if (leaf instanceof ScanLeft)
			behavior = new ScanLeft();
		else if (leaf instanceof ScanRight)
			behavior = new ScanRight();
		else if (leaf instanceof SittingDuck)
			behavior = new SittingDuck();
		else if (leaf instanceof SniperFire)
			behavior = new SniperFire();
		else if (leaf instanceof Wander_v1)
			behavior = new Wander_v1();
		else if (leaf instanceof Wander_v2)
			behavior = new Wander_v2();
		else if (leaf instanceof Wander_v3)
			behavior = new Wander_v3();
		else throw new IllegalStateException("Attempting to clone an unknown type of Behavior.");

		assert (behavior != null);
		return behavior;
	}

}

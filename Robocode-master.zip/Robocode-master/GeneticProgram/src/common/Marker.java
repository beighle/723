package common;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.Behavior;
import behaviorFramework.Leaf;
import behaviorFramework.State;


import evolutionEngine.Evolveable;


public class Marker extends Leaf {

	// Singleton Object Construction
	private static Marker uniqueInstance = new Marker();
	private Marker() {}
	
	public static Marker getInstance () {
		return uniqueInstance;
	}

	@Override
	public Action genAction(State state) {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public int depth() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public void minorMutation() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public void majorMutation() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public Behavior placeCrossoverMarker() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public boolean placeAtMarker(Evolveable newSubTree) {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	public Element genXML() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be saved as XML.");
	}
}

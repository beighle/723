package behaviorFramework.arbiters;

import java.util.ArrayList;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.ArbitrationUnit;



import common.Util;

/**
 * This arbiter selects the action with the highest priority, (if it voted)
 * winner takes all.   --if (vote > 0) priority = weight
 *  
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class HighestPriority extends ArbitrationUnit {

	public HighestPriority (ArrayList<Double> weightList) {
		super();
		this.setWeights(weightList);
	}

	// Overloaded constructor that allows for default weight values
	public HighestPriority() {
		this(null);
	}

	public Action evaluate(ArrayList<Action> actionSet) {
		Action action = new Action();
		double maxPriority = 0.0;
		
		// Return the highest priority action with a non-zero vote
		//
		for(Action a : actionSet)
		{
			if (a.getVote() > 0.0)
			{
				double priority = w.get(actionSet.indexOf(a));
				if (priority > maxPriority)
				{
					action = a;
					maxPriority = priority;
				}
			}
		}
		// return a noOp if no action in the set votes
		return action;
	}

	public Element genXML() {
		Element arbiterElement = new Element(Util.ARBITER_TAG);
		arbiterElement.setAttribute(Util.WEIGHT_1_TAG, Double.toString(w.get(0)));
		arbiterElement.setAttribute(Util.WEIGHT_2_TAG, Double.toString(w.get(1)));
		arbiterElement.setAttribute(Util.WEIGHT_3_TAG, Double.toString(w.get(2)));
		arbiterElement.setAttribute(Util.WEIGHT_4_TAG, Double.toString(w.get(3)));		
		arbiterElement.setText("HighestPriority");
		return arbiterElement;
	}
}

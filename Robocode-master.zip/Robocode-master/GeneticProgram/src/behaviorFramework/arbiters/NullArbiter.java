package behaviorFramework.arbiters;

import java.util.ArrayList;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.ArbitrationUnit;



import common.Util;

/**
 * This arbiter always passes an empty action back, regardless of the
 * Action set that was passed in.  This has been introduced specifically
 * for use in the GP evolution of the UBF.
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class NullArbiter extends ArbitrationUnit {

	public NullArbiter (ArrayList<Double> weightList) {
		super();
		this.setWeights(weightList);
	}
	
	// Overloaded constructor that allows for default weight values
	public NullArbiter() {
		this(null);
	}

	public Action evaluate(ArrayList<Action> actionSet) {
		return new Action();
	}

	public Element genXML() {
		Element arbiterElement = new Element(Util.ARBITER_TAG);
		arbiterElement.setAttribute(Util.WEIGHT_1_TAG, Double.toString(w.get(0)));
		arbiterElement.setAttribute(Util.WEIGHT_2_TAG, Double.toString(w.get(1)));
		arbiterElement.setAttribute(Util.WEIGHT_3_TAG, Double.toString(w.get(2)));
		arbiterElement.setAttribute(Util.WEIGHT_4_TAG, Double.toString(w.get(3)));		
		arbiterElement.setText("NullArbiter");
		return arbiterElement;
	}
}

package behaviorFramework.arbiters;

import java.util.ArrayList;
import java.util.Random;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.ArbitrationUnit;


import common.Util;


/**
 * The MonteCarlo arbitration method randomly selects actions from a
 * weighted distribution of the action's vote times its weight.
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class MonteCarlo extends ArbitrationUnit {
	Random rand = new Random();
	int turnCounter = 0, index = 0;
	
	public MonteCarlo (ArrayList<Double> weightList) {
		super();
		this.setWeights(weightList);
	}

	// Overloaded constructor that allows for default weight values
	public MonteCarlo() {
		this(null);
	}

	public Action evaluate(ArrayList<Action> actionSet) {
		Action action = new Action();
		
		if (turnCounter > 0)
		{
			action = actionSet.get(index);
			turnCounter--;
		}
		else
		{
			double ratio = 0.0;
			for(Action a : actionSet)
				ratio += (a.getVote() * w.get(actionSet.indexOf(a)));

			// Random selection of an Action, weighted by Vote
			//
			double selector = (rand.nextDouble() * ratio); 	
			for(Action a : actionSet) {
				if (a.getVote() > selector) {
					action = a;
					break;
				}
				selector -= a.getVote();
			}
			turnCounter = 20;
		}
		return action;
	}
	public Element genXML() {
		Element arbiterElement = new Element(Util.ARBITER_TAG);
		arbiterElement.setAttribute(Util.WEIGHT_1_TAG, Double.toString(w.get(0)));
		arbiterElement.setAttribute(Util.WEIGHT_2_TAG, Double.toString(w.get(1)));
		arbiterElement.setAttribute(Util.WEIGHT_3_TAG, Double.toString(w.get(2)));
		arbiterElement.setAttribute(Util.WEIGHT_4_TAG, Double.toString(w.get(3)));		
		arbiterElement.setText("MonteCarlo");
		return arbiterElement;
	}
}

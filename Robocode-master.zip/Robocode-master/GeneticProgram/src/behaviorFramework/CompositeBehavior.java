package behaviorFramework;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.jdom.Element;

import behaviorFramework.arbiters.HighestPriority;



import common.BehaviorFactory;
import common.Marker;
import common.Util;

import evolutionEngine.Evolveable;
import evolutionEngine.Representable;


/**
 * This is a composite behavior, following the composite pattern.  It can
 * have either elemental behaviors or other composite behaviors as its
 * child elements. It must have an arbitration unit as a way of selecting
 * the Action that will be passed up the hierarchy.
 * 
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 *
 */
public class CompositeBehavior extends Behavior {
	private ArrayList<Behavior> behaviorSet = new ArrayList<Behavior>();
	private ArbitrationUnit arbiter = new HighestPriority();
	private BehaviorFactory factory = BehaviorFactory.getInstance();
	
	private	Random rand = new Random();
	
	public Action genAction(State state) {
		assert (state != null);
		
		ArrayList<Action> actionSet = new ArrayList<Action>();
		for (Behavior b : behaviorSet)
			actionSet.add(b.genAction(state));
		return arbiter.evaluate(actionSet);
	}
	
	public void add(Behavior newBehavior) {
		assert(newBehavior != null);
		behaviorSet.add(newBehavior);
	}
	
	public boolean remove(Behavior existingBehavior) {
		assert(existingBehavior != null);
		return behaviorSet.remove(existingBehavior);
	}
	
	public ArbitrationUnit getArbiter() {
		return arbiter;
	}

	public Collection<Behavior> getBehaviorSet() {
		return behaviorSet;
	}

	public void setArbitrationUnit(ArbitrationUnit au) {
		assert(au != null);
		arbiter = au;
	}
	
	/**
	 * Gives the value of deepest path from this point. 
	 * @return the depth of the structure up to this point.
	 */
	public int depth() {
		int myDepth = 0;
		for (Behavior b : behaviorSet)
		{
			myDepth = Math.max(myDepth, b.depth());
		}
		return myDepth + 1;
	}
	public void prune(int depth) {
		Set<Integer> pruneSet = new HashSet<Integer>();
		for (Evolveable e : behaviorSet)
		{
			if (e instanceof Leaf) {
				// Do nothing...
			} else {
				if (depth > 2)
					e.prune(depth-1);
				else
					pruneSet.add(behaviorSet.indexOf(e));
			}
		}
		for (Integer i : pruneSet) {
			if (behaviorSet.remove(behaviorSet.get(i))) {
				behaviorSet.add(i, factory.genRandomLeaf());
			}
			else throw new IllegalStateException("Couldn't prune tree...");
		}
	}
	public int nodeCount() {
		int myNodeCount = 0;
		for (Behavior b : behaviorSet)
		{
			myNodeCount += b.nodeCount();
		}
		return myNodeCount + 1;
	}

	public void minorMutation() {
		ArrayList<Double> oldWeights, newWeights;
		
		oldWeights = arbiter.getWeights();
		newWeights = new ArrayList<Double>();
		for (double d : oldWeights)
			newWeights.add(d * (0.9 + (rand.nextDouble()/5)));
		arbiter.setWeights(newWeights);
		
		// Propagate the minor mutation
		for (Evolveable e : behaviorSet)
			e.minorMutation();
	}

	public void majorMutation() {
		int myCount = nodeCount();
		double selector = rand.nextDouble();
		
		if (selector <= 1/myCount)
		{
			setArbitrationUnit(factory.genRandomArbiter());
			return;
		}
		selector -= 1/myCount;
		for (Evolveable e : behaviorSet)
		{
			if (selector < e.nodeCount()/myCount)
			{
				if (e instanceof CompositeBehavior)
					// Propagate the major mutation
					e.majorMutation();
				else
					e = factory.genRandomLeaf();
				return;
			}
			selector -= e.nodeCount()/myCount;			
		}
	}

	public Element genXML() {
		Element compositeElement = new Element(Util.NODE_TAG);
		compositeElement.setAttribute(Util.COMPOSITE_TAG, "Y");

		compositeElement.addContent(arbiter.genXML());
		for (Representable r : behaviorSet)
			compositeElement.addContent(r.genXML());			
		return compositeElement;
	}

	public Behavior placeCrossoverMarker() {
		int i = (int)(rand.nextDouble() * 4);
		Behavior b = behaviorSet.get(i);
		if (b instanceof Leaf)
		{
			behaviorSet.remove(i);
			behaviorSet.add(i, Marker.getInstance());
		}
		else if (b instanceof CompositeBehavior)
		{
			// This will be our cut point
			if (rand.nextBoolean())
			{
				behaviorSet.remove(i);
				behaviorSet.add(i, Marker.getInstance());				
			}
			// Allow the cut point to exist deeper
			// in the behavior hierarchy
			else
			{
				b = b.placeCrossoverMarker();
			}
		}
		else throw new IllegalStateException();	
		return b;
	}
	public boolean placeAtMarker(Evolveable newSubTree) {
		if (newSubTree instanceof Behavior)
		{
			for (Behavior b : behaviorSet)
			{
				int i = behaviorSet.indexOf(b);
				if (b == Marker.getInstance())
				{
					behaviorSet.remove(i);
					behaviorSet.add(i, (Behavior)newSubTree);
					return true;
				}
				if (b.placeAtMarker(newSubTree))
					return true;
			}
		}
		return false;
	}
}

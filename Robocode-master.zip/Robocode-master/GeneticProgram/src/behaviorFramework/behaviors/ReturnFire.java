package behaviorFramework.behaviors;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;



import common.Util;

/**
 * This Fire Behavior was developed hold a grudge.  The aggressor is considered
 * to be the first opponent to have shot our robot.  We will pursue them until
 * they have been killed.  Oh, don't worry, this behavior likes freebies too.
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class ReturnFire extends Leaf {
	String agressor = "none";
	
	public Action genAction(State state) {
		assert (state != null);

		Action action = new Action();
		
		// Check to see if we are free to pursue other targets
		if (state.getRobotHasDied()) agressor = "none";

		if ((state.isHitByRobot() || state.isHitByBullet()) &&
				agressor.equalsIgnoreCase("none"))
		{
			agressor = state.getHitByBulletEvent().getName(); // Did you get the name of that SOB?

			// Calculate the location of the shooter
			double absoluteBearing = state.getHeading() + state.getHitByBulletEvent().getBearing(); //getTargetBearing();
			double bearingFromGun = normalRelativeAngle(absoluteBearing - state.getGunHeading());

			if (bearingFromGun >  20) bearingFromGun =  20;
			if (bearingFromGun < -20) bearingFromGun = -20;
			action.setGunRotation(bearingFromGun);	// Make the system limit our MaxTurnRate
			action.setVote(25);
		}

		if ( !state.hasScannedTarget())
		{
			action.setGunRotation(5);
			action.setVote(10);
		}
		else {
			if (state.getScannedRobotEvents().firstElement().getDistance() < 500)
			{
				// Either we've spotted the SOB that shot us...
				// or there's no one on ourShitList and this is a target of opportunity.
				if (agressor.equalsIgnoreCase("none") || agressor.equalsIgnoreCase(state.getScannedRobotEvents().firstElement().getName()))
				{
					action.setGunRotation(0);

					// Calculate the location of the robot
					double absoluteBearing = state.getHeading() + state.getScannedRobotEvents().firstElement().getBearing();
					double bearingFromGun = normalRelativeAngle(absoluteBearing - state.getGunHeading());

					if (Math.abs(bearingFromGun) <= 1.0)
						action.setFireGun(Math.min(3, state.getEnergy() - .1));
					else
						action.setGunRotation(bearingFromGun/3);

					action.scan();
					action.setVote(70);
				}
			}
		}
		return action;
	}

	// Helper Method
	private double normalRelativeAngle(double angle) {
		if (angle > -180 && angle <= 180) return angle;
		double fixedAngle = angle;
		while (fixedAngle <= -180) fixedAngle += 360;
		while (fixedAngle > 180)   fixedAngle -= 360;
		return fixedAngle;
	}

	public Element genXML() {
		return new Element(Util.NODE_TAG).setText("ReturnFire");		
	}
}
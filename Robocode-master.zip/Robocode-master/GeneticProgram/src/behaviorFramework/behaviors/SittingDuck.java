package behaviorFramework.behaviors;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;



import common.Util;


/**
 * This is a sitting duck behavior.  It will always vote to stop the
 * motion of the robot as well as its turret and radar.
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class SittingDuck extends Leaf {
	public Action genAction(State state) {
        assert (state != null);

        Action action = new Action();

        // This is a sitting duck behavior...what did you expect!
        action.setVelocity(0.0);
        action.setTurnRate(0.0);
        action.setGunRotation(0.0);
        action.setRadarRotation(0.0);
        
        // Make sure to vote if you want a chance to be picked.
		action.setVote(1);
		
		return action;
	}

	public Element genXML() {
		return new Element(Util.NODE_TAG).setText("SittingDuck");		
	}
}
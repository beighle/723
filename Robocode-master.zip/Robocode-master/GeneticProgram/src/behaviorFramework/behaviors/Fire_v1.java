package behaviorFramework.behaviors;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;



import common.Util;

/**
 * This Fire Behavior was adapted from Mathew Nelson's TrackFire robot.
 * It expects the Radar and Gun to be aligned.  The default action is to
 *   rotate the turret 5 degrees/tick.  If a target has been detected
 *   the turret rotation will stop or slow and attempt shoot the target. 
 *   
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class Fire_v1 extends Leaf {
	public Action genAction(State state) {
		assert (state != null);

		Action action = new Action();

		if (state.hasScannedTarget() || state.isHitByRobot() || state.isHittingRobot())
		{
			// Calculate the location of the robot
			double absoluteBearing = state.getHeading();
			if (state.getScannedRobotEvents().firstElement().getDistance() <= 250) {
				absoluteBearing += state.getScannedRobotEvents().firstElement().getBearing();
			}
			if (state.isHitByRobot() || state.isHittingRobot()) {
				absoluteBearing += state.getHitRobotEvent().getBearing();
			}
			double bearingFromGun = normalRelativeAngle(absoluteBearing - state.getGunHeading());
			
			action.setGunRotation(0);	// Stops the gun's rotation.
			
			// If it's close enough, fire!
			if (Math.abs(bearingFromGun) <= 3) {
				if (state.getGunHeat() == 0)
				{
					action.setFireGun(Math.min(3 - Math.abs(bearingFromGun),state.getEnergy() - .1));
					action.setVote(45);
				}
			} else {
				// otherwise just set the gun to turn.
				action.setGunRotation(bearingFromGun);
				action.setVote(25);
			}
			action.scan();
		}
		else
		{
			action.setGunRotation(-5.0);
			action.setVote(10);
		}
		action.scan();
		return action;
	}

	// Helper Method
	private double normalRelativeAngle(double angle) {
		if (angle > -180 && angle <= 180)
			return angle;
		double fixedAngle = angle;
		while (fixedAngle <= -180)
			fixedAngle += 360;
		while (fixedAngle > 180)
			fixedAngle -= 360;
		return fixedAngle;
	}

	public Element genXML() {
		return new Element(Util.NODE_TAG).setText("Fire_v1");		
	}
}
package behaviorFramework.behaviors;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;



import common.Util;

/**
 * This Fire Behavior was developed to deliver long bursts of intense fire
 * at unmoving targets at long range.
 * Precondition:  The target has a velocity less than 0.10;
 * Actions: 1) Call allStop() to stabilize the shooting position.
 * 			2) Aligned the gun turret with the target (0.5 degree +/-).
 * 			3) Fire at MaxRate with MaxEnergy.
 *  
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class SniperFire extends Leaf {
	public Action genAction(State state) {
		assert (state != null);

		Action action = new Action();
		
		if (state.hasScannedTarget())
		{
			if (state.getScannedRobotEvents().firstElement().getVelocity() < 0.1) {
				action.setVelocity(0.0);
				action.setTurnRate(0.0);
				action.setGunRotation(0.0);
				action.setRadarRotation(0.0);

				// Calculate the exact location of the robot
				double absoluteBearing = state.getHeading() + state.getScannedRobotEvents().firstElement().getBearing();
				double bearingFromGun = normalRelativeAngle(absoluteBearing - state.getGunHeading());

				if (Math.abs(bearingFromGun) <= 1.0)
					action.setFireGun(Math.min(3, state.getEnergy() - .1));
				else
					action.setFireGun(Math.min(3 / bearingFromGun, state.getEnergy() - .1));
				action.setGunRotation(bearingFromGun / 3);

				action.scan();
				action.setVote(65);
			}
		} else
		{
			action.setGunRotation(5);
			action.setVote(10);
		}
		return action;
	}

	// Helper Method
	private double normalRelativeAngle(double angle) {
		if (angle > -180 && angle <= 180) return angle;
		double fixedAngle = angle;
		while (fixedAngle <= -180) fixedAngle += 360;
		while (fixedAngle > 180)   fixedAngle -= 360;
		return fixedAngle;
	}

	public Element genXML() {
		return new Element(Util.NODE_TAG).setText("SniperFire");		
	}
}
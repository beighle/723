package behaviorFramework.behaviors;

import java.util.Random;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;



import common.Util;

/**
 * This wander behavior performs a series of "S" turns across the battlefield.  When it
 * hits a wall the polarity of the velocity is flipped.  The angle of the arc is randomly
 * selected to be between 30 and 120 degrees before changing its polarity.
 *
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class Wander_v3 extends Leaf {
	Random rand = new Random();
	double velocity = 4.0;
	double turnRate = 3.0;
	int turnCounter = 0;
	public Action genAction(State state) {
        assert (state != null);

        Action action = new Action();

        // We've crossed the board and hit the wall. 
        if (state.isHittingWall()) velocity *= -1;
        
        // Select the magnitude of our next turn.
        if (turnCounter < 1) 
        {
        		turnRate *= -1;
        		turnCounter = (int)(rand.nextDouble() * 30) + 10;
        }
        turnCounter--;
        action.setVelocity(velocity);
        action.setTurnRate(turnRate);
        action.setVote(25);
		
		return action;
	}
	
	public Element genXML() {
		return new Element(Util.NODE_TAG).setText("Wander_v3");		
	}
}
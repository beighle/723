package behaviorFramework.behaviors;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;



import common.Util;

/**
 * This Fire will let loose on a target that is at close range and is less than
 * 15 degrees off bore site!
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class ShortRngFire extends Leaf {
	public Action genAction(State state) {
		assert (state != null);

		Action action = new Action();
		
		if (state.hasScannedTarget() || state.isHitByRobot() || state.isHittingRobot())
		{
			double absoluteBearing = state.getHeading();
			// Shoot the SOB!
			if (state.getScannedRobotEvents().firstElement().getDistance() <= 250) {
				// Calculate the exact location of the robot
				absoluteBearing += state.getScannedRobotEvents().firstElement().getBearing();
			}
			if (state.isHitByRobot() || state.isHittingRobot()) {
				absoluteBearing += state.getHitRobotEvent().getBearing();
			}
			double bearingFromGun = normalRelativeAngle(absoluteBearing - state.getGunHeading());

			if (bearingFromGun < 15)
			{
				// He's close enough, FIRE!!
				action.setGunRotation(bearingFromGun/3);	// Slows the gun's rotation.
				action.setFireGun(Math.min(3,state.getEnergy() - 0.1));
				action.setVote(50);
			}
		}
		else
		{
			action.setGunRotation(-5);
			action.setVote(10);
		}
		// Generates another scan event if we've see a robot.
		action.scan();
		return action;
	}

	// Helper Method
	private double normalRelativeAngle(double angle) {
		if (angle > -180 && angle <= 180)
			return angle;
		double fixedAngle = angle;
		while (fixedAngle <= -180)
			fixedAngle += 360;
		while (fixedAngle > 180)
			fixedAngle -= 360;
		return fixedAngle;
	}

	public Element genXML() {
		return new Element(Util.NODE_TAG).setText("ShortRngFire");		
	}
}
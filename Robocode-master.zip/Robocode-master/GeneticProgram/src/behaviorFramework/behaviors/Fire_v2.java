package behaviorFramework.behaviors;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;



import common.Util;

/**
 * This Fire Behavior was adapted from Mathew Nelson's TrackFire robot.
 * It expects the Radar and Gun to be aligned.  The default action is to
 *   rotate the turret 5 degrees/tick.  If a target has been detected
 *   the turret rotation will stop or slow and attempt shoot the target. 
 *   
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class Fire_v2 extends Leaf {
	public Action genAction(State state) {
		assert (state != null);

		Action action = new Action();

		if (state.hasScannedTarget() || state.isHitByRobot() || state.isHittingRobot())
		{
			if (state.getScannedRobotEvents().firstElement().getDistance() < 500)
			{
				// Calculate the location of the robot
				double absoluteBearing = state.getHeading() + state.getScannedRobotEvents().firstElement().getBearing();
				double bearingFromGun = normalRelativeAngle(absoluteBearing - state.getGunHeading());

				action.setGunRotation(0);	// Stops the gun's rotation.

				// If it's close enough, fire!
				if (Math.abs(bearingFromGun) <= 3) {
					// Don't hold back if you're off angle like Fire_v1...
					// Don't worry about the gun temperature like TrakFire_v1...
					action.setGunRotation(bearingFromGun/3);
					action.setFireGun(Math.min(3,state.getEnergy() - .1));
					action.setVote(45);		// Make sure to vote.
				} else {
					// otherwise set the gun to turn.
					action.setGunRotation(bearingFromGun/2);
					action.setFireGun(Math.min(3 - Math.abs(bearingFromGun)/3, state.getEnergy() - .1));
					action.setVote(35);		// Make sure to vote.
				}
			}
		}
		else
		{
			action.setGunRotation(-5);
			action.setVote(10);
		}
		action.scan();
		return action;
	}

	// Helper Method
	private double normalRelativeAngle(double angle) {
		if (angle > -180 && angle <= 180)
			return angle;
		double fixedAngle = angle;
		while (fixedAngle <= -180)
			fixedAngle += 360;
		while (fixedAngle > 180)
			fixedAngle -= 360;
		return fixedAngle;
	}

	public Element genXML() {
		return new Element(Util.NODE_TAG).setText("Fire_v2");		
	}
}
package behaviorFramework.behaviors;

import java.util.Random;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;

import common.Util;

/**
 * This Dodge behavior causes the robot to reposition when it's been
 * shot or rammed by another robot.
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */
 
public class Dodge extends Leaf {
    private Random rand = new Random();
    private double velocity = 8.0;
    private double turnRate = 4.0;
    private int turnCounter = 0;
    
	public Action genAction(State state) {
        assert (state != null);

        Action action = new Action();
        
        // Relocate if we've been shot or hit by a robot!
        //
        if (turnCounter < 1) 
        {
        	if (state.isHitByBullet() || state.isHitByRobot())
      		{
        		if (rand.nextBoolean()) velocity *= -1;
        		if (rand.nextBoolean())	turnRate *= -1;
        		turnCounter = 20;
            }
        	if (state.isHitByRobot())
        	{

        		// We're being rammed from the front-right quad
        		if (state.getHitRobotEvent().getBearing() > 0 && state.getHitRobotEvent().getBearing() <= 90)
        		{
        			if (velocity > 0) velocity *= -1;
        			if (turnRate < 0) turnRate *= -1;
        		}
        		// We're being rammed from the rear-right quad
        		else if (state.getHitRobotEvent().getBearing() > 90 && state.getHitRobotEvent().getBearing() <= 180)
        		{
        			if (velocity < 0) velocity *= -1;
        			if (turnRate > 0) turnRate *= -1; 
        		}
           		// We're being rammed from the rear-left quad
        		else if (state.getHitRobotEvent().getBearing() > 180 && state.getHitRobotEvent().getBearing() <= 270)
        		{
        			if (velocity < 0) velocity *= -1;
        			if (turnRate < 0) turnRate *= -1; 
        		}
        		// We're being rammed from the front-left quad
        		else
        		{
        			if (velocity > 0) velocity *= -1;
        			if (turnRate > 0) turnRate *= -1; 
        		}
        		turnCounter = 20;
        	}
        }
        if (state.isHittingWall()) velocity *= -1;
        
        if (turnCounter > 0) {
        	action.setVelocity(velocity);
        	action.setTurnRate(turnRate);
        	action.setVote(100);
        	turnCounter--;
        }
        else
        {
        	action.setVelocity(0.0);
        	action.setTurnRate(0.0);
        	action.setVote(1);
        }
		
		return action;
	}

	public Element genXML() {
		return new Element(Util.NODE_TAG).setText("Dodge");		
	}
}
package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Juliet extends evolutionRobot {
	public Juliet(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Juliet");	
	}


}

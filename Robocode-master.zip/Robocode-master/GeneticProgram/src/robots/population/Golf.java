package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Golf extends evolutionRobot {
	public Golf(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Golf");	
	}


}

package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Indigo extends evolutionRobot {
	public Indigo(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Indigo");
	}


}

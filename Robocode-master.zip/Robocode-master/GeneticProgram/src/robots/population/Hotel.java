package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Hotel extends evolutionRobot {
	public Hotel(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Hotel");	
	}


}

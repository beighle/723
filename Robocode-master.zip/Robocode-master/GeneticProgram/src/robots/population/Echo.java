package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Echo extends evolutionRobot {
	public Echo(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Echo");	
	}


}

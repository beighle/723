package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Foxtrot extends evolutionRobot {
	public Foxtrot(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Foxtrot");	
	}


}

package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Delta extends evolutionRobot {
	public Delta(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Delta");	
	}


}

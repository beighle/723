package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Charlie extends evolutionRobot {
	public Charlie(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Charlie");	
	}


}

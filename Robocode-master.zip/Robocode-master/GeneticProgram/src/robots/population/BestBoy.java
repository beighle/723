package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class BestBoy extends evolutionRobot {
	public BestBoy(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("bestBoy");	
	}
}

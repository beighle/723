package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Alpha extends evolutionRobot {
	public Alpha(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Alpha");	
	}

}

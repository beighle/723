package robots.population;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Bravo extends evolutionRobot {
	public Bravo(){
		myBehavior = BehaviorFactory.getInstance().getBehaviorFromXML("Bravo");	
	}


}

package robots.samples;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class TrackFire extends evolutionRobot {
	public TrackFire(){
		myBehavior = BehaviorFactory.getInstance().getMyBehavior("TrackFire");	
	}


}

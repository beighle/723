package robots.samples;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class SittingDuck extends evolutionRobot {
	public SittingDuck(){
		myBehavior = BehaviorFactory.getInstance().getMyBehavior("SittingDuck");	
	}


}

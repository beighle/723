package robots.samples;

import robots.evolutionRobot;
import common.BehaviorFactory;

public class Wander extends evolutionRobot {
	public Wander(){
		myBehavior = BehaviorFactory.getInstance().getMyBehavior("Wander");	
	}


}

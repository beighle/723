package robots;

import java.awt.Color;

import robocode.AdvancedRobot;
import common.JBBehaviorFactory;
import behaviorFramework.*;

public class Robo5000 extends AdvancedRobot {

	protected State myState = new State();
	protected JBBehavior myBehavior =
			JBBehaviorFactory.getInstance().getMyBehavior("evolutionRobot");

	public Robo5000(){

		myBehavior = JBBehaviorFactory.getInstance().getBehaviorFromXML("Robo5000");
	}

	public void run() {

		setColors(Color.GREEN, Color.LIGHT_GRAY, Color.YELLOW);

		// Isolates Turret/Radar motion to encourage behavioral independence.
		setAdjustGunForRobotTurn(true);
		setAdjustRadarForRobotTurn(true);
		setAdjustRadarForGunTurn(false);

		myState.clearEnvironment();

		// These state variables only need to be set once per game.
		myState.setHeight(this.getHeight());
		myState.setWidth(this.getWidth());
		myState.setNumberOfRounds(this.getNumRounds());
		myState.setBoardHeight(this.getBattleFieldHeight());
		myState.setBoardWidth(this.getBattleFieldWidth());
		this.getOthers();


		/* main loop of execution
		 * 1. update the state environment
		 * 2. request an action from the myBehavior
		 * 3. execute the proposed action
		 * 4. execute the Robocode environment
		 */
		while (true) {
			updateState();
			myBehavior.genAction(myState).execute(this);
			execute();
		}
	}

	protected void updateState() {

		myState.setX(this.getX());
		myState.setY(this.getY());
		myState.setHeading(this.getHeading());
		myState.setGunHeading(this.getGunHeading());
		myState.setRadarHeading(this.getRadarHeading());

		myState.setVelocity(this.getVelocity());
		myState.setTurnRate(this.getTurnRate());
		myState.setGunRotation(this.getGunRotation());
		myState.setRadarRotation(this.getRadarRotation());

		myState.setEnergy(this.getEnergy());
		myState.setGunTemp(this.getGunHeat());

		myState.clearEnvironment();

		myState.setOthers(this.getOthers());
		myState.setRound(this.getRoundNum());
		myState.setTime(this.getTime());

		myState.setScannedObjectEvent(this.getScannedObjectEvent());
		myState.setScannedRobotEvents(this.getScannedRobotEvents());
		myState.setHitObjectEvent(this.getHitObjectEvent());
		myState.setHitByBulletEvent(this.getHitByBulletEvent());
		myState.setBulletHitEvent(this.getBulletHitEvent());
		myState.setBulletMissedEvent(this.getBulletMissedEvent());
		myState.setBulletHitBulletEvent(this.getBulletHitBulletEvent());
		myState.setHitRobotEvent(this.getHitRobotEvent());

//		System.out.format("(x, y, theta_r, theta_g, theta_s): (%.2f,%.2f,%.2f,%.2f,%.2f) %.2f%n",myState.getX(),myState.getY(),myState.getHeading(),myState.getGunHeading(),myState.getRadarHeading(),myState.getScannedObjectEvent().getDistance());
	}

	/* *************************
	 * This robots RoboCode API
	 * *************************/

	public void onSkippedTurn() {
//		updateState();
//		myBehavior.genAction(myState).execute(this);
//		execute();
	}

	/**
	 * Returns this robot's current behavior.
	 * @return the robot's current behavior.
	 */
	public JBBehavior getBehavior() {
		return myBehavior;
	}

	/**
	 * Sets this robot's current behavior.
	 * @param behavior
	 * 				will become this robots current behavior.
	 */
	public void setBehavior(JBBehavior behavior) {
		myBehavior = behavior;
	}


}

package behaviorFramework;

import evolutionEngine.Evolveable;

/**
 * All interchangeable Behavior objects must conform to this standard interface
 * to be usable within the behavior framework.
 *  
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 */
abstract public class JBBehavior implements Evolveable {
	public abstract Action genAction(State state);
}


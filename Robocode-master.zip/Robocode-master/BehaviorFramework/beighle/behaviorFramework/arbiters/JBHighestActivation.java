package behaviorFramework.arbiters;

import java.util.ArrayList;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.JBArbitrationUnit;



import common.JBUtil;

/**
 * This arbiter selects the action with the highest utility value, winner takes all.
 *  (utility = action.getVote * weight)
 *  
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class JBHighestActivation extends JBArbitrationUnit {

	public JBHighestActivation (ArrayList<Double> weightList) {
		super();
		this.setWeights(weightList);
	}
	
	// Overloaded constructor that allows for default weight values
	public JBHighestActivation() {
		this(null);
	}

	public Action evaluate(ArrayList<Action> actionSet) {
		Action action = new Action();
		double maxUtility = 0.0;
		
		// Return the action with the greatest utility
		// Each action's vote value is weighted
		//
		for(Action a : actionSet)
		{
			double utility = a.getVote() * w.get(actionSet.indexOf(a));
			if (utility > maxUtility)
			{
				action = a;
				maxUtility = utility;
			}
		}
		// return a noOp if no action in the set votes
	    return action;
	}

	public Element genXML() {
		Element arbiterElement = new Element(JBUtil.ARBITER_TAG);
		arbiterElement.setAttribute(JBUtil.WEIGHT_1_TAG, Double.toString(w.get(0)));
		arbiterElement.setAttribute(JBUtil.WEIGHT_2_TAG, Double.toString(w.get(1)));
		arbiterElement.setAttribute(JBUtil.WEIGHT_3_TAG, Double.toString(w.get(2)));
		arbiterElement.setAttribute(JBUtil.WEIGHT_4_TAG, Double.toString(w.get(3)));
		arbiterElement.setText("HighestActivation");
		return arbiterElement;
	}
}

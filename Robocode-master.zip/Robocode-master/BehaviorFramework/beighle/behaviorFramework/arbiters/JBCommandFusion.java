package behaviorFramework.arbiters;

import java.util.ArrayList;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.JBArbitrationUnit;



import common.JBUtil;

/**
 * This arbiter builds an action that represents a vector fusion of
 * all of the proposed actions into a single action object.
 * 
 * The strength of each contributing (non-zero) sub-action is scaled
 * the contributing actions weight: (i.e. velocity += velocity[i] * w[i])
 * 
 * The new action is given the highest overall utility value.
 * The AllStop command is meaningless and is ignored.
 * The Scan command is issued regardless.
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class JBCommandFusion extends JBArbitrationUnit {

	public JBCommandFusion (ArrayList<Double> weightList) {
		super();
		this.setWeights(weightList);
	}
	
	// Overloaded constructor that allows for default weight values
	public JBCommandFusion() {
		this(null);
	}

	public Action evaluate(ArrayList<Action> actionSet) {
		Action action = new Action();
		
		assert (w.size() >= actionSet.size());
		
		double maxVote = 0.0;
		
		double velocity = 0.0;
		double turnRate = 0.0;
		double gunTurnRate = 0.0;
		double firePower = 0.0;
		double radarTurn = 0.0;

		double uVelocity 	= 0.0;
		double uTurnRate	= 0.0;
		double uGunTurn 	= 0.0;
		double uFirePower	= 0.0;
		double uRadarTurn 	= 0.0;

		for(Action a : actionSet) {
			double utility =  a.getVote() * w.get(actionSet.indexOf(a));
			if (a.getVote() > maxVote) maxVote = a.getVote();

			if (a.isVelocitySet())
			{
				velocity += a.getVelocity() * utility;
				uVelocity += utility;
			}
			if (a.isTurnRateSet())
			{
				turnRate += a.getTurnRate() * utility;
				uTurnRate += utility;
			}
			if (a.isGunRotationSet())
			{
				gunTurnRate += a.getGunRotation() * utility;
				uGunTurn += utility;
			}
			if (a.isFirePowerSet())
			{
				firePower += a.getFirePower() * utility;
				uFirePower += utility;
			}
			if (a.isRadarRotationSet())
			{
				radarTurn += a.getRadarRotation() * utility;
				uRadarTurn += utility;			
			}
			if (a.isScanSet())
				action.scan();
		}
		
		action.setVote(maxVote);
		action.setVelocity(velocity/uVelocity);
		action.setTurnRate(turnRate/uTurnRate);
		action.setGunRotation(gunTurnRate/uGunTurn);
		action.setFireGun(firePower/uFirePower);
		action.setRadarRotation(radarTurn/uRadarTurn);
		
		return action;
	}

	public Element genXML() {
		Element arbiterElement = new Element(JBUtil.ARBITER_TAG);
		arbiterElement.setAttribute(JBUtil.WEIGHT_1_TAG, Double.toString(w.get(0)));
		arbiterElement.setAttribute(JBUtil.WEIGHT_2_TAG, Double.toString(w.get(1)));
		arbiterElement.setAttribute(JBUtil.WEIGHT_3_TAG, Double.toString(w.get(2)));
		arbiterElement.setAttribute(JBUtil.WEIGHT_4_TAG, Double.toString(w.get(3)));
		arbiterElement.setText("CommandFusion");
		return arbiterElement;
	}
}

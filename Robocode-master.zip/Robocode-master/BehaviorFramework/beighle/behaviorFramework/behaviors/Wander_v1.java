package behaviorFramework.behaviors;

import java.util.Random;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.JBLeaf;
import behaviorFramework.State;



import common.JBUtil;


/**
 * This wander behavior tries to circumnavigate the perimeter of the board in a
 * clockwise direction.  It accepts the current velocity, but requires that it be
 * a positive value greater than 2.
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */

public class Wander_v1 extends JBLeaf {
	private double height, width, myX, myY;
	private double heading, velocity, turnRate;
	private double range = 50;
	Random rand = new Random();

	public Action genAction(State state) {
		assert (state != null);
		Action action = new Action();

		height = state.getBoardHeight();
		width = state.getBoardWidth();
		myX = state.getX();
		myY = state.getY();
		heading = state.getHeading();
		velocity = state.getVelocity();
		turnRate = state.getTurnRate();

		// Sets the velocity to a positive value greater than 2
		action.setVelocity(Math.max(2, Math.abs(velocity)));			

		// We're near the West wall...
		if (myX < range)
		{
			steerNorth();
			
			// We're near the North-West corner
			if (height - myY < range)
				steerEast();
		}
		// We're near the East wall...
		else if (width - myX < range)
		{
			steerSouth();
			
			// We're near the South-East corner,
			if (myY < range)
				steerWest();
		}
		// We're near the South wall...
		else if (myY < range)
		{
			steerWest();
			
			// We're near the South-West corner,
			if (myX < range)
				steerNorth();
		}
		// We're near the North wall...
		else if (height - myY < range)
		{
			steerEast();
			
			// We're near the North-East corner,
			if (width - myX < range)
				steerSouth();
		}
		else
		{
			action.setTurnRate(0.0);
			action.setVote(20);
			return action;
		}
		
		// Boundary Checking
		if (turnRate >  10) turnRate =  10;
		if (turnRate < -10) turnRate = -10;
		
		action.setTurnRate(-turnRate);
		action.setVote(25);		
		return action;
	}
	
	private void steerNorth() {
		if (heading > 180)
			turnRate = (heading-360)/3; 
		else
			turnRate = heading/3;
	}
	private void steerSouth() {
		turnRate = (heading - 180)/3;
	}
	private void steerEast() {
		if (heading > 270)
			turnRate = (heading-360-90)/3;
		else
			turnRate = (heading - 90)/3;
	}
	private void steerWest() {
		if (heading < 90)
			turnRate = (heading+90)/3;
		else
			turnRate = (heading-270)/3;
	}

	public Element genXML() {
		return new Element(JBUtil.NODE_TAG).setText("Wander_v1");
	}
}
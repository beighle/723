package behaviorFramework.behaviors;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.JBLeaf;
import behaviorFramework.State;


import common.JBUtil;



/**
 * This charging behavior causes the robot to charge another robot.
 * Assumes that AdjustRadarForGunTurn = false
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */
 
public class Charge extends JBLeaf {
	private String target = "none";
	private double velocity, turnRate, gunRotation;
	
	public Action genAction(State state) {
        assert (state != null);
        Action action = new Action();

        // Clear our target info...
        if (state.getRobotHasDied()) target = "none";

        if (state.hasScannedTarget() && target.equals("none"))
        {
        	if (state.getScannedRobotEvents().firstElement().getEnergy() < state.getEnergy())
        		target = state.getScannedRobotEvents().firstElement().getName();

			if (target.equals(state.getScannedRobotEvents().firstElement().getName())) {
				// Calculate the exact location of the robot
				double targetBearing = state.getScannedRobotEvents().firstElement().getBearing();
				double absoluteBearing = state.getHeading() + targetBearing;
				double bearingFromGun = normalRelativeAngle(absoluteBearing - state.getRadarHeading());
				gunRotation = bearingFromGun/2;
				if (gunRotation >  20) gunRotation =  20;
				if (gunRotation < -20) gunRotation = -20;
				action.setGunRotation(gunRotation);

				velocity = state.getScannedRobotEvents().firstElement().getDistance()/100;
				if (velocity > 8) velocity = 8;
				if (velocity < 4) velocity = 4;

				if (Math.abs(targetBearing) <  45) action.setVelocity( velocity);
				if (Math.abs(targetBearing) > 135) action.setVelocity(-velocity);

				turnRate = targetBearing/2;
				if (turnRate >  10) turnRate =  10;
				if (turnRate < -10) turnRate = -10;

				if (Math.abs(targetBearing) < 90) action.setTurnRate( turnRate);
				if (Math.abs(targetBearing) > 90) action.setTurnRate(-turnRate);

				action.setVote(80);
			}
			else
			{
				if (target.equalsIgnoreCase("none"))
				{
					action.setVelocity(0.0);
					action.setTurnRate(0.0);
				}
				action.setGunRotation(-5.0);
				action.setVote(10);
			}
        }
        action.scan();
        return action;
		
	}

	// Helper Method
	private double normalRelativeAngle(double angle) {
		if (angle > -180 && angle <= 180)
			return angle;
		double fixedAngle = angle;
		while (fixedAngle <= -180)
			fixedAngle += 360;
		while (fixedAngle > 180)
			fixedAngle -= 360;
		return fixedAngle;
	}

	public Element genXML() {
		return new Element(JBUtil.NODE_TAG).setText("Charge");
	}
}
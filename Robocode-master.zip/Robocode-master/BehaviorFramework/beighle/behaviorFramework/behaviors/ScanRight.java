package behaviorFramework.behaviors;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.JBLeaf;
import behaviorFramework.State;



import common.JBUtil;

/**
 * This scan behavior scans by turning the turret in a clockwise direction.
 * Assumes that AdjustRadarForGunTurn = false
 * 
 * @author Brian Woolley - for use by AFIT/ENG
 */
 
public class ScanRight extends JBLeaf {
	double turnRate = 5.0;
	
	public Action genAction(State state) {
        assert (state != null);
        
        Action action = new Action();
        action.setGunRotation(turnRate);
        action.scan();
        action.setVote(15);
		return action;
	}

	public Element genXML() {
		return new Element(JBUtil.NODE_TAG).setText("ScanRight");
	}
}
package behaviorFramework.behaviors;

import java.util.Random;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.JBLeaf;
import behaviorFramework.State;



import common.JBUtil;

/**
 * This wander behavior simulates Brownian motion by randomly executing a series of
 * 50 degree arcs.  It will also flip the polarity of its velocity when it hits a wall.
 *
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class Wander_v2 extends JBLeaf {
	Random rand = new Random();
	double velocity = 3.0;
	double turnRate = 2.5;
	int turnCounter = 0;
	public Action genAction(State state) {
        assert (state != null);

        Action action = new Action();

        if (turnCounter < 1 || state.isHittingWall()) 
        {
        		if (rand.nextBoolean()) velocity *= -1;
        		if (rand.nextBoolean())	turnRate *= -1;
        		turnCounter = 20;
        }
        turnCounter--;
        action.setVelocity(velocity);
        action.setTurnRate(turnRate);
        action.setVote(25);
		
		return action;
	}
	
	public Element genXML() {
		return new Element(JBUtil.NODE_TAG).setText("Wander_v2");
	}
}
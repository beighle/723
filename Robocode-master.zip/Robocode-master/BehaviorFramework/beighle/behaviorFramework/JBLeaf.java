package behaviorFramework;

import evolutionEngine.Evolveable;

/**
 * This is a Leaf Behavior of the behavior hierarchy.
 * All primitive behavior extend this leaf behavior.
 *
 * @author Brian Woolley - for use by AFIT/ENG
 */

abstract public class JBLeaf extends JBBehavior {
    public int depth() {
        return 1;
    }
    public void prune(int i) {
        System.err.println("Leaf nodes cannot prune themselves.");
        throw new IllegalStateException();
    }
    public int nodeCount() {
        return 1;
    }
    public void minorMutation() {
        // Leaf nodes have no minor mutations.
        // Do nothing...
    }
    public void majorMutation() {
        // Leaf nodes have no major mutations.
        // Do nothing...
    }

    public JBBehavior placeCrossoverMarker() {
        System.err.println("Leaf nodes have no sub-behaviors and cannot continue this walk.");
        throw new IllegalStateException();
    }

    public boolean placeAtMarker(Evolveable newSubTree) {
        // Leaf nodes cannot replace themselves.
        // Do nothing...
        return false;
    }
}
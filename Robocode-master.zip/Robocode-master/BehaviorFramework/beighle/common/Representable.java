package common;

import org.jdom.Element;

public interface Representable {
	public abstract Element genXML();
}

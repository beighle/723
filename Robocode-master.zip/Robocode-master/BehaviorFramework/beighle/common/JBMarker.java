package common;

import org.jdom.Element;

import behaviorFramework.Action;
import behaviorFramework.JBBehavior;
import behaviorFramework.JBLeaf;
import behaviorFramework.State;


import evolutionEngine.Evolveable;


public class JBMarker extends JBLeaf {

	// Singleton Object Construction
	private static JBMarker uniqueInstance = new JBMarker();
	private JBMarker() {}
	
	public static JBMarker getInstance () {
		return uniqueInstance;
	}

	@Override
	public Action genAction(State state) {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public int depth() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public void minorMutation() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public void majorMutation() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public JBBehavior placeCrossoverMarker() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	@Override
	public boolean placeAtMarker(Evolveable newSubTree) {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be invoked.");
	}
	public Element genXML() {
		throw new IllegalStateException("The Marker is is not a valid behavior and should never be saved as XML.");
	}
}

package common;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import behaviorFramework.JBArbitrationUnit;
import behaviorFramework.JBBehavior;
import behaviorFramework.JBCompositeBehavior;
import behaviorFramework.JBLeaf;
import behaviorFramework.arbiters.JBActivationFusion;
import behaviorFramework.arbiters.JBCommandFusion;
import behaviorFramework.arbiters.JBHighestActivation;
import behaviorFramework.arbiters.JBHighestPriority;
import behaviorFramework.behaviors.Charge;
import behaviorFramework.behaviors.Dodge;
import behaviorFramework.behaviors.Fire_v1;
import behaviorFramework.behaviors.Fire_v2;
import behaviorFramework.behaviors.ReturnFire;
import behaviorFramework.behaviors.ScanLeft;
import behaviorFramework.behaviors.ScanRight;
import behaviorFramework.behaviors.ShortRngFire;
import behaviorFramework.behaviors.JBSittingDuck;
import behaviorFramework.behaviors.SniperFire;
import behaviorFramework.behaviors.Wander_v1;
import behaviorFramework.behaviors.Wander_v2;
import behaviorFramework.behaviors.Wander_v3;
import evolutionEngine.Evolveable;



/**
 * This factory is the main access point for robots using the behaviorFramwork
 * package.  The BehaviorFactory accepts a robot's name or identifier and then
 * retrieves and builds a behavior tree from either the persistent behavior.XML
 * file or from a direct specification. 
 *  
 * @author Brian Woolley - for use by AFIT/ENG
 */
public class JBBehaviorFactory {
	
	// Singleton Object Construction
	private static JBBehaviorFactory uniqueInstance = new JBBehaviorFactory();
	private JBBehaviorFactory() {}
	
	public static JBBehaviorFactory getInstance () {
		return uniqueInstance;
	}
	
	private Random rand = new Random();

	/**
	 * 
	 * @param id
	 * @return
	 */
	public JBBehavior getBehaviorFromXML(String id) {
		assert (id != null);
		
		// ID will is used to retrieve and build an behavior
		// hierarchy from the persistent behavior.XML file		
		SAXBuilder builder = new SAXBuilder();
		try
		{
			Document behaviorXML = builder.build(new File(JBUtil.behaviorFile));
			Element root = behaviorXML.getRootElement();
			Element member = findMember(root, id);
			if (member != null)
				return buildBehavior(member.getChild(JBUtil.NODE_TAG));
			else
				return new JBSittingDuck();
		}
		catch (Throwable e) {
			e.printStackTrace();
		}
		return new JBSittingDuck();
	}
	
	/**
	 * 
	 * @param name
	 * @return
	 */
	public JBBehavior getMyBehavior(String name) {

		if (name.equalsIgnoreCase("myRobot")) {
			JBCompositeBehavior cb = new JBCompositeBehavior();
			cb.setArbitrationUnit(new JBActivationFusion());
			cb.add(new Wander_v3());
			cb.add(new Dodge());
			cb.add(new Charge());
			cb.add(new Fire_v1());
			return cb;		
		} else if (name.equalsIgnoreCase("TrackFire")) {
			return new Fire_v1();
		} else if (name.equalsIgnoreCase("Wander")) {
			return new Wander_v3();
		} else
			return new JBSittingDuck();
	}
	
	/**
	 * 
	 * @return
	 */
	public JBBehavior genRandomBehavior() {
		return genRandomCompositeBehavior();
	}

	public Evolveable cloneEvolveable(Evolveable item) {
		assert (item != null);
		
		if (item instanceof JBBehavior) {
			return cloneBehavior((JBBehavior) item);
		} else
			throw new IllegalStateException("Attempting to clone an object of type: " + item.getClass());
	}
	
	private JBBehavior cloneBehavior(JBBehavior behavior) {
		assert (behavior != null);
		
		if (behavior instanceof JBCompositeBehavior)
			return cloneCompositeBehavior((JBCompositeBehavior) behavior);
		else if (behavior instanceof JBLeaf)
			return cloneLeafBehavior((JBLeaf) behavior);
		else throw new IllegalStateException();
	}

	private JBBehavior genRandomCompositeBehavior() {
		JBCompositeBehavior cb = new JBCompositeBehavior();

		cb.setArbitrationUnit(genRandomArbiter());
		for (int i=0; i<4; i++)		// the branching factor
			if (rand.nextDouble() > 0.80)
				cb.add(genRandomCompositeBehavior());
			else
				cb.add(genRandomLeaf());				
		return cb;
	}

	public JBArbitrationUnit genRandomArbiter() {
		System.out.println("JB: Is this being used?");
		/*
		ArrayList<Double> w = new ArrayList<Double>();
		for (int i=0; i<4; i++)
			w.add(rand.nextDouble());

		JBArbitrationUnit au = null;
		
		double selector = rand.nextDouble();
		if (selector > 0.8)
			au = new JBCommandFusion(w);
		else if (selector > 0.6)
			au = new JBMonteCarlo(w);
		else if (selector > 0.4)
			au = new JBHighestPriority(w);
		else if (selector > 0.2)
			au = new JBHighestActivation(w);
		else if (selector > 0.00)
			au = new JBActivationFusion(w);
			
		assert (au != null);

		*/
		return null;//au;
	}

	public JBLeaf genRandomLeaf() {
		JBLeaf leaf = null;
		
		double selector = rand.nextDouble();
		if (selector > 0.9228)		leaf = new Fire_v2();
		else if (selector > 0.8459)	leaf = new ReturnFire();
		else if (selector > 0.7690)	leaf = new ShortRngFire();
		else if (selector > 0.6921)	leaf = new ScanLeft();
		else if (selector > 0.6152)	leaf = new ScanRight();
		else if (selector > 0.5383)	leaf = new JBSittingDuck();
		else if (selector > 0.4614)	leaf = new SniperFire();
		else if (selector > 0.3845)	leaf = new Wander_v1();
		else if (selector > 0.3076) leaf = new Wander_v2();
		else if (selector > 0.2307) leaf = new Wander_v3();
		else if (selector > 0.1538) leaf = new Dodge();
		else if (selector > 0.0769) leaf = new Charge();
		else if (selector > 0.00)	leaf = new Fire_v1();

		assert (leaf != null);
		return leaf;
	}
	
	@SuppressWarnings("unchecked")
	private Element findMember(Element root, String id) {
		List<Element> memberList = root.getChildren(JBUtil.MEMBER_TAG);
		Boolean memberFound = false;
		for (Element memberElement : memberList)
		{
			String name = memberElement.getAttributeValue(JBUtil.NAME_TAG);
			assert (name != null);
			if (name.equalsIgnoreCase(id))
				return memberElement;
		}
		// notify the user: "The robot name was not found in behavior.XML."
		if (!memberFound)
			System.err.println("The robot identifier: " + id + " was not found in " + JBUtil.behaviorFile);
		return null;
	}
	
	@SuppressWarnings("unchecked")
	private JBBehavior buildBehavior(Element currentNode) {
		// This is a composite behavior node.
		if ("Y".equalsIgnoreCase(currentNode.getAttributeValue(JBUtil.COMPOSITE_TAG)))
		{
			JBCompositeBehavior compositeBehaviorNode = new JBCompositeBehavior();
			// Setup and add the ArbitrationUnit.
			Element arbiterElement = currentNode.getChild(JBUtil.ARBITER_TAG);
			compositeBehaviorNode.setArbitrationUnit(buildArbiter(arbiterElement));
			
			// Recursively obtain and add the composing behaviors.
			List<Element> nodeList = currentNode.getChildren(JBUtil.NODE_TAG);
			for (Element subNode : nodeList)
			{
				compositeBehaviorNode.add(buildBehavior(subNode));
			}
			// This behavior is complete.
			return compositeBehaviorNode;
		}
		// This is a leaf behavior node, as well as the recursive termination.
		else
		{
			String behaviorName = currentNode.getText();
			if 		("Charge".equalsIgnoreCase(behaviorName)) 	return new Charge();
			else if ("Dodge".equalsIgnoreCase(behaviorName))		return new Dodge();
			else if ("Fire_v1".equalsIgnoreCase(behaviorName))		return new Fire_v1();
			else if ("Fire_v2".equalsIgnoreCase(behaviorName))		return new Fire_v2();
			else if ("ReturnFire".equalsIgnoreCase(behaviorName))	return new ReturnFire();
			else if ("ShortRngFire".equalsIgnoreCase(behaviorName))	return new ShortRngFire();
			else if ("ScanLeft".equalsIgnoreCase(behaviorName))		return new ScanLeft();
			else if ("ScanRight".equalsIgnoreCase(behaviorName))	return new ScanRight();
			else if ("JBSittingDuck".equalsIgnoreCase(behaviorName)) return new JBSittingDuck();
			else if ("SniperFire".equalsIgnoreCase(behaviorName))	return new SniperFire();
			else if ("Wander_v1".equalsIgnoreCase(behaviorName)) 	return new Wander_v1();
			else if ("Wander_v2".equalsIgnoreCase(behaviorName)) 	return new Wander_v2();
			else if ("Wander_v3".equalsIgnoreCase(behaviorName)) 	return new Wander_v3();
			else
			{
				System.err.println("The behavior identifier: " + behaviorName +
								   " is not a known behavior type.");				
				return new JBSittingDuck();
			}
		}
	}
	
	private JBArbitrationUnit buildArbiter(Element arbiterElement) {
		String arbiterName = arbiterElement.getText();
		ArrayList<Double> w = new ArrayList<Double>();
		JBArbitrationUnit arbiter = null;
		
		if ("JBCommandFusion".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_4_TAG)));
			arbiter = new JBCommandFusion(w);
		} else
		if ("JBMonteCarlo".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_4_TAG)));
			//arbiter = new JBMonteCarlo(w);
		} else
		if ("JBNullArbiter".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_4_TAG)));
			//arbiter = new JBNullArbiter(w);
		} else
		if ("JBHighestPriority".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_4_TAG)));
			arbiter = new JBHighestPriority(w);
		} else
		if ("JBHighestActivation".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_4_TAG)));
			arbiter = new JBHighestActivation(w);
		} else
		if ("JBActivationFusion".equalsIgnoreCase((arbiterName)))
		{
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_1_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_2_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_3_TAG)));
			w.add(Double.parseDouble(arbiterElement.getAttributeValue(JBUtil.WEIGHT_4_TAG)));
			arbiter = new JBActivationFusion(w);
		} else {
			System.err.println("The arbiter identifier: " + arbiterName +
							   " is not a known arbitration type.");				
			arbiter = new JBHighestPriority();
		}
		return arbiter;
	}
	
	private JBBehavior cloneCompositeBehavior(JBCompositeBehavior node) {
		JBCompositeBehavior cb = new JBCompositeBehavior();

		cb.setArbitrationUnit(cloneArbiter(node.getArbiter()));
		for (JBBehavior b : node.getBehaviorSet())
			cb.add(cloneBehavior(b));
		
		return cb;
	}

	private JBArbitrationUnit cloneArbiter(JBArbitrationUnit arbiter) {
		JBArbitrationUnit au = null;


		if (arbiter instanceof JBCommandFusion)
			au = new JBCommandFusion();
		//else if (arbiter instanceof JBMonteCarlo)
			//au = new JBMonteCarlo();
		//else if (arbiter instanceof JBNullArbiter)
			//au = new JBNullArbiter();
		else if (arbiter instanceof JBHighestPriority)
			au = new JBHighestPriority();
		else if (arbiter instanceof JBHighestActivation)
			au = new JBHighestActivation();
		else if (arbiter instanceof JBActivationFusion)
			au = new JBActivationFusion();
		else throw new IllegalStateException("Attempting to clone an unknown type of Arbiter.");
		
		assert (au != null);
		ArrayList<Double> w = arbiter.getWeights();
		au.setWeights(w);
		return au;
	}

	private JBBehavior cloneLeafBehavior(JBLeaf leaf) {
		JBLeaf behavior = null;

		if (leaf instanceof Charge)
			behavior = new Charge();
		else if (leaf instanceof Dodge)
			behavior = new Dodge();
		else if (leaf instanceof Fire_v1)
			behavior = new Fire_v1();
		else if (leaf instanceof Fire_v2)
			behavior = new Fire_v2();
		else if (leaf instanceof ReturnFire)
			behavior = new ReturnFire();
		else if (leaf instanceof ShortRngFire)
			behavior = new ShortRngFire();
		else if (leaf instanceof ScanLeft)
			behavior = new ScanLeft();
		else if (leaf instanceof ScanRight)
			behavior = new ScanRight();
		else if (leaf instanceof JBSittingDuck)
			behavior = new JBSittingDuck();
		else if (leaf instanceof SniperFire)
			behavior = new SniperFire();
		else if (leaf instanceof Wander_v1)
			behavior = new Wander_v1();
		else if (leaf instanceof Wander_v2)
			behavior = new Wander_v2();
		else if (leaf instanceof Wander_v3)
			behavior = new Wander_v3();
		else throw new IllegalStateException("Attempting to clone an unknown type of Behavior.");

		assert (behavior != null);
		return behavior;
	}

}

package evolutionEngine;

import behaviorFramework.JBBehavior;

public interface Evolveable extends Representable {
	public abstract int depth();
	public abstract void prune(int maxDepth);
	public abstract int nodeCount();
	public abstract JBBehavior placeCrossoverMarker();
	public abstract boolean placeAtMarker(Evolveable newSubTree);
	public abstract void minorMutation();
	public abstract void majorMutation();
}

package evolutionEngine;

import org.jdom.Element;

public interface Representable {
	public abstract Element genXML();
}

package development;

import java.awt.Color;

import behaviorFramework.sam_BehaviorFactory;
import development.myRobot;

/**
 * samRobot - a simple robot that wanders around the battle field, shooting when it sees a robot.
 */
public class sam_Robot extends myRobot {
	
	
	public sam_Robot(){
		super();
		myBehavior = sam_BehaviorFactory.getInstance().getMyBehavior("sam_Robot");	
	}
	
public void run() {
		
		setColors(Color.BLACK, Color.BLACK, Color.BLACK);
		
		// Setting these to true isolates Turret/Radar/Gun motions to encourage behavioral independence.
		// Otherwise, when the biggest one (robot) turns they all turn.
		setAdjustGunForRobotTurn(false);
		setAdjustRadarForRobotTurn(false);
		setAdjustRadarForGunTurn(false);

		myState.clearEnvironment();
		
		// These state variables only need to be set once per game.
		myState.setHeight(this.getHeight());
		myState.setWidth(this.getWidth());
		myState.setNumberOfRounds(this.getNumRounds());
		myState.setBoardHeight(this.getBattleFieldHeight());
		myState.setBoardWidth(this.getBattleFieldWidth());
		this.getOthers();
		
		
		/* main loop of execution
		 * 1. update the state environment
		 * 2. request an action from the myBehavior
		 * 3. execute the proposed action
		 * 4. execute the Robocode environment
		 */ 
		while (true) {
			updateState();
			myBehavior.genAction(myState).execute(this);
			execute();
		}
	}	
}
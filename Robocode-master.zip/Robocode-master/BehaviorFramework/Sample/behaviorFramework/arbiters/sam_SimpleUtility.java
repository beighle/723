package behaviorFramework.arbiters;

import java.util.Collection;

import behaviorFramework.Action;
import behaviorFramework.ArbitrationUnit;

/**
 * This arbiter selects the action that votes with the highest value.
 *  
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 */
public class sam_SimpleUtility extends ArbitrationUnit {

	public Action evaluate(Collection<Action> actionSet) {
		Action action = new Action();
		double maxUtility = 0.0;
		
		// Return the action with the greatest utility
		// Each action's vote value is weighted
		//
		for(Action a : actionSet)
		{
			double utility = a.getVote();
			if (utility > maxUtility)
			{
				action = a;
				maxUtility = utility;
			}
		}
		// returns a noOp if no action in the set votes
	    return action;
	}
}

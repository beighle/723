package behaviorFramework;

import behaviorFramework.arbiters.SimplePriority;
import behaviorFramework.behaviors.SittingDuck;
import behaviorFramework.behaviors.TrackFire;

/**
 * This factory is the main access point for robots using the behaviorFramwork
 * package.  The BehaviorFactory accepts a robot's name or identifier and then
 * retrieves and builds a behavior tree from the persistent behavior.XML file. 
 *  
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 */
public class sam_BehaviorFactory {
	
	// Singleton Object Construction
	private static sam_BehaviorFactory uniqueInstance = new sam_BehaviorFactory();
	private sam_BehaviorFactory() {}
	
	public static sam_BehaviorFactory getInstance () {
		return uniqueInstance;
	}
	
	public synchronized Behavior getMyBehavior(String id) {
		assert (id != null);
		
		if (id.equalsIgnoreCase("sam_Robot")) {
			ArbitrationUnit arbiter = new SimplePriority();
			
			CompositeBehavior cb = new CompositeBehavior();
			cb.setArbitrationUnit(arbiter); 
//			cb.add(new sam_Wander());
			cb.add(new TrackFire());
			return cb;
		}
		else return new SittingDuck();
	}
}

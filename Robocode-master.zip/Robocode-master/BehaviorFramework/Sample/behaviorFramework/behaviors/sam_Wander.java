package behaviorFramework.behaviors;

import java.util.Random;

import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;


/**
 * 
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 */
 
public class sam_Wander extends Leaf {
	public Action genAction(State state) {
        assert (state != null);

        Action action = new Action();
        Random rand = new Random();

        // Turn away from the obstacle (meaningless for bullets)
        // Shouldn't rebump the same wall
        //if (state.isHittingWall() || state.isHitByRobot()) // State did not have a isHittingWall function?  DWK
        if(state.isHittingObject() || state.isHitByRobot())
        {
//        	System.out.println( "Ack! Im hitting a wall!" ) ;
        	action.setVelocity(-8.0);
        	action.setTurnRate(0.0);
        	action.setVote( 10 ) ;
        }
        else
        {
        	action.setTurnRate(rand.nextDouble() * 10);        	
        	// Set a Random positive velocity, we want to wander forward
        	action.setVelocity(rand.nextDouble() * 8);
            action.setVote( 5 );
        }
		return action;
	}
}
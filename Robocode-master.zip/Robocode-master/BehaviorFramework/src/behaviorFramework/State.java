package behaviorFramework;

import java.util.Collection;
import java.util.Vector;
import java.util.HashSet;
import robocode.*;

/**
 *
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 */
public class State {

	/**
	 * Creates a duplicate State object as a means of sharing information
	 * about a robot's state, without the chance of it becoming corrupted.
	 * @param originalState
	 */
	public State copyState(State originalState) {
		State copy = new State();
		copy.bearingToWall = (bearingToWall);
		copy.bearingToObject = (bearingToObject);
		copy.boardHeight = (boardHeight);
		copy.boardWidth = (boardWidth);
		copy.energy = (energy);
		copy.gunHeading = (gunHeading);
		copy.gunRotation = (gunRotation);
		copy.gunHeat = (gunHeat);
		copy.scannedRobotEvents = (scannedRobotEvents);
		copy.scannedObjectEvent = (scannedObjectEvent);
		copy.heading = (heading);
		copy.height = (height);
		copy.isHitByBullet = (isHitByBullet);
		copy.isHitByRobot = (isHitByRobot);
		copy.isHittingRobot = (isHittingRobot);
		copy.isHittingWall = (isHittingWall);
		copy.isHittingObject = (isHittingObject);
		copy.numberOfRounds = (numberOfRounds);
		copy.numberOfOthers = (numberOfOthers);
		copy.radarHeading = (radarHeading);
		copy.radarRotation = (radarRotation);
		copy.roundNumber = (roundNumber);
//		copy.targetBearing = (targetBearing);
//		copy.targetDistance = (targetDistance);
//		copy.targetEnergy = (targetEnergy);
//		copy.targetHeading = (targetHeading);
//		copy.targetName = (targetName);
//		copy.targetVelocity = (targetVelocity);
		copy.timeOfUpdate = (timeOfUpdate);
		copy.turnRate = (turnRate);
		copy.velocity = (velocity);
		copy.width = (width);
		copy.x = (x);
		copy.y = (y);
		return copy;
	}

	// -- Environmental Info --
	private double boardWidth;
	private double boardHeight;
	private int numberOfRounds;
	private int roundNumber;
	private long timeOfUpdate;

	// -- Self-Aware Info --

	private double x;
	private double y;
	private double height;
	private double width;
	private double heading;
	private double velocity;
	private double turnRate;
	private double gunHeading;
	private double gunRotation;
	private double gunHeat;
	private double radarHeading;
	private double radarRotation;
	private double energy;

	private boolean isHitByBullet;
	private boolean isHitByRobot;
	private boolean isHittingRobot;
	private boolean isHittingObject;
	private boolean isHittingWall;
	private double bearingToWall;
	private boolean robotHasDied;

	// -- Object Data --
	private double bearingToObject;
	private double distanceToObject;
	private ScannedObjectEvent scannedObjectEvent;
	private HitObjectEvent hitObjectEvent;
	private HitByBulletEvent hitByBulletEvent;
	private BulletHitEvent bulletHitEvent;
	private HitRobotEvent hitRobotEvent;
	private boolean bulletMissedEvent;
	private boolean bulletHitBulletEvent;
	//private double objectEnergy;

	// -- Target Data --
	private Vector<ScannedRobotEvent> scannedRobotEvents;
	/*	private String targetName;
        private double targetBearing;
        private double targetDistance;
        private double targetHeading;
        private double targetVelocity;
        private double targetEnergy;
        private java.util.Vector scannedTargetEvents;*/
	private int numberOfOthers;
	private HashSet<String> activeRobotList = new HashSet<String>();
	private HashSet<String> deadRobotList = new HashSet<String>();


	// -- GETTERS and SETTERS --
	public double getBoardWidth() {
		return boardWidth;
	}
	public void setBoardWidth(double width) {
		boardWidth = width;
	}

	public double getBoardHeight() {
		return boardHeight;
	}
	public void setBoardHeight(double heigth) {
		boardHeight = heigth;
	}

	/**
	 * Indicates that a bullet has struck this robot.
	 * @return TRUE when a bullet has hit the robot.
	 */
	public boolean isHitByBullet() {
		return isHitByBullet;
	}
	public void setIsHitByBullet(boolean set) {
		isHitByBullet = set;
	}

	/**
	 * Indicates that another robot has struck this robot.
	 * @return TRUE when a robot has hit this robot.
	 */
	public boolean isHitByRobot() {
		return isHitByRobot;
	}
	public void setIsHitByRobot(boolean set) {
		isHitByRobot = set;
	}

	/**
	 * Indicates that this robot has struck another robot.
	 * @return TRUE when this robot has hit another robot.
	 */
	public boolean isHittingRobot() {
		return isHittingRobot;
	}
	public void setIsHittingRobot(boolean set) {
		isHittingRobot = set;
	}

	/**
	 * Indicates that this robot has struck an object.
	 * @return TRUE when this robot has hit an object.
	 */
	public boolean isHittingObject() {
		return isHittingObject;
	}
	public void setIsHittingObject(boolean set) {
		isHittingObject = set;
	}

	/**
	 * Returns a vector containing all ScannedTargetEvents currently in the robot's queue.
	 * You might, for example, call this while processing another event.
	 *
	 * <P>Example:
	 * <pre>
	 *   Vector v = getScannedRobotEvents();
	 *   ScannedRobotEvent e;
	 *   for (int i = 0; i < e.size(); i++) {
	 *      e = (ScannedRobotEvent)v.elementAt(i);
	 *      <i> (do something with e) </i>
	 *   }
	 * </pre>
	 *
	 * @see #onScannedRobot
	 * @see robocode.ScannedRobotEvent
	 * @see Vector
	 */
//	public java.util.Vector getScannedTargetEvents() {
//		return scannedTargetEvents;
//	}

	/**
	 */
	public ScannedObjectEvent getScannedObjectEvent() {
		return scannedObjectEvent;
	}

	public void setScannedObjectEvent(ScannedObjectEvent event) {
		scannedObjectEvent = event;
	}

	public Vector<ScannedRobotEvent> getScannedRobotEvents() {
		return scannedRobotEvents;
	}

	public void setScannedRobotEvents(Vector<ScannedRobotEvent> event) {
		scannedRobotEvents = event;
	}

	public HitObjectEvent getHitObjectEvent() {
		return hitObjectEvent;
	}

	public void setHitObjectEvent(HitObjectEvent event) {
		hitObjectEvent = event;
	}

	public void setHitByBulletEvent(HitByBulletEvent event) {
		hitByBulletEvent = event;
	}

	public HitByBulletEvent getHitByBulletEvent() {
		return hitByBulletEvent;
	}

	public boolean hasHitByBullet() {
		return hitByBulletEvent.activeHitByBulletEvent();
	}

	public void setHitRobotEvent(HitRobotEvent event) {
		hitRobotEvent = event;
	}

	public HitRobotEvent getHitRobotEvent() {
		return hitRobotEvent;
	}

	public boolean hasHitRobotEvent() {
		return hitRobotEvent.activeHitRobotEvent();
	}

	public void setBulletHitEvent(BulletHitEvent event) {
		bulletHitEvent = event;
	}

	public BulletHitEvent getBulletHitEvent() {
		return bulletHitEvent;
	}

	public boolean hasBulletHit() {
		return bulletHitEvent.activeBulletHitEvent();
	}

	public void setBulletMissedEvent(boolean event) {
		bulletMissedEvent = event;
	}

	public boolean hasBulletMissed() {
		return bulletMissedEvent;
	}

	public void setBulletHitBulletEvent(boolean event) {
		bulletHitBulletEvent = event;
	}

	public boolean hasBulletHitBullet() {
		return bulletHitBulletEvent;
	}

	/**
	 * Indicates that a robot has been scanned by this robot's radar.
	 * @return TRUE when a robot has been scanned.
	 */
	public boolean hasScannedTarget() {
		if (scannedRobotEvents == null)
			return false;
		if (scannedRobotEvents.size() == 0)
			return false;
		return true;
	}

	/**
	 * Indicates that a robot has scanned an object.
	 * @return TRUE when an object has been scanned.
	 */
	public boolean hasScannedObject() {
		return scannedObjectEvent.getActive();
	}

	/**
	 * Indicates the name of the current target.
	 * @return "Unknown" if no specific target exists.
	 */
/*	public String getTargetName() {
		return targetName;
	}
	public void setTargetName(String name) {
		activeRobotList.add(name);
		targetName = name;
	}
*/

	/**
	 * Indicates the bearing to the current target.
	 * @return NaN if no specific target exists.
	 */
//	public double getTargetBearing() {
//		return targetBearing;
//	}
//	public void setTargetBearing(double newBearing) {
//		targetBearing = newBearing;
//	}

	/**
	 * Indicates the distance to the current target.
	 * @return NaN if no specific target exists.
	 */
//	public double getTargetDistance() {
//		return targetDistance;
//	}
//	public void setTargetDistance(double newDistance) {
//		targetDistance = newDistance;
//	}

	/**
	 * Indicates the heading of the current target.
	 * @return NaN if no specific target exists.
	 */
//	public double getTargetHeading() {
//		return targetHeading;
//	}
//	public void setTargetHeading(double newHeading) {
//		targetHeading = newHeading;
//	}

	/**
	 * Indicates the velocity of the current target.
	 * @return NaN if no specific target exists.
	 */
//	public double getTargetVelocity() {
//		return targetVelocity;
//	}
//	public void setTargetVelocity(double newVelocity) {
//		targetVelocity = newVelocity;
//	}

	/**
	 * Indicates the energy level of the current target.
	 * @return NaN if no specific target exists.
	 */
//	public double getTargetEnergy() {
//		return targetEnergy;
//	}
//	public void setTargetEnergy(double newEnergy) {
//		targetEnergy = newEnergy;
//	}

	/**
	 * Indicates that a wall has been struck by this robot.
	 * @return TRUE when a wall has been hit.
	 */
	public boolean isHittingWall() {
		return isHittingWall;
	}
	public void setIsHittingWall(boolean set) {
		isHittingWall = set;
	}

	/**
	 * Indicates a bearing to the wall most recently struck.
	 * @return NaN if no wall was struck.
	 */
	public double getBearingToWall() {
		return bearingToWall;
	}
	public void setBearingToWall(double newBearing) {
		bearingToWall = newBearing;
	}

	/**
	 * Indicates a bearing to the object most recently struck.
	 * @return NaN if no object was struck.
	 */
	public double getBearingToObject() {
		return bearingToObject;
	}
	public void setBearingToObject(double newBearing) {
		bearingToObject = newBearing;
	}

	/**
	 * Indicates a distance to the object most recently struck.
	 * @return NaN if no object was struck.
	 */
	public double getDistanceToObject() {
		return distanceToObject;
	}
	public void setDistanceToObject(double dist){
		distanceToObject = dist;
	}

	public double getX() {
		return x;
	}
	public void setX(double newX) {
		x = newX;
	}

	public double getY() {
		return y;
	}
	public void setY(double newY) {
		y = newY;
	}

	/**
	 * Indicates the current heading of this robot, in degrees.
	 * @return double, the robot's heading, in degrees.
	 */
	public double getHeading() {
		return heading;
	}
	public void setHeading(double newHeading) {
		heading = newHeading;
	}

	public double getVelocity() {
		return velocity;
	}
	public void setVelocity(double velocity) {
		this.velocity = velocity;
	}

	public double getTurnRate() {
		return turnRate;
	}
	public void setTurnRate(double newTurnRate) {
		turnRate = newTurnRate;
	}

	/**
	 * Indicates the current direction of this robot's gun, in degrees.
	 * @return double, the direction of this robot's gun, in degrees.
	 */
	public double getGunHeading() {
		return gunHeading;
	}
	public void setGunHeading(double newHeading) {
		gunHeading = newHeading;
	}

	public double getGunRotation() {
		return gunRotation;
	}
	public void setGunRotation(double newGunRotation) {
		gunRotation = newGunRotation;
	}

	public double getGunHeat() {
		return gunHeat;
	}
	public void setGunTemp(double heat) {
		gunHeat = heat;
	}

	/**
	 * Indicates the current direction of this robot's radar, in degrees.
	 * @return double, the direction of this robot's radar, in degrees.
	 */
	public double getRadarHeading() {
		return radarHeading;
	}
	public void setRadarHeading(double newHeading) {
		radarHeading = newHeading;
	}

	public double getRadarRotation() {
		return radarRotation;
	}
	public void setRadarRotation(double rotation) {
		radarRotation = rotation;
	}

	public double getEnergy() {
		return energy;
	}
	public void setEnergy (double energy) {
		this.energy = energy;
	}

	public int getNumberOfOthers() {
		return numberOfOthers;
	}
	public void setOthers(int others) {
		numberOfOthers = others;
	}

	public int getNumberOfRounds() {
		return numberOfRounds;
	}
	public void setNumberOfRounds(int numRounds) {
		numberOfRounds = numRounds;
	}

	public int getRoundNumber() {
		return roundNumber;
	}
	public void setRound(int numRounds) {
		roundNumber = numRounds;
	}

	public long getTimeUpdated() {
		return timeOfUpdate;
	}
	public void setTime(long time) {
		timeOfUpdate = time;
	}

	public double getHeight() {
		return height;
	}
	public void setHeight(double newHeight) {
		height = newHeight;
	}

	public double getWidth() {
		return width;
	}
	public void setWidth(double newWidth) {
		width = newWidth;
	}

	/**
	 * Resets the following state variables to their default value:
	 * -isHitByBullet    : false
	 * -isHitByRobot     : false
	 * -isHittingRobot   : false
	 * -hasScannedTarget : false
	 * -robotHasDied	 : false
	 *
	 * -targetName       : "Unknown"
	 * -targetBearing    : NaN
	 * -targetDistance   : NaN
	 * -targetHeading    : NaN
	 * -targetVelocity   : NaN
	 * -targetEnergy     : NaN
	 *
	 * -isHittingWall    : false
	 * -bearingToWall    : NaN
	 */
	public void clearEnvironment() {
		setIsHitByBullet(false);
		setIsHittingRobot(false);
		setIsHitByRobot(false);
		setRobotHasDied(false);

		setIsHittingWall(false);
		setBearingToWall(Double.NaN);
	}

	private void setRobotHasDied(boolean set) {
		robotHasDied = set;
	}
	public boolean getRobotHasDied() {
		return robotHasDied;
	}
	public void setRobotAsDead(String name) {
		setRobotHasDied(true);
		activeRobotList.remove(name);
		deadRobotList.add(name);
		System.out.println(name + " was put into the deadRobotList.");
	}
	public Collection<String> getDeadRobotList() {
		return deadRobotList;
	}
}



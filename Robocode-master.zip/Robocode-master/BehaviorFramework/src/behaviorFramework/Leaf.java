package behaviorFramework;

/**
 * This is a Leaf Behavior of the behavior hierarchy.
 * All elemenatal behavior extend this leaf behavior.
 * 
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 */
 
abstract public class Leaf extends Behavior {
}
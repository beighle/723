package behaviorFramework.behaviors;

import robocode.*;
import behaviorFramework.Action;
import behaviorFramework.Leaf;
import behaviorFramework.State;

import java.text.DecimalFormat;

/**
 * This Fire Behavior was adapted from Mathew Nelson's TrackFire robot.
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 */
public class TrackFire extends Leaf {
	public Action genAction(State state) {
		assert (state != null);

		Action action = new Action();

		if (state.hasHitByBullet())
			System.out.println("AAHH, I've been hit!");
		
		if (state.hasBulletHit())
			System.out.println("Yay! Got the sucker " + state.getBulletHitEvent().getName());

		// Shoot the SOB!
		if ( state.hasScannedTarget())
		{
			ScannedRobotEvent target = state.getScannedRobotEvents().firstElement();
			//Do this if you want to loop through all targets.
//			Iterator<ScannedRobotEvent> iter = state.getScannedRobotEvents().iterator();
//			ScannedRobotEvent target = iter.next();
			
			// Calculate the location of the robot
			double absoluteBearing = target.getBearing(); //state.getHeading() + target.getBearing();
			double bearingFromGun = normalRelativeAngle(absoluteBearing - state.getGunHeading());
			
			action.setGunRotation(0.0);	// Stops the gun's rotation.
			action.setRadarRotation(0.0);
			DecimalFormat df = new DecimalFormat();
			df.setMaximumFractionDigits(2);
			System.out.println( "Scanned target! " + target.getName() + " " + df.format(target.getBearing()) + " " + df.format(absoluteBearing) );
			// If it's close enough, fire!
//			if (Math.abs(bearingFromGun) <= 3) {
				if (state.getGunHeat() == 0)
				{
					action.setFireGun(Math.min(3 - Math.abs(bearingFromGun),state.getEnergy() - .1));
					action.scan();
					// Make sure to vote if you want a chance to be picked.
					action.setVote(50);
//					System.out.println("FIRE!");
//				}
			} else {
				// Do nothing
				action.scan();
				action.setVote(10);
			}
				// otherwise just set the gun to turn.
//				action.setGunRotation(bearingFromGun);
//				action.setVote(10);		// Make sure to vote.
//			}
			// Generates another scan event if we've see a robot.
//			action.scan();
			
		} else {
			action.setGunRotation(1.0);
			action.scan();
			// Make sure to vote if you want a chance to be picked.
			action.setVote(5);
		}
		return action;
	}

	// Helper Method
	private double normalRelativeAngle(double angle) {
		if (angle > -180 && angle <= 180)
			return angle;
		double fixedAngle = angle;
		while (fixedAngle <= -180)
			fixedAngle += 360;
		while (fixedAngle > 180)
			fixedAngle -= 360;
		return fixedAngle;
	}
}
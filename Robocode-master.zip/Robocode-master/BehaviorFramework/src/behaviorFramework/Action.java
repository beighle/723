package behaviorFramework;

import robocode.AdvancedRobot;

/**
 * Action objects are used by behaviors to pass their recommended actions
 * up the behavior framework.  The vote field is used by arbiters to select
 * an action for execution or submission to a higher level of the framework.
 * 
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 */
public class Action {
	
	//--------------------------------------------------DEMOCRATIC Voice
	private double f_vote = 0.0;
	public double getVote() {
		return f_vote;
	}
	public void setVote(double i) {
		f_vote = i;
	}
	
	//--------------------------------------------------MOTOR Actions
	private double velocity = 0.0;
	private boolean newVelocityRequest;
	public boolean isVelocitySet() {
		return newVelocityRequest;
	}
	public double getVelocity() {
		return velocity;
	}
	public void setVelocity(double newVelocity)	{
		newVelocityRequest = true;
		velocity = newVelocity;		
	}

	private double turnRate = 0.0;
	private boolean newTurnRateRequest;
	public boolean isTurnRateSet() {
		return newTurnRateRequest;
	}
	public double getTurnRate() {
		return turnRate;
	}
	public void setTurnRate(double newTurnRate) {
		newTurnRateRequest = true;
		turnRate = newTurnRate;		
	}

	//--------------------------------------------------GUN Actions
	private double gunRotation = 0.0;
	private boolean newGunRotationRequest;
	public boolean isGunRotationSet() {
		return newGunRotationRequest;
	}
	public double getGunRotation() {
		return gunRotation;
	}
	public void setGunRotation(double newTurnRate) {
		newGunRotationRequest = true;
		gunRotation = newTurnRate;
	}
	
	private double firePower = 0.0;
	private boolean fireGunRequest;
	public boolean isFirePowerSet() {
		return fireGunRequest;
	}
	public double getFirePower() {
		return firePower;
	}
	public void setFireGun(double power) {
		firePower = power;
		if ( power != 0 )
			fireGunRequest = true;
		else
			fireGunRequest = false;
	}

	//--------------------------------------------------RADAR Actions
	private double radarRotation = 0.0;
	private boolean newRadarRotationRequest;
	public boolean isRadarRotationSet() {
		return newRadarRotationRequest;
	}
	public double getRadarRotation() {
		return radarRotation;
	}
	public void setRadarRotation(double newTurnRate) {
		newRadarRotationRequest = true;
		radarRotation = newTurnRate;
	}

	private boolean radarScanRequest;
	public boolean isScanSet() {
		return radarScanRequest;
	}
	public void scan()
	{
		radarScanRequest = true;
	}

	//--------------------------------------------------Misc Actions
	private boolean allStopRequested = false;

	public boolean isAllStopSet() {
		return allStopRequested;
	}

	public void setAllStop() {
		allStopRequested = true;		
	}

	/**
	 * 
	 * @param advRobot
	 */
	public void execute(AdvancedRobot advRobot) {
		
		// etc...
		if (allStopRequested) advRobot.allStop();
		if (newVelocityRequest) advRobot.setVelocity(velocity);
		if (newTurnRateRequest) advRobot.setTurnRate(turnRate);

		if (newGunRotationRequest) advRobot.setGunRotation(gunRotation);
		if (fireGunRequest) advRobot.fire(firePower);

		if (newRadarRotationRequest) advRobot.setRadarRotation(radarRotation);
		if (radarScanRequest) advRobot.scan();
		// etc...
	}
}
package behaviorFramework;

import behaviorFramework.arbiters.*;
import behaviorFramework.behaviors.*;

/**
 * This factory is the main access point for robots using the behaviorFramwork
 * package.  The BehaviorFactory accepts a robot's name or identifier and then
 * retrieves and builds a behavior tree from the persistent behavior.XML file. 
 *  
 * @author Brian Woolley - for use by AFIT/ENG - CSCE623 and CSCE723
 */
public class BehaviorFactory {
	
	// Singleton Object Construction
	private static BehaviorFactory uniqueInstance = new BehaviorFactory();
	private BehaviorFactory() {}
	
	public static BehaviorFactory getInstance () {
		return uniqueInstance;
	}
	
	public synchronized Behavior getMyBehavior(String id) {
		assert (id != null);
		
		if (id.equalsIgnoreCase("myRobot")) {
//			CompositeBehavior cb = new CompositeBehavior();
//			cb.add(new Wander());
//			cb.add(new TrackFire());
//			return cb;
			return new SittingDuck();
		}
		else return new SittingDuck();
	}
}
